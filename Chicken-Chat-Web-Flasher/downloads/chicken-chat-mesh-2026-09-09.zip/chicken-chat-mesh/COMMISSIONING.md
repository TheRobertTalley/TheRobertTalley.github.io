# Chicken Chat repeaters and Wi-Fi gateway

Implemented firmware for standard ESP32 DevKit boards with 4 MB flash. The same repeater image works as a dedicated repeater, a repeater with sensors, or a non-forwarding sensor leaf. A separate gateway image reaches the hub through farm Wi-Fi.

```text
Sensor / Bin Commander / Cluck-o-Magic
        <-> repeater <-> repeater <-> repeater <-> gateway <-> farm Wi-Fi <-> hub
```

## Delivered behavior

- Automatic forwarding over any reachable same-network repeaters. No neighbor addresses or route tables to maintain. Alternate paths work where overlapping physical coverage exists.
- Eight radio hops maximum, including the source-to-first-repeater link. Seven intermediate repeaters can fit between source and gateway.
- Repeaters can sample an ADC1 input and a dry contact while forwarding. Pins are disabled until configured. Raw ADC values are 0-4095; engineering-unit calibration remains sensor-specific. Use only appropriately conditioned 0-3.3 V inputs. Contact inputs use pull-ups and report closed when LOW.
- New feeder builds publish relay state, feed presence, E-stop, and fault state. Each can also forward mesh traffic. Existing local controls, safety logic, pin maps, and legacy direct ESP-NOW messages are retained.
- AES-256-GCM encrypted/authenticated radio envelopes with fresh random 96-bit nonces, shared farm network key, separate network ID, and explicit serialization. Maximum wire size is 212 bytes.
- Jittered forwarding, duplicate suppression, five source transmission attempts, a 30-second final delivery deadline, and an eight-message source queue. Alarm packets receive queue priority. A receiver ACK means application acceptance; a radio send alone does not count as success.
- Gateway records are written to LittleFS before acknowledging the source. Up to 256 records are retained, with the last 32 positions reserved for alarms. The hub commits records to SQLite before releasing gateway copies. If storage fills or fails, records are not falsely acknowledged. Source queues are RAM-only and finite; prolonged outages or source power loss can lose unsaved readings.
- USB provisioning stores configuration in NVS. Radio keys and Wi-Fi credentials are absent from binaries and are never echoed by status responses.
- A hub collector writes live records to `ChickenChat/data/live/mesh_nodes.json`; the existing dashboard API serves them at `GET /api/mesh-nodes`. The existing overview and cloud snapshot are not overwritten with a different schema.

This release carries telemetry, alarms, acknowledgments, and diagnostic ping/pong traffic. It does not execute new mesh actuator commands or extend general phone/camera internet access. All nodes with the network key are trusted members; this shared-key design is not per-device command authorization. Legacy direct control remains local.

## Radio requirements

Keep the gateway's 2.4 GHz Wi-Fi AP and all mesh nodes on the same fixed channel. Use channel 6 when including existing feeder/shaker firmware. A single ESP32 cannot remain on an independent ESP-NOW channel while associated with Wi-Fi on another channel.

The gateway refuses to continue on a mismatched connected AP channel, restores the commissioned channel, and reports `wifi_channel_mismatch` over USB. Reconfigure the AP/channel and reboot or reprovision the gateway to retry. Failed Wi-Fi connection attempts run for up to 10 seconds, at one-minute intervals. Those attempts can temporarily interrupt this gateway's reception while its radio searches; other repeaters continue. Repeater-only nodes never join or search for upstream Wi-Fi. A dual-radio or wired-backhaul gateway is a future option, not implemented by this image.

Use continuously powered repeaters. Put the gateway within reliable farm Wi-Fi coverage, then place repeaters back toward the house with overlapping coverage. No installation spacing or RF range has been measured yet. A failed middle node requires an actual reachable alternate path; software cannot bridge a physical radio gap.

## Builds and flash package

From the workspace root:

```powershell
pio run -d ChickenChat/firmware/mesh_node -e repeater -e gateway
pio run -d 'Feeder Bin Bot' -e esp32dev-mesh -e fbb-production-pcb-mesh -e prototype-shield-mesh -e cluck-o-magic-mesh
```

The prepared release is under `ChickenChat/releases/mesh-2026-09-09/`. Its manifest includes hardware roles, offsets, sizes, and SHA-256 hashes. Choose the exact feeder board profile already used by that device; prototype profiles retain their existing hardware E-stop configuration. Do not substitute a generic repeater image for an operating controller.

`ChickenChat/tools/mesh/mesh_tool.py` includes `verify-release` and `flash` operations. Flash requires an explicit USB port and release role, validates the package, and invokes the installed Espressif flasher. It writes bootloader, partition table, OTA selection, and firmware without a whole-chip erase. This package targets the original ESP32, not ESP32-C3/S3/C6. The production gateway and repeater images were flashed and tested on two identified ESP32 boards on September 9, 2026. See HARDWARE-VALIDATION.md in the release package.

## Commissioning tool

Python 3.11+ and `pyserial` are required for USB operations. PlatformIO supplies the flasher; the collector uses the Python standard library.

The commissioning sequence is supported by these tool operations:

1. `status --port PORT` reads a flashed board's 16-digit `id`, configuration state, radio channel, Wi-Fi address, and delivery counters. Select the gateway board first.
2. `new-network --gateway-id ID --output ChickenChat/tools/mesh/farm.private.json --channel 6` generates random network credentials once. Existing network files are not overwritten.
3. `provision --port PORT --network FILE --name NAME --house HOUSE --zone ZONE --gateway` provisions the gateway and prompts locally for Wi-Fi credentials. The gateway ID must match this board's reported ID.
4. Use the same `provision` operation without `--gateway` for repeaters and mesh-enabled feeder/shaker builds. Optional `--analog-pin`, `--contact-pin`, `--interval-ms`, and `--leaf` select sensor inputs, sample interval, and forwarding. Feeder/shaker builds reject separate analog/contact pins to protect existing equipment pin assignments.
5. `collect --gateway URL --network FILE` runs the hub collector against the gateway's reported Wi-Fi address. Run from the workspace root for the default output paths. `--once` performs one batch. A continuously running collector and hub are required for continuous off-gateway storage.

Names, house IDs, and zones allow 1-24 letters, digits, spaces, underscores, or hyphens. Keep the private network file out of shared release packages. The gateway HTTP API uses the separate network-file token over the trusted farm LAN. It is not a public internet endpoint. Private remote access remains a hub/VPN responsibility.

The raw USB command protocol is newline-delimited JSON. `{ "op": "status" }` is read-only; `configure` validates all fields, saves them, acknowledges success, and reboots. Bad or oversized commands never replace the saved configuration. The provisioning tool does not toggle DTR/RTS to reset unknown serial devices during status reads.

## Diagnostics and acceptance

- Gateway: authenticated `GET /api/mesh/status`, `GET /api/mesh/events`, `POST /api/mesh/ack?id=...`, and `POST /api/mesh/ping?id=...`. Pass the `X-Chicken-Mesh-Token` header. Ping acceptance means queued; a confirmed count increase indicates the destination acknowledged it. Pong sender identity is also reported on gateway USB.
- Hub: `GET /api/mesh-nodes` reports per-node identity, house, zone, hop count, readings, and freshness. Old gateway records after a reboot have unknown original age and remain stale. Stopped collectors become stale after 30 seconds; node readings become stale after 90 seconds. The underlying SQLite database preserves all collected event identities for deduplication.
- Source: `confirmed`, `failed`, `pending`, `forwarded`, `queue_full`, `auth_failures`, and `rx_overflow` distinguish successful delivery from transmission attempts and resource limits.

Run `ChickenChat/tests/firmware_tests/mesh/run_tests.ps1` to compile and execute the actual C++ transport in a deterministic WebAssembly radio simulator, then test the collector and API. The test compiler must support WebAssembly (`CHICKEN_MESH_CLANG` can select it). These tests cover the routing engine and host data path; they do not emulate ESP32 RF, NVS, LittleFS power-failure behavior, or the Wi-Fi driver.

Before field acceptance, use at least five physical boards to force a source through three intermediate repeaters to a gateway; check hop counts and confirmed delivery, unplug the middle repeater with and without a reachable alternate, disconnect/reconnect the AP, and power-cycle the gateway with queued events. Then perform a 24-hour soak with house equipment operating. Two-board radio forwarding, end-to-end acknowledgments, gateway reboot retention, and production Wi-Fi collection passed. Multiple independent physical repeaters, installed range, interrupted-write power-loss durability, and field capacity remain unverified.
