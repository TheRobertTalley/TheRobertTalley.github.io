# Chicken Chat mesh firmware

Six firmware images for original ESP32 boards with 4 MB flash:

| Release role | Use |
| --- | --- |
| `repeater` | Dedicated repeater, repeater with ADC1/contact sensing, or sensor leaf |
| `gateway` | ESP32 within farm Wi-Fi coverage; forwards readings to the hub collector |
| `bin-commander-devkit` | Existing generic ESP32 feeder pin map, plus mesh telemetry |
| `bin-commander-production` | Existing production feeder PCB pin map, plus mesh telemetry |
| `bin-commander-prototype` | Existing prototype shield pin map, plus mesh telemetry |
| `cluck-o-magic-prototype` | Existing shaker prototype pin map, plus mesh telemetry |

The release is unprovisioned. It contains no farm radio keys, Wi-Fi passwords, or tokens. Existing feeder/shaker profiles keep their original hardware and safety configuration. Choose the matching board profile, not just a matching chip.

`manifest.json` contains flash offsets and SHA-256 hashes. `source-sha256.json` identifies the firmware source used. The included `mesh_tool.py` verifies every part before flashing and also provisions nodes and collects gateway data.

Run `python mesh_tool.py --help` for available operations. `verify-release --manifest manifest.json` checks the complete package without touching hardware. `flash --manifest manifest.json --role ROLE --port PORT` writes the selected image through Espressif's flasher, supplied by PlatformIO or the `esptool` Python package. USB provisioning requires `pyserial` from the included requirements file.

Full operating notes, commissioning sequence, pin restrictions, and field acceptance steps are in the workspace at `ChickenChat/firmware/mesh_node/README.md`, also copied here as `COMMISSIONING.md`.

Verified in software: ESP32 compilation, 18 C++ routing/codec scenarios, 12 collector/package tests, 18 dashboard/API regression files, and repository schema/fixture checks. The unchanged generic feeder build also compiles. Routing tests execute the shared C++ engine in a deterministic simulator and exercise chains, alternate paths, duplicates, losses, queue limits, reboot sessions, and eight-hop bounds.

Hardware verified September 9, 2026: 40/40 two-hop out-and-back probes using two physical ESP32s, no false delivery while the repeater was offline, recovery after restart, all 69 queued records retained through a gateway reboot, and live durable Wi-Fi collection. The exact production gateway and repeater images also passed live telemetry and acknowledgment checks. See HARDWARE-VALIDATION.md for the test scope and remaining field acceptance. The Wemos was returned to current TTS Maker firmware after testing.

The network carries telemetry, alarms, acknowledgments, and diagnostic probes. New mesh motor commands are not enabled. Existing local equipment control remains authoritative. The fixed-channel gateway uses the same 2.4 GHz channel as the mesh; choose channel 6 when including the existing feeder/shaker builds. General internet extension for phones or cameras is outside this firmware's scope.
