"""Provision Chicken Chat radios and durably collect gateway telemetry. Python 3.11+."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import secrets
import hashlib
import importlib.util
import subprocess
import sqlite3
import sys
import time
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

ID = re.compile(r"^[0-9a-f]{16}$")
EVENT_ID = re.compile(r"^[0-9a-f]{16}_[0-9a-f]{16}_[0-9a-f]{8}$")
LABEL = re.compile(r"^[A-Za-z0-9 _-]{1,24}$")


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    with temp.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def utc(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat().replace("+00:00", "Z")


def release_parts(manifest_path: Path, role: str) -> list[str]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("chip") != "esp32" or manifest.get("format") != 1:
        raise ValueError("Unsupported release manifest")
    entry = manifest.get("builds", {}).get(role)
    if not entry or len(entry.get("parts", [])) != 4:
        raise ValueError("Unknown release role")
    root = manifest_path.resolve().parent
    args = []
    for part, offset, limit in zip(entry["parts"], (0x1000, 0x8000, 0xe000, 0x10000), (0x7000, 0xc00, 0x2000, 0x140000)):
        path = (root / part["file"]).resolve()
        if not path.is_relative_to(root) or part["offset"] != offset:
            raise ValueError("Invalid release file path or offset")
        data = path.read_bytes()
        if not 0 < len(data) <= limit or len(data) != part["size"] or hashlib.sha256(data).hexdigest() != part["sha256"]:
            raise ValueError(f"Release verification failed: {path.name}")
        args.extend([hex(offset), str(path)])
    return args


def esptool_command() -> list[str]:
    if importlib.util.find_spec("esptool"):
        return [sys.executable, "-m", "esptool"]
    bundled = Path.home() / ".platformio/packages/tool-esptoolpy/esptool.py"
    if bundled.is_file():
        return [sys.executable, str(bundled)]
    raise ValueError("Install the esptool Python package or PlatformIO before flashing")


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("Gateway redirects are not allowed")


class Gateway:
    def __init__(self, url: str, token: str):
        parsed = urlsplit(url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Use the gateway's local HTTP(S) address")
        self.url = url.rstrip("/")
        self.token = token
        self.opener = build_opener(NoRedirect())

    def request(self, path: str, *, post: bool = False) -> dict:
        req = Request(self.url + path, data=b"" if post else None,
                      headers={"X-Chicken-Mesh-Token": self.token})
        with self.opener.open(req, timeout=5) as response:
            raw = response.read(65537)
        if len(raw) > 65536:
            raise ValueError("Gateway response exceeded limit")
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError("Invalid gateway response")
        return value


class Collector:
    def __init__(self, database: Path, snapshot: Path):
        database.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(database)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("""CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY, source TEXT NOT NULL, first_saved REAL NOT NULL,
            received_at REAL, body TEXT NOT NULL)""")
        self.db.execute("CREATE INDEX IF NOT EXISTS events_source ON events(source, received_at)")
        self.db.commit()
        self.snapshot = snapshot

    @staticmethod
    def validate(event: dict) -> None:
        if not isinstance(event, dict) or not EVENT_ID.fullmatch(str(event.get("id", ""))):
            raise ValueError("Invalid event identity")
        for field in ("source", "session", "gateway_session"):
            if not ID.fullmatch(str(event.get(field, ""))):
                raise ValueError(f"Invalid {field}")
        for field, lo, hi in (("sequence", 1, 0xffffffff), ("hops", 1, 8),
                              ("received_uptime_ms", 0, 0x1fffffffffffff), ("source_uptime_ms", 0, 0xffffffff)):
            if type(event.get(field)) is not int or not lo <= event[field] <= hi:
                raise ValueError(f"Invalid {field}")
        if event["id"] != f'{event["source"]}_{event["session"]}_{event["sequence"]:08x}':
            raise ValueError("Event identity does not match its fields")
        for field in ("node_name", "house_id", "zone_id"):
            if not LABEL.fullmatch(str(event.get(field, ""))):
                raise ValueError(f"Invalid {field}")
        if event.get("role") not in {"bin_commander", "cluck_o_magic", "repeater_sensor"}:
            raise ValueError("Invalid role")
        if "analog_raw" in event and (type(event["analog_raw"]) is not int or not 0 <= event["analog_raw"] <= 4095):
            raise ValueError("Invalid analog reading")
        for field in ("contact_closed", "relay1_on", "relay2_on", "emergency_stop", "fault", "feed_present"):
            if field in event and type(event[field]) is not bool:
                raise ValueError(f"Invalid {field}")
        if len(json.dumps(event, allow_nan=False)) > 2048:
            raise ValueError("Event too large")

    def poll(self, gateway: Gateway, now: float | None = None) -> int:
        now = time.time() if now is None else now
        batch = gateway.request("/api/mesh/events")
        session, uptime, events = batch.get("gateway_session"), batch.get("uptime_ms"), batch.get("events")
        if not ID.fullmatch(str(session)) or type(uptime) is not int or not 0 <= uptime <= 0x1fffffffffffff or not isinstance(events, list) or len(events) > 8:
            raise ValueError("Invalid gateway batch")
        for event in events:
            self.validate(event)
        with self.db:
            for event in events:
                # Gateway reboot destroys its monotonic time reference. Never invent freshness.
                age = (uptime - event["received_uptime_ms"]) / 1000
                received = now - age if event["gateway_session"] == session and 0 <= age < 86400 else None
                self.db.execute("INSERT OR IGNORE INTO events VALUES (?, ?, ?, ?, ?)",
                                (event["id"], event["source"], now, received,
                                 json.dumps(event, separators=(",", ":"), allow_nan=False)))
        # Commit and export before asking the gateway to release any durable records.
        self.export(now)
        for event in events:
            answer = gateway.request("/api/mesh/ack?" + urlencode({"id": event["id"]}), post=True)
            if answer.get("saved") is not True:
                raise ValueError("Gateway did not acknowledge spool release")
        return len(events)

    def export(self, now: float | None = None) -> None:
        now = time.time() if now is None else now
        rows = self.db.execute("""SELECT body, received_at, first_saved FROM (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY source ORDER BY
                received_at IS NOT NULL DESC, received_at DESC, first_saved DESC, id DESC) AS rank
            FROM events) WHERE rank = 1 ORDER BY source""")
        nodes = []
        for body, received, saved in rows:
            event = json.loads(body)
            event["received_at_utc"] = utc(received) if received is not None else None
            event["saved_at_utc"] = utc(saved)
            event["status"] = "online" if received is not None and 0 <= now - received <= 90 else "stale"
            nodes.append(event)
        atomic_json(self.snapshot, {"record_type": "mesh_nodes", "generated_at_utc": utc(now), "nodes": nodes})


def serial_request(port: str, request: dict, expected: str, timeout: float = 8) -> dict:
    import serial
    connection = serial.Serial()
    connection.port = port
    connection.baudrate = 115200
    connection.timeout = 0.25
    connection.dtr = False
    connection.rts = False
    connection.open()
    try:
        connection.reset_input_buffer()
        connection.write((json.dumps(request, separators=(",", ":")) + "\n").encode())
        connection.flush()
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                answer = json.loads(connection.readline().decode("utf-8", errors="replace"))
            except (ValueError, UnicodeError):
                continue
            if isinstance(answer, dict) and (expected in answer or "error" in answer):
                if "error" in answer:
                    raise ValueError(f'Device rejected request: {answer["error"]}')
                return answer
        raise TimeoutError("No Chicken Chat mesh response on this port")
    finally:
        connection.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    verify = commands.add_parser("verify-release")
    verify.add_argument("--manifest", type=Path, required=True)
    flash = commands.add_parser("flash")
    flash.add_argument("--manifest", type=Path, required=True)
    flash.add_argument("--role", required=True)
    flash.add_argument("--port", required=True)
    status = commands.add_parser("status")
    status.add_argument("--port", required=True)
    new = commands.add_parser("new-network")
    new.add_argument("--gateway-id", required=True)
    new.add_argument("--output", type=Path, required=True)
    new.add_argument("--channel", type=int, default=6, choices=range(1, 12))
    provision = commands.add_parser("provision")
    provision.add_argument("--port", required=True)
    provision.add_argument("--network", type=Path, required=True)
    provision.add_argument("--name", required=True)
    provision.add_argument("--house", required=True)
    provision.add_argument("--zone", required=True)
    provision.add_argument("--gateway", action="store_true")
    provision.add_argument("--leaf", action="store_true")
    provision.add_argument("--analog-pin", type=int, default=-1)
    provision.add_argument("--contact-pin", type=int, default=-1)
    provision.add_argument("--interval-ms", type=int, default=30000)
    collect = commands.add_parser("collect")
    collect.add_argument("--gateway", required=True)
    collect.add_argument("--network", type=Path, required=True)
    collect.add_argument("--database", type=Path, default=Path("ChickenChat/data/live/mesh.sqlite3"))
    collect.add_argument("--snapshot", type=Path, default=Path("ChickenChat/data/live/mesh_nodes.json"))
    collect.add_argument("--once", action="store_true")
    args = parser.parse_args()
    if args.command == "verify-release":
        manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
        for role in manifest["builds"]:
            release_parts(args.manifest, role)
            print(f"Verified {role}")
    elif args.command == "flash":
        parts = release_parts(args.manifest, args.role)
        subprocess.run(esptool_command() + ["--chip", "esp32", "--port", args.port, "--baud", "115200",
                       "--before", "default_reset", "--after", "hard_reset", "write_flash",
                       "--flash_mode", "dio", "--flash_freq", "40m", "--flash_size", "4MB"] + parts, check=True)
    elif args.command == "status":
        print(json.dumps(serial_request(args.port, {"op": "status"}, "id"), indent=2))
    elif args.command == "new-network":
        if not ID.fullmatch(args.gateway_id) or int(args.gateway_id, 16) == 0:
            raise ValueError("Gateway ID must be the 16-digit ID reported by its firmware")
        if args.output.exists():
            raise ValueError("Network file already exists; refusing to replace its keys")
        atomic_json(args.output, {"network": secrets.randbelow(0x7ffffffe) + 1, "gateway": args.gateway_id,
                                 "channel": args.channel, "key": secrets.token_hex(32), "token": secrets.token_hex(32)})
        print(f"Network credentials saved to {args.output}; keep this file private.")
    elif args.command == "provision":
        import getpass
        net = json.loads(args.network.read_text(encoding="utf-8"))
        for value in (args.name, args.house, args.zone):
            if not LABEL.fullmatch(value):
                raise ValueError("Names must use 1-24 letters, digits, spaces, underscores, or hyphens")
        command = {"op": "configure", **{key: net[key] for key in ("network", "gateway", "channel", "key")},
                   "name": args.name, "house": args.house, "zone": args.zone, "forward": not args.leaf,
                   "analog_pin": args.analog_pin, "contact_pin": args.contact_pin, "interval_ms": args.interval_ms,
                   "ssid": "", "password": "", "token": net["token"] if args.gateway else ""}
        if args.gateway:
            command["ssid"] = input("Farm Wi-Fi name: ")
            command["password"] = getpass.getpass("Farm Wi-Fi password: ")
        print(json.dumps(serial_request(args.port, command, "saved")))
    elif args.command == "collect":
        net = json.loads(args.network.read_text(encoding="utf-8"))
        gateway = Gateway(args.gateway, net["token"])
        collector = Collector(args.database, args.snapshot)
        try:
            while True:
                count = 0
                try:
                    count = collector.poll(gateway)
                    if count or args.once:
                        print(f"Saved {count} gateway records.", flush=True)
                except Exception as error:
                    collector.export()
                    if args.once:
                        raise
                    print(f"Gateway unavailable: {type(error).__name__}. Retrying.", file=sys.stderr, flush=True)
                if args.once:
                    break
                time.sleep(2 if count else 5)
        finally:
            collector.db.close()


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TimeoutError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
