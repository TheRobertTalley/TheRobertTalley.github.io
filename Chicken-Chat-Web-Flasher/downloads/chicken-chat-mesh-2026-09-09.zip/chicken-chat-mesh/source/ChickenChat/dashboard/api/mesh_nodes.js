const fs = require('node:fs/promises');

async function readMeshNodes(filePath, now = Date.now()) {
  let data;
  try { data = JSON.parse(await fs.readFile(filePath, 'utf8')); }
  catch (error) {
    if (error.code === 'ENOENT') return {record_type: 'mesh_nodes', status: 'unavailable', nodes: []};
    throw error;
  }
  if (data.record_type !== 'mesh_nodes' || !Array.isArray(data.nodes)) throw new Error('Invalid mesh snapshot');
  const generated = Date.parse(data.generated_at_utc);
  const collectorCurrent = Number.isFinite(generated) && now >= generated && now - generated <= 30000;
  return {
    ...data,
    status: collectorCurrent ? 'online' : 'stale',
    nodes: data.nodes.map(node => {
      const received = Date.parse(node.received_at_utc);
      return {...node, status: collectorCurrent && Number.isFinite(received) && now >= received && now - received <= 90000 ? 'online' : 'stale'};
    }),
  };
}
module.exports = {readMeshNodes};
