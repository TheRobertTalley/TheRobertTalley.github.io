#include "ChickenMeshRadio.h"
chickenmesh::Radio *chickenmesh::Radio::owner_ = nullptr;
