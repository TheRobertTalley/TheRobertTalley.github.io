#pragma once
#include <Arduino.h>
#include <Preferences.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_system.h>
#include <mbedtls/gcm.h>
#include <cJSON.h>
#include <atomic>
#include "MeshCore.h"

namespace chickenmesh {
inline bool allowedPin(int pin, bool analog);
struct Config {
  uint32_t version = 1, network = 0;
  uint64_t gateway = 0;
  uint8_t key[32] = {};
  uint8_t channel = 6;
  bool forward = true;
  int8_t analogPin = -1, contactPin = -1;
  uint32_t intervalMs = 30000;
  char name[25] = {}, house[25] = {}, zone[25] = {};
  char ssid[33] = {}, password[64] = {}, token[65] = {};
  bool load() {
    Preferences p;
    if (!p.begin("chickenmesh", true)) return false;
    bool ok = p.getBytesLength("config") == sizeof(*this) && p.getBytes("config", this, sizeof(*this)) == sizeof(*this);
    p.end();
    if (!ok || version != 1 || !network || !gateway || channel < 1 || channel > 11 ||
        intervalMs < 10000 || intervalMs > 3600000 || !allowedPin(analogPin, true) ||
        !allowedPin(contactPin, false) || (analogPin >= 0 && analogPin == contactPin)) return false;
    return memchr(name, 0, sizeof(name)) && memchr(house, 0, sizeof(house)) &&
      memchr(zone, 0, sizeof(zone)) && memchr(ssid, 0, sizeof(ssid)) &&
      memchr(password, 0, sizeof(password)) && memchr(token, 0, sizeof(token));
  }
  bool save() const {
    Preferences p; if (!p.begin("chickenmesh", false)) return false;
    bool ok = p.putBytes("config", this, sizeof(*this)) == sizeof(*this); p.end(); return ok;
  }
};
inline String hexId(uint64_t id) {
  char out[17]; snprintf(out, sizeof(out), "%016llx", (unsigned long long)id); return String(out);
}
inline bool fromHex(const char *s, uint8_t *out, size_t bytes) {
  if (!s || strlen(s) != bytes * 2) return false;
  for (size_t i = 0; i < bytes; ++i) {
    unsigned v = 0;
    for (int j = 0; j < 2; ++j) {
      char c = s[i * 2 + j]; unsigned n;
      if (c >= '0' && c <= '9') n = c - '0';
      else if (c >= 'a' && c <= 'f') n = c - 'a' + 10;
      else if (c >= 'A' && c <= 'F') n = c - 'A' + 10;
      else return false;
      v = v * 16 + n;
    }
    out[i] = uint8_t(v);
  }
  return true;
}
inline const char *str(const cJSON *o, const char *key) {
  const cJSON *v = cJSON_GetObjectItemCaseSensitive(o, key);
  return cJSON_IsString(v) ? v->valuestring : nullptr;
}
inline bool textField(const cJSON *o, const char *key, char *out, size_t cap, bool label = false) {
  const char *s = str(o, key); if (!s || strlen(s) >= cap) return false;
  if (label) {
    if (!*s) return false;
    for (const char *p = s; *p; ++p)
      if (!isalnum((unsigned char)*p) && *p != '-' && *p != '_' && *p != ' ') return false;
  }
  strcpy(out, s); return true;
}
inline bool number(const cJSON *o, const char *key, int lo, int hi, int &out) {
  auto v = cJSON_GetObjectItemCaseSensitive(o, key);
  if (!cJSON_IsNumber(v) || v->valuedouble < lo || v->valuedouble > hi || v->valuedouble != v->valueint) return false;
  out = v->valueint; return true;
}
// Pins intentionally limited to safe ADC1/input pins on the standard ESP32 target.
inline bool allowedPin(int pin, bool analog) {
  if (pin == -1) return true;
  if (analog) return pin == 32 || pin == 33 || pin == 34 || pin == 35 || pin == 36 || pin == 39;
  return pin == 18 || pin == 19 || pin == 21 || pin == 22 || pin == 23 || pin == 25 || pin == 26 || pin == 27 || pin == 32 || pin == 33;
}
inline bool parseConfig(const cJSON *o, Config &c) {
  int channel, net, analog, contact, interval;
  uint8_t gateway[8];
  if (!number(o, "network", 1, INT32_MAX, net) || !number(o, "channel", 1, 11, channel) ||
      !number(o, "analog_pin", -1, 39, analog) || !allowedPin(analog, true) ||
      !number(o, "contact_pin", -1, 33, contact) || !allowedPin(contact, false) ||
      (analog >= 0 && analog == contact) || !number(o, "interval_ms", 10000, 3600000, interval) ||
      !fromHex(str(o, "gateway"), gateway, 8) || !fromHex(str(o, "key"), c.key, 32) ||
      !textField(o, "name", c.name, sizeof(c.name), true) ||
      !textField(o, "house", c.house, sizeof(c.house), true) ||
      !textField(o, "zone", c.zone, sizeof(c.zone), true) ||
      !textField(o, "ssid", c.ssid, sizeof(c.ssid)) || !textField(o, "password", c.password, sizeof(c.password)) ||
      !textField(o, "token", c.token, sizeof(c.token))) return false;
  auto forwarding = cJSON_GetObjectItemCaseSensitive(o, "forward");
  if (!cJSON_IsBool(forwarding)) return false;
  c.gateway = 0; for (uint8_t b : gateway) c.gateway = (c.gateway << 8) | b;
  bool nonzero = false; for (uint8_t b : c.key) nonzero |= b != 0;
  if (!c.gateway || !nonzero) return false;
  c.network = net; c.channel = channel; c.forward = cJSON_IsTrue(forwarding);
  c.analogPin = analog; c.contactPin = contact; c.intervalMs = interval;
  return true;
}

class Radio : public IO {
 public:
  using Receiver = bool (*)(const Frame &);
  Config config;
  uint64_t id = 0, session = 0;
  Core *core = nullptr;
  uint32_t authFailures = 0, radioFailures = 0, lastRxMs = 0;
  std::atomic<uint32_t> rxOverflow{0};
  bool configured = false;
 private:
  struct Packet { uint8_t data[250]; uint16_t size; };
  QueueHandle_t rx_ = nullptr;
  Receiver receiver_ = nullptr;
  mbedtls_gcm_context crypto_;
  uint32_t lastSend_ = 0;
  String line_;
  bool lineOverflow_ = false;
  static Radio *owner_;
  static void receiveCallback(const uint8_t *, const uint8_t *data, int len) {
    if (owner_) owner_->accept(data, len);
  }
  bool ensureBroadcastPeer() {
    wifi_mode_t mode;
    if (esp_wifi_get_mode(&mode) != ESP_OK || mode == WIFI_MODE_NULL) return false;
    wifi_interface_t interface = mode == WIFI_MODE_AP ? WIFI_IF_AP : WIFI_IF_STA;
    uint8_t broadcast[6]; memset(broadcast, 0xff, sizeof(broadcast));
    esp_now_peer_info_t peer = {};
    if (esp_now_get_peer(broadcast, &peer) == ESP_OK) {
      if (peer.ifidx == interface && peer.channel == 0) return true;
      peer.ifidx = interface; peer.channel = 0;
      return esp_now_mod_peer(&peer) == ESP_OK;
    }
    memcpy(peer.peer_addr, broadcast, 6); peer.ifidx = interface; peer.channel = 0;
    return esp_now_add_peer(&peer) == ESP_OK;
  }
 public:
  Radio() { mbedtls_gcm_init(&crypto_); }
  bool load() {
    id = ESP.getEfuseMac();
    esp_fill_random(&session, sizeof(session)); if (!session) session = 1;
    configured = config.load(); return configured;
  }
  bool begin(Receiver receiver, bool own = true) {
    if (!configured) return false;
    receiver_ = receiver;
    if (!core) core = new Core(*this, id, session, config.forward);
    if (!rx_) rx_ = xQueueCreate(32, sizeof(Packet));
    mbedtls_gcm_free(&crypto_); mbedtls_gcm_init(&crypto_);
    if (!core || !rx_ || mbedtls_gcm_setkey(&crypto_, MBEDTLS_CIPHER_ID_AES, config.key, 256)) return false;
    if (own) {
      esp_now_deinit();
      if (esp_now_init() != ESP_OK) return false;
      owner_ = this;
      if (esp_now_register_recv_cb(receiveCallback) != ESP_OK) return false;
    }
    return ensureBroadcastPeer();
  }
  // Safe to call from the existing feeder's radio callback; never steals legacy packets.
  bool accept(const uint8_t *data, int len) {
    if (!data || len < 2 || data[0] != 0xcc || data[1] != 0x4d) return false;
    if (!rx_ || len > 250 || len < 35 + int(HeaderSize)) return true;
    Packet p; p.size = len; memcpy(p.data, data, len);
    if (xQueueSend(rx_, &p, 0) != pdTRUE) ++rxOverflow;
    return true;
  }
  bool transmit(const Frame &f) override {
    uint32_t now = millis(); if (uint32_t(now - lastSend_) < 25) return false;
    // Do not transmit on a mismatched channel, including during Wi-Fi reconnects.
    uint8_t channel; wifi_second_chan_t second;
    if (esp_wifi_get_channel(&channel, &second) != ESP_OK || channel != config.channel) return false;
    if (!ensureBroadcastPeer()) { ++radioFailures; return false; }
    uint8_t plain[PlainMax], wire[250]; size_t n = encode(f, plain); if (!n) return true;
    wire[0] = 0xcc; wire[1] = 0x4d; wire[2] = 1; put(wire + 3, config.network, 4);
    esp_fill_random(wire + 7, 12);
    if (mbedtls_gcm_crypt_and_tag(&crypto_, MBEDTLS_GCM_ENCRYPT, n, wire + 7, 12,
        wire, 19, plain, wire + 19, 16, wire + 19 + n)) { ++radioFailures; return false; }
    static const uint8_t broadcast[6] = {255,255,255,255,255,255};
    lastSend_ = now;
    if (esp_now_send(broadcast, wire, n + 35) != ESP_OK) { ++radioFailures; return false; }
    return true;
  }
  bool deliver(const Frame &f) override { return receiver_ && receiver_(f); }
  void tick() {
    if (!core || !rx_) return;
    Packet p;
    for (int i = 0; i < 8 && xQueueReceive(rx_, &p, 0) == pdTRUE; ++i) {
      size_t n = p.size - 35; uint8_t plain[PlainMax]; Frame f;
      if (n > PlainMax || p.data[2] != 1 || get(p.data + 3, 4) != config.network ||
          mbedtls_gcm_auth_decrypt(&crypto_, n, p.data + 7, 12, p.data, 19,
            p.data + 19 + n, 16, p.data + 19, plain) || !decode(plain, n, f)) {
        ++authFailures; continue;
      }
      lastRxMs = millis(); core->receive(f, millis());
    }
    core->tick(millis());
  }
  bool publish(const String &json) {
    return core && core->publish(config.gateway, (const uint8_t *)json.c_str(), json.length(), millis());
  }
  String status() const {
    String s = "{\"id\":\"" + hexId(id) + "\",\"configured\":" + (configured ? "true" : "false");
    s += ",\"firmware\":\"cc-mesh-2026.09.09\"";
    s += ",\"session\":\"" + hexId(session) + "\",\"channel\":" + String(config.channel);
    s += ",\"wifi_connected\":" + String(WiFi.status() == WL_CONNECTED ? "true" : "false");
    s += ",\"wifi_ip\":\"" + WiFi.localIP().toString() + "\"";
    uint8_t current = 0; wifi_second_chan_t second;
    esp_wifi_get_channel(&current, &second);
    s += ",\"radio_channel\":" + String(current);
    s += ",\"auth_failures\":" + String(authFailures) + ",\"rx_overflow\":" + String(rxOverflow.load());
    s += ",\"radio_failures\":" + String(radioFailures);
    if (core) {
      auto &st = core->stats;
      s += ",\"received\":" + String(st.received) + ",\"forwarded\":" + String(st.forwarded);
      s += ",\"confirmed\":" + String(st.confirmed) + ",\"failed\":" + String(st.failed);
      s += ",\"queue_full\":" + String(st.queueFull) + ",\"pending\":" + String(core->pending());
      s += ",\"rejected\":" + String(st.rejected) + ",\"duplicates\":" + String(st.duplicates);
    }
    return s + "}";
  }
  // USB-only provisioning. Secrets are never returned in status or echoed.
  // Firmware role validation is supplied by the caller before persisting a new config.
  void console(bool (*validate)(const Config &) = nullptr, bool (*extra)(const cJSON *) = nullptr) {
    for (int i = 0; i < 128 && Serial.available(); ++i) {
      char c = Serial.read();
      if (c == '\r') continue;
      if (c != '\n') {
        if (line_.length() < 1200 && !lineOverflow_) line_ += c;
        else lineOverflow_ = true;
        continue;
      }
      if (lineOverflow_) { Serial.println("{\"error\":\"line_too_long\"}"); line_ = ""; lineOverflow_ = false; continue; }
      cJSON *o = cJSON_Parse(line_.c_str()); line_ = "";
      const char *op = o ? str(o, "op") : nullptr;
      if (op && !strcmp(op, "status")) Serial.println(status());
      else if (op && !strcmp(op, "configure")) {
        Config next;
        if (!parseConfig(o, next) || (validate && !validate(next))) Serial.println("{\"error\":\"invalid_config\"}");
        else if (!next.save()) Serial.println("{\"error\":\"storage_failed\"}");
        else { Serial.println("{\"saved\":true}"); Serial.flush(); delay(50); ESP.restart(); }
      } else if (!extra || !extra(o)) Serial.println("{\"error\":\"unknown_operation\"}");
      cJSON_Delete(o);
    }
  }
};
} // namespace chickenmesh
