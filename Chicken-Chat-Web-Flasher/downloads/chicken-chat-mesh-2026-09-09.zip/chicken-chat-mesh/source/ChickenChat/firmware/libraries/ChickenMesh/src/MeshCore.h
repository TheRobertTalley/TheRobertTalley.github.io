#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

namespace chickenmesh {
constexpr size_t PayloadMax = 144;
constexpr uint8_t MaxHops = 8;
constexpr size_t HeaderSize = 33;
constexpr size_t PlainMax = HeaderSize + PayloadMax;
enum Type : uint8_t { Telemetry = 1, Ack = 2, Ping = 3, Pong = 4, Alarm = 5 };
struct Frame {
  uint64_t source = 0, destination = 0, session = 0;
  uint32_t sequence = 0;
  uint8_t type = 0, attempt = 0, ttl = MaxHops, hops = 0, length = 0;
  uint8_t payload[PayloadMax] = {};
};
inline void put(uint8_t *p, uint64_t v, size_t n) {
  for (size_t i = 0; i < n; ++i) p[i] = uint8_t(v >> (i * 8));
}
inline uint64_t get(const uint8_t *p, size_t n) {
  uint64_t v = 0;
  for (size_t i = 0; i < n; ++i) v |= uint64_t(p[i]) << (i * 8);
  return v;
}
inline bool valid(const Frame &f) {
  return f.source && f.destination && f.session && f.sequence &&
    f.type >= Telemetry && f.type <= Alarm && f.length <= PayloadMax &&
    f.attempt <= 4 && f.ttl >= 1 && f.ttl <= MaxHops &&
    f.hops < MaxHops && f.ttl + f.hops == MaxHops &&
    (f.type != Ack || f.length == 12) &&
    ((f.type != Ping && f.type != Pong) || f.length == 0);
}
inline size_t encode(const Frame &f, uint8_t *p) {
  if (!valid(f)) return 0;
  p[0] = f.type; put(p + 1, f.source, 8); put(p + 9, f.destination, 8);
  put(p + 17, f.session, 8); put(p + 25, f.sequence, 4);
  p[29] = f.attempt; p[30] = f.ttl; p[31] = f.hops; p[32] = f.length;
  memcpy(p + HeaderSize, f.payload, f.length);
  return HeaderSize + f.length;
}
inline bool decode(const uint8_t *p, size_t n, Frame &f) {
  if (n < HeaderSize || n > PlainMax || n != HeaderSize + p[32]) return false;
  f.type = p[0]; f.source = get(p + 1, 8); f.destination = get(p + 9, 8);
  f.session = get(p + 17, 8); f.sequence = uint32_t(get(p + 25, 4));
  f.attempt = p[29]; f.ttl = p[30]; f.hops = p[31]; f.length = p[32];
  memcpy(f.payload, p + HeaderSize, f.length);
  return valid(f);
}
inline bool due(uint32_t now, uint32_t when) { return int32_t(now - when) >= 0; }
struct Stats {
  uint32_t received = 0, sent = 0, forwarded = 0, duplicates = 0,
    delivered = 0, confirmed = 0, failed = 0, queueFull = 0, rejected = 0;
};
class IO {
 public:
  virtual bool transmit(const Frame &) = 0;
  // Return true only after the application has accepted responsibility for this record.
  virtual bool deliver(const Frame &) = 0;
  virtual ~IO() = default;
};
class Core {
  struct Seen {
    uint64_t source = 0, session = 0;
    uint32_t sequence = 0, at = 0;
    uint8_t attempt = 0, hops = 0;
  } seen_[192];
  struct Tx { Frame frame; uint32_t at = 0, expires = 0; bool used = false; } tx_[24];
  struct Pending { Frame frame; uint32_t at = 0, expires = 0; bool used = false; } pending_[8];
  IO &io_;
  uint64_t id_, session_;
  uint32_t seq_ = 0;
  size_t seenCursor_ = 0;
  bool forwarding_;
  static bool same(const Frame &f, const Seen &s) {
    return f.source == s.source && f.session == s.session && f.sequence == s.sequence;
  }
  bool remembered(const Frame &f, uint32_t now, bool anyAttempt) const {
    for (const auto &s : seen_)
      if (uint32_t(now - s.at) < 60000 && same(f, s) &&
          (anyAttempt || (f.attempt == s.attempt && f.hops >= s.hops))) return true;
    return false;
  }
  void remember(const Frame &f, uint32_t now) {
    Seen &s = seen_[seenCursor_++ % 192];
    s.source = f.source; s.session = f.session; s.sequence = f.sequence;
    s.attempt = f.attempt; s.hops = f.hops; s.at = now;
  }
  bool enqueue(const Frame &f, uint32_t now) {
    // Reserve four slots for acknowledgments and probes under telemetry pressure.
    size_t start = (f.type == Telemetry) ? 4 : 0;
    for (size_t i = start; i < 24; ++i) if (!tx_[i].used) {
      tx_[i].frame = f;
      tx_[i].at = now + 20 + uint32_t((id_ ^ f.source ^ f.sequence * 2654435761UL ^ f.attempt * 7919UL) % 81);
      tx_[i].expires = now + 2000;
      tx_[i].used = true;
      return true;
    }
    ++stats.queueFull;
    return false;
  }
  Frame make(uint8_t type, uint64_t destination) {
    Frame f; f.type = type; f.source = id_; f.destination = destination; f.session = session_;
    // Never reuse an identity in a boot session, even on sequence exhaustion.
    if (seq_ != UINT32_MAX) f.sequence = ++seq_;
    return f;
  }
  void acknowledge(const Frame &f, uint32_t now) {
    Frame a = make(Ack, f.source); a.length = 12;
    put(a.payload, f.session, 8); put(a.payload + 8, f.sequence, 4);
    if (a.sequence) enqueue(a, now);
  }
 public:
  Stats stats;
  Core(IO &io, uint64_t id, uint64_t session, bool forwarding = true)
    : io_(io), id_(id), session_(session), forwarding_(forwarding) {}
  size_t pending() const { size_t n = 0; for (const auto &p : pending_) n += p.used; return n; }
  bool publish(uint64_t destination, const uint8_t *data, size_t size, uint32_t now, uint8_t type = Telemetry) {
    if (!destination || destination == id_ || size > PayloadMax || (size && !data) ||
        (type != Telemetry && type != Alarm && type != Ping) || (type == Ping && size)) return false;
    for (auto &p : pending_) if (!p.used) {
      p.frame = make(type, destination);
      if (!p.frame.sequence) return false;
      p.frame.length = uint8_t(size); if (size) memcpy(p.frame.payload, data, size);
      if (!enqueue(p.frame, now)) return false;
      p.at = now + 2500; p.expires = now + 30000; p.used = true;
      return true;
    }
    ++stats.queueFull;
    return false;
  }
  void receive(const Frame &f, uint32_t now) {
    if (!valid(f)) { ++stats.rejected; return; }
    if (f.source == id_) return;
    ++stats.received;
    if (f.destination == id_) {
      if (f.type == Ack) {
        for (auto &p : pending_) if (p.used && f.source == p.frame.destination &&
          get(f.payload, 8) == session_ && get(f.payload + 8, 4) == p.frame.sequence) {
          p.used = false; ++stats.confirmed;
        }
        return;
      }
      if (remembered(f, now, true)) { ++stats.duplicates; acknowledge(f, now); return; }
      if (f.type == Ping) {
        Frame pong = make(Pong, f.source);
        if (pong.sequence) enqueue(pong, now);
      } else if (!io_.deliver(f)) { ++stats.rejected; return; }
      remember(f, now); ++stats.delivered;
      if (f.type != Pong) acknowledge(f, now);
      return;
    }
    if (!forwarding_ || f.ttl <= 1) return;
    if (remembered(f, now, false)) { ++stats.duplicates; return; }
    Frame next = f; --next.ttl; ++next.hops;
    if (enqueue(next, now)) { remember(f, now); ++stats.forwarded; }
  }
  void tick(uint32_t now) {
    for (auto &t : tx_) if (t.used && due(now, t.expires)) { t.used = false; ++stats.queueFull; }
    for (auto &p : pending_) if (p.used && due(now, p.expires)) { p.used = false; ++stats.failed; }
    for (auto &p : pending_) if (p.used && due(now, p.at)) {
      if (p.frame.attempt == 4) { p.used = false; ++stats.failed; continue; }
      Frame retry = p.frame; ++retry.attempt;
      if (enqueue(retry, now)) { p.frame = retry; p.at = now + 2500 + retry.attempt * 1500; }
      else p.at = now + 200;
    }
    // One send per tick, prioritizing ACKs. Radio adapter applies pacing as well.
    for (int priority = 0; priority < 2; ++priority)
      for (auto &t : tx_) if (t.used && due(now, t.at) && ((t.frame.type != Telemetry) == (priority == 0))) {
        if (io_.transmit(t.frame)) { t.used = false; ++stats.sent; }
        else t.at = now + 50;
        return;
      }
  }
};
} // namespace chickenmesh
