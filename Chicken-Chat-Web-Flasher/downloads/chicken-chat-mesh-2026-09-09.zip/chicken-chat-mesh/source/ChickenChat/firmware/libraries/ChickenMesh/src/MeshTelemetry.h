#pragma once
#include "MeshCore.h"
namespace chickenmesh {
constexpr size_t TelemetrySize = 87;
struct Reading {
  uint8_t role = 0; // 0 repeater/sensor, 1 Bin Commander, 2 Cluck-o-Magic
  uint32_t uptime = 0;
  bool hasAnalog = false, hasContact = false, contact = false;
  uint16_t analog = 0;
  // Feeder flags: relay1, relay2, E-stop, fault, feed present (bits 0..4).
  uint8_t feederFlags = 0;
  char name[25] = {}, house[25] = {}, zone[25] = {};
};
inline bool labelValid(const char *s) {
  bool ended = false;
  for (size_t i = 0; i < 25; ++i) {
    unsigned char c = s[i]; if (!c) { ended = true; break; }
    if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
      (c >= '0' && c <= '9') || c == '-' || c == '_' || c == ' ')) return false;
  }
  return ended && s[0];
}
inline bool encodeReading(const Reading &r, uint8_t *p) {
  if (r.role > 2 || r.analog > 4095 || r.feederFlags > 31 ||
      !labelValid(r.name) || !labelValid(r.house) || !labelValid(r.zone)) return false;
  p[0] = 1; p[1] = r.role; put(p + 2, r.uptime, 4); p[6] = r.hasAnalog;
  put(p + 7, r.analog, 2); p[9] = r.hasContact; p[10] = r.contact; p[11] = r.feederFlags;
  memcpy(p + 12, r.name, 25); memcpy(p + 37, r.house, 25); memcpy(p + 62, r.zone, 25);
  return true;
}
inline bool decodeReading(const uint8_t *p, size_t n, Reading &r) {
  if (n != TelemetrySize || p[0] != 1 || p[1] > 2 || p[6] > 1 || p[9] > 1 || p[10] > 1 || p[11] > 31) return false;
  r.role = p[1]; r.uptime = uint32_t(get(p + 2, 4)); r.hasAnalog = p[6];
  r.analog = uint16_t(get(p + 7, 2)); r.hasContact = p[9]; r.contact = p[10]; r.feederFlags = p[11];
  memcpy(r.name, p + 12, 25); memcpy(r.house, p + 37, 25); memcpy(r.zone, p + 62, 25);
  return r.analog <= 4095 && labelValid(r.name) && labelValid(r.house) && labelValid(r.zone);
}
} // namespace chickenmesh
