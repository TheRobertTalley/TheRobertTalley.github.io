#include <Arduino.h>
#include <LittleFS.h>
#include <WebServer.h>
#include <ChickenMeshRadio.h>
#include <MeshTelemetry.h>
#include <esp_timer.h>

using namespace chickenmesh;
namespace {
Radio mesh;
WebServer server(80);
bool ready = false, storageReady = false, channelMismatch = false, configReady = false;
uint32_t lastSample = 0, lastWifiTry = 0, wifiAttemptAt = 0;
uint32_t lastInitTry = 0;
uint32_t spoolFull = 0, spoolErrors = 0;
bool wifiAttempt = false;
size_t spoolCount = 0;
constexpr size_t SpoolLimit = 256;

String recordId(const Frame &f) {
  char seq[9]; snprintf(seq, sizeof(seq), "%08lx", (unsigned long)f.sequence);
  return hexId(f.source) + "_" + hexId(f.session) + "_" + seq;
}
bool validRecordId(const String &id) {
  if (id.length() != 42 || id[16] != '_' || id[33] != '_') return false;
  for (size_t i = 0; i < id.length(); ++i)
    if (i != 16 && i != 33 && !isxdigit((unsigned char)id[i])) return false;
  return true;
}
bool validateRole(const Config &c) {
#if CC_GATEWAY
  uint8_t token[32];
  return c.gateway == mesh.id && c.ssid[0] && fromHex(c.token, token, 32) && c.forward && c.analogPin == -1 && c.contactPin == -1;
#else
  return c.gateway != mesh.id && !c.ssid[0] && !c.password[0] && !c.token[0];
#endif
}
String eventJson(const Frame &f, const Reading &r) {
  cJSON *o = cJSON_CreateObject();
  cJSON_AddStringToObject(o, "id", recordId(f).c_str());
  cJSON_AddStringToObject(o, "source", hexId(f.source).c_str());
  cJSON_AddStringToObject(o, "session", hexId(f.session).c_str());
  cJSON_AddNumberToObject(o, "sequence", f.sequence);
  cJSON_AddNumberToObject(o, "hops", f.hops + 1);
  cJSON_AddStringToObject(o, "priority", f.type == Alarm ? "alarm" : "routine");
  cJSON_AddStringToObject(o, "gateway_session", hexId(mesh.session).c_str());
  cJSON_AddNumberToObject(o, "received_uptime_ms", esp_timer_get_time() / 1000);
  cJSON_AddNumberToObject(o, "source_uptime_ms", r.uptime);
  cJSON_AddStringToObject(o, "node_name", r.name);
  cJSON_AddStringToObject(o, "house_id", r.house);
  cJSON_AddStringToObject(o, "zone_id", r.zone);
  cJSON_AddStringToObject(o, "role", r.role == 1 ? "bin_commander" : r.role == 2 ? "cluck_o_magic" : "repeater_sensor");
  if (r.hasAnalog) cJSON_AddNumberToObject(o, "analog_raw", r.analog);
  if (r.hasContact) cJSON_AddBoolToObject(o, "contact_closed", r.contact);
  if (r.role) {
    cJSON_AddBoolToObject(o, "relay1_on", r.feederFlags & 1);
    cJSON_AddBoolToObject(o, "relay2_on", r.feederFlags & 2);
    cJSON_AddBoolToObject(o, "emergency_stop", r.feederFlags & 4);
    cJSON_AddBoolToObject(o, "fault", r.feederFlags & 8);
    cJSON_AddBoolToObject(o, "feed_present", r.feederFlags & 16);
  }
  char *text = cJSON_PrintUnformatted(o); String result = text ? text : "";
  cJSON_free(text); cJSON_Delete(o); return result;
}
bool delivered(const Frame &f) {
  if (f.type == Pong) { Serial.println("{\"pong_from\":\"" + hexId(f.source) + "\"}"); return true; }
#if CC_GATEWAY
  Reading r;
  if (!storageReady || !decodeReading(f.payload, f.length, r)) return false;
  String path = "/spool/" + recordId(f) + ".json";
  if (LittleFS.exists(path)) return true;
  if (spoolCount >= SpoolLimit || (f.type != Alarm && spoolCount >= SpoolLimit - 32)) { ++spoolFull; return false; }
  String json = eventJson(f, r);
  if (!json.length()) { ++spoolErrors; return false; }
  File file = LittleFS.open("/pending.tmp", FILE_WRITE);
  bool ok = file && file.print(json) == json.length();
  if (file) { file.flush(); file.close(); }
  if (!ok || !LittleFS.rename("/pending.tmp", path)) { ++spoolErrors; return false; }
  ++spoolCount;
  return true; // Only ACK after the durable spool has accepted the record.
#else
  return false;
#endif
}
bool authorized() {
  if (server.header("X-Chicken-Mesh-Token") == mesh.config.token) return true;
  server.send(401, "application/json", "{\"error\":\"unauthorized\"}"); return false;
}
void setupApi() {
  const char *headers[] = {"X-Chicken-Mesh-Token"}; server.collectHeaders(headers, 1);
  server.on("/api/mesh/status", HTTP_GET, [] {
    if (!authorized()) return;
    String s = mesh.status(); s.remove(s.length() - 1);
    s += ",\"spool_count\":" + String(spoolCount) + ",\"spool_full\":" + String(spoolFull);
    s += ",\"spool_errors\":" + String(spoolErrors) + ",\"storage_ready\":" + (storageReady ? "true" : "false");
    s += ",\"channel_mismatch\":" + String(channelMismatch ? "true" : "false");
    server.send(200, "application/json", s + "}");
  });
  server.on("/api/mesh/events", HTTP_GET, [] {
    if (!authorized()) return;
    if (!storageReady) { server.send(503, "application/json", "{\"error\":\"storage_unavailable\"}"); return; }
    char uptime[24]; snprintf(uptime, sizeof(uptime), "%llu", (unsigned long long)(esp_timer_get_time() / 1000));
    String body = "{\"gateway_session\":\"" + hexId(mesh.session) + "\",\"uptime_ms\":" + uptime + ",\"events\":[";
    File dir = LittleFS.open("/spool"); File f = dir.openNextFile(); size_t count = 0;
    while (f && count < 8) {
      if (!f.isDirectory()) { if (count++) body += ','; body += f.readString(); }
      f.close(); f = dir.openNextFile();
    }
    f.close(); dir.close();
    server.send(200, "application/json", body + "]}");
  });
  server.on("/api/mesh/ack", HTTP_POST, [] {
    if (!authorized()) return;
    String id = server.arg("id");
    if (!validRecordId(id)) { server.send(400, "application/json", "{\"error\":\"invalid_id\"}"); return; }
    String path = "/spool/" + id + ".json";
    if (LittleFS.exists(path)) {
      if (!LittleFS.remove(path)) { server.send(503, "application/json", "{\"error\":\"storage_failed\"}"); return; }
      if (spoolCount) --spoolCount;
    }
    server.send(200, "application/json", "{\"saved\":true}");
  });
  server.on("/api/mesh/ping", HTTP_POST, [] {
    if (!authorized()) return;
    uint8_t bytes[8]; uint64_t id = 0;
    if (!fromHex(server.arg("id").c_str(), bytes, 8)) { server.send(400, "application/json", "{\"error\":\"invalid_id\"}"); return; }
    for (uint8_t b : bytes) id = (id << 8) | b;
    bool ok = mesh.core && mesh.core->publish(id, nullptr, 0, millis(), Ping);
    server.send(ok ? 202 : 503, "application/json", ok ? "{\"queued\":true}" : "{\"error\":\"unavailable\"}");
  });
  server.onNotFound([] { server.send(404, "application/json", "{\"error\":\"not_found\"}"); });
  server.begin();
}
void startWifiAttempt() {
  lastWifiTry = millis(); wifiAttemptAt = lastWifiTry; wifiAttempt = true;
  WiFi.begin(mesh.config.ssid, mesh.config.password, mesh.config.channel);
}
void wifiTick() {
#if CC_GATEWAY
  if (WiFi.status() == WL_CONNECTED) {
    wifiAttempt = false;
    if (WiFi.channel() != mesh.config.channel) {
      channelMismatch = true; WiFi.disconnect(false, false);
      esp_wifi_set_channel(mesh.config.channel, WIFI_SECOND_CHAN_NONE);
      Serial.println("{\"error\":\"wifi_channel_mismatch\"}");
    }
  } else if (wifiAttempt && millis() - wifiAttemptAt > 10000) {
    WiFi.disconnect(false, false); wifiAttempt = false;
    esp_wifi_set_channel(mesh.config.channel, WIFI_SECOND_CHAN_NONE);
  } else if (!wifiAttempt && !channelMismatch && millis() - lastWifiTry >= 60000) startWifiAttempt();
  // Disconnect is asynchronous. Restore the mesh channel after it actually completes.
  if (!wifiAttempt && WiFi.status() != WL_CONNECTED) {
    uint8_t channel = 0; wifi_second_chan_t second;
    if (esp_wifi_get_channel(&channel, &second) == ESP_OK && channel != mesh.config.channel)
      esp_wifi_set_channel(mesh.config.channel, WIFI_SECOND_CHAN_NONE);
  }
#endif
}
void sample() {
#if !CC_GATEWAY
  if (!mesh.core || millis() - lastSample < mesh.config.intervalMs) return;
  lastSample = millis(); Reading r;
  r.uptime = millis(); strcpy(r.name, mesh.config.name); strcpy(r.house, mesh.config.house); strcpy(r.zone, mesh.config.zone);
  r.hasAnalog = mesh.config.analogPin >= 0; r.hasContact = mesh.config.contactPin >= 0;
  if (r.hasAnalog) r.analog = analogRead(mesh.config.analogPin);
  if (r.hasContact) r.contact = digitalRead(mesh.config.contactPin) == LOW;
  uint8_t payload[TelemetrySize];
  if (encodeReading(r, payload)) mesh.core->publish(mesh.config.gateway, payload, sizeof(payload), millis());
#endif
}
#ifdef CC_MESH_BENCH
bool benchConsole(const cJSON *o) {
  const char *op = o ? str(o, "op") : nullptr;
  if (!op) return false;
  if (!strcmp(op, "bench_probe")) {
    int seq;
    if (!ready || !number(o, "sequence", 1, INT32_MAX, seq)) {
      Serial.println("{\"error\":\"invalid_probe\"}"); return true;
    }
    Frame f; f.source = mesh.id ^ 0xff00000000000000ULL; f.destination = mesh.id;
    f.session = mesh.session; f.sequence = seq; f.type = Telemetry; f.length = TelemetrySize;
    Reading r; r.uptime = millis(); strcpy(r.name, "Radio round trip"); strcpy(r.house, "bench"); strcpy(r.zone, "two-radio-hops");
    encodeReading(r, f.payload);
    bool sent = mesh.transmit(f);
    Serial.println(String("{\"probe_sent\":") + (sent ? "true" : "false") + ",\"record_id\":\"" + recordId(f) + "\"}");
    return true;
  }
  if (!strcmp(op, "bench_events")) {
    char uptime[24]; snprintf(uptime, sizeof(uptime), "%llu", (unsigned long long)(esp_timer_get_time() / 1000));
    Serial.print(String("{\"gateway_session\":\"") + hexId(mesh.session) + "\",\"uptime_ms\":" + uptime + ",\"events\":[");
    File dir = LittleFS.open("/spool"); File file = dir.openNextFile(); bool first = true;
    while (file) {
      if (!file.isDirectory()) { if (!first) Serial.print(','); first = false; Serial.print(file.readString()); }
      file.close(); file = dir.openNextFile();
    }
    dir.close(); Serial.println("]}"); return true;
  }
  return false;
}
#endif
}
void setup() {
  Serial.begin(115200); mesh.load(); Serial.println(mesh.status());
  if (!mesh.configured || !validateRole(mesh.config)) return;
  configReady = true;
  WiFi.persistent(false); WiFi.mode(WIFI_STA); WiFi.setSleep(false); WiFi.setAutoReconnect(false);
  WiFi.disconnect(false, false); esp_wifi_set_channel(mesh.config.channel, WIFI_SECOND_CHAN_NONE);
#if CC_GATEWAY
  // A first-use partition may be formatted; an existing corrupt filesystem is never silently erased.
  storageReady = LittleFS.begin(false);
  if (!storageReady) {
    Preferences p; p.begin("meshfs", false);
    if (!p.getBool("initialized", false)) {
      storageReady = LittleFS.format() && LittleFS.begin(false);
      if (storageReady) p.putBool("initialized", true);
    }
    p.end();
  } else { Preferences p; p.begin("meshfs", false); p.putBool("initialized", true); p.end(); }
  if (storageReady) {
    if (!LittleFS.exists("/spool")) LittleFS.mkdir("/spool");
    File dir = LittleFS.open("/spool"); File f = dir.openNextFile();
    while (f) { if (!f.isDirectory()) ++spoolCount; f.close(); f = dir.openNextFile(); }
    dir.close();
  }
#else
  if (mesh.config.contactPin >= 0) pinMode(mesh.config.contactPin, INPUT_PULLUP);
  if (mesh.config.analogPin >= 0) { pinMode(mesh.config.analogPin, INPUT); analogReadResolution(12); }
#endif
  ready = mesh.begin(delivered);
  if (!ready) Serial.println("{\"error\":\"radio_init_failed\"}");
#if CC_GATEWAY
  setupApi(); startWifiAttempt();
#endif
}
void loop() {
#ifdef CC_MESH_BENCH
  mesh.console(validateRole, benchConsole);
#else
  mesh.console(validateRole);
#endif
  if (configReady && !ready && millis() - lastInitTry >= 5000) {
    lastInitTry = millis(); ready = mesh.begin(delivered);
  }
  if (ready) { mesh.tick(); sample(); }
  if (configReady) wifiTick();
#if CC_GATEWAY
  if (configReady) server.handleClient();
#endif
  delay(1);
}
