const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const {createServer} = require('../../dashboard/api/server');
(async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'chicken-mesh-'));
  const file = path.join(dir, 'mesh.json');
  const server = createServer({meshSnapshotPath: file});
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const url = `http://127.0.0.1:${server.address().port}/api/mesh-nodes`;
  try {
    assert.equal((await (await fetch(url)).json()).status, 'unavailable');
    const fresh = {record_type: 'mesh_nodes', generated_at_utc: new Date().toISOString(), nodes: [
      {source: '0000000000000001', received_at_utc: new Date().toISOString(), status: 'online'},
      {source: '0000000000000002', received_at_utc: new Date(Date.now() - 120000).toISOString(), status: 'online'},
      {source: '0000000000000003', received_at_utc: null, status: 'online'}]};
    await fs.writeFile(file, JSON.stringify(fresh));
    assert.deepEqual((await (await fetch(url)).json()).nodes.map(n => n.status), ['online', 'stale', 'stale']);
    fresh.generated_at_utc = new Date(Date.now() - 45000).toISOString();
    await fs.writeFile(file, JSON.stringify(fresh));
    assert.deepEqual((await (await fetch(url)).json()).nodes.map(n => n.status), ['stale', 'stale', 'stale']);
    assert.equal((await fetch(url, {method: 'POST'})).status, 405);
    console.log('PASS mesh API missing data, current readings, stale readings, stopped collector, and read-only access');
  } finally {
    await new Promise(r => server.close(r));
    await fs.rm(dir, {recursive: true, force: true});
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
