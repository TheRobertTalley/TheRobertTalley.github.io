#include "MeshCore.h"
#include "MeshTelemetry.h"
using namespace chickenmesh;
extern "C" void *memcpy(void *d, const void *s, size_t n) {
  auto out = (unsigned char *)d; auto in = (const unsigned char *)s;
  for (size_t i = 0; i < n; ++i) out[i] = in[i]; return d;
}
extern "C" void *memset(void *d, int c, size_t n) {
  auto out = (unsigned char *)d; for (size_t i = 0; i < n; ++i) out[i] = c; return d;
}
void operator delete(void *) noexcept {}
void operator delete(void *, size_t) noexcept {}
extern "C" void __cxa_pure_virtual() { __builtin_trap(); }
extern "C" int __cxa_atexit(void (*)(void *), void *, void *) { return 0; }

struct Node;
Node *nodes[10];
bool links[10][10] = {};
uint32_t nowMs = 0, transmissions = 0;
unsigned dropAck = 0, copies = 1;
bool blockRadio = false;
struct Event { Frame frame; int target = 0; bool used = false; } events[2048];
struct Node : IO {
  int index; Core core; int deliveredCount = 0, rejectCount = 0; uint8_t lastHops = 0;
  Node(int i) : index(i), core(*this, i + 1, i + 101) { nodes[i] = this; }
  bool transmit(const Frame &f) override {
    if (blockRadio) return false;
    ++transmissions;
    if (f.type == Ack && dropAck) { --dropAck; return true; }
    for (int j = 0; j < 10; ++j) if (links[index][j])
      for (unsigned c = 0; c < copies; ++c) {
        bool placed = false;
        for (auto &e : events) if (!e.used) { e.frame = f; e.target = j; e.used = true; placed = true; break; }
        if (!placed) __builtin_trap();
      }
    return true;
  }
  bool deliver(const Frame &f) override {
    if (rejectCount) { --rejectCount; return false; }
    ++deliveredCount; lastHops = f.hops + 1; return true;
  }
};
Node n0(0), n1(1), n2(2), n3(3), n4(4), n5(5), n6(6), n7(7), n8(8), n9(9);
void link(int a, int b) { links[a][b] = links[b][a] = true; }
void chain(int count) { for (int i = 0; i + 1 < count; ++i) link(i, i + 1); }
void run(uint32_t ms) {
  for (uint32_t t = 0; t < ms; t += 5) {
    nowMs += 5;
    for (auto &e : events) if (e.used) { Frame f = e.frame; int dst = e.target; e.used = false; nodes[dst]->core.receive(f, nowMs); }
    for (auto n : nodes) n->core.tick(nowMs);
  }
}
bool send(Node &n, uint64_t dst) {
  uint8_t data[] = {7, 8, 9}; return n.core.publish(dst, data, 3, nowMs);
}
extern "C" __attribute__((visibility("default"))) int run_case(int which) {
  if (which == 0) { // Three repeaters, actual four radio edges, both directions.
    chain(5); if (!send(n0, 5)) return 1; run(3000);
    if (n4.deliveredCount != 1 || n4.lastHops != 4 || n0.core.stats.confirmed != 1) return 2;
    if (!send(n4, 1)) return 3; run(3000);
    return n0.deliveredCount == 1 && n4.core.stats.confirmed == 1 ? 0 : 4;
  }
  if (which == 1) { chain(5); dropAck = 2; send(n0, 5); run(29000);
    return n4.deliveredCount == 1 && n0.core.stats.confirmed == 1 && n0.core.pending() == 0 ? 0 : 1; }
  if (which == 2) { chain(5); link(1, 5); link(5, 3); links[1][2] = links[2][1] = false;
    send(n0, 5); run(6000); return n4.deliveredCount == 1 && n0.core.stats.confirmed == 1 ? 0 : 1; }
  if (which == 3) { chain(3); send(n0, 5); run(31000);
    return n0.core.pending() == 0 && n0.core.stats.failed == 1 && !n0.core.stats.confirmed ? 0 : 1; }
  if (which == 4) { chain(6); link(0, 2); link(1, 3); link(3, 5); copies = 4; send(n0, 6); run(31000);
    return n5.deliveredCount == 1 && n0.core.stats.confirmed == 1 && transmissions < 80 ? 0 : 1; }
  if (which == 5) { chain(10); send(n0, 10); run(31000);
    return n9.deliveredCount == 0 && n0.core.stats.failed == 1 ? 0 : 1; }
  if (which == 6) { for (int i = 0; i < 8; ++i) if (!send(n0, 5)) return 1;
    if (send(n0, 5)) return 2; run(31000); return n0.core.stats.failed == 8 ? 0 : 3; }
  if (which == 7) { nowMs = 0xfffff800; chain(5); dropAck = 1; send(n0, 5); run(29000);
    return n4.deliveredCount == 1 && n0.core.stats.confirmed == 1 ? 0 : 1; }
  if (which == 8) { chain(5); n4.rejectCount = 2; send(n0, 5); run(29000);
    return n4.deliveredCount == 1 && n0.core.stats.confirmed == 1 && n4.core.stats.rejected == 2 ? 0 : 1; }
  if (which == 9) { Frame f; f.source = 1; f.destination = 2; f.session = 3; f.sequence = 4; f.type = Telemetry;
    uint8_t bytes[PlainMax]; f.length = PayloadMax; for (size_t i = 0; i < PayloadMax; ++i) f.payload[i] = i;
    size_t len = encode(f, bytes); Frame d;
    if (len != PlainMax || !decode(bytes, len, d) || d.payload[143] != 143) return 1;
    for (size_t i = 0; i < len; ++i) if (decode(bytes, i, d)) return 2;
    bytes[0] = 9; if (decode(bytes, len, d)) return 3;
    bytes[0] = Telemetry; bytes[30] = 255; if (decode(bytes, len, d)) return 4;
    bytes[30] = MaxHops; bytes[31] = 1; if (decode(bytes, len, d)) return 5;
    return 0;
  }
  if (which == 10) { chain(5); n4.core.publish(1, nullptr, 0, nowMs, Ping); run(6000);
    return n4.deliveredCount == 1 && n4.core.stats.confirmed == 1 ? 0 : 1; }
  if (which == 11) { blockRadio = true; send(n0, 5); run(31000);
    return n0.core.pending() == 0 && n0.core.stats.failed == 1 ? 0 : 1; }
  if (which == 12) { Reading r; r.role = 1; r.uptime = 0xffffffff; r.feederFlags = 31;
    r.hasAnalog = true; r.analog = 4095; r.hasContact = true; r.contact = true;
    memcpy(r.name, "Feed Bin", 9); memcpy(r.house, "house-01", 9); memcpy(r.zone, "far-end", 8);
    uint8_t bytes[TelemetrySize]; Reading d;
    if (!encodeReading(r, bytes) || !decodeReading(bytes, sizeof(bytes), d) || d.analog != 4095 || d.uptime != r.uptime || d.feederFlags != 31) return 1;
    bytes[36] = 'x'; for (int i = 12; i < 36; ++i) bytes[i] = 'x';
    return decodeReading(bytes, sizeof(bytes), d) ? 2 : 0;
  }
  if (which == 13) { chain(9); send(n0, 9); run(6000);
    return n8.deliveredCount == 1 && n8.lastHops == 8 && n0.core.stats.confirmed == 1 ? 0 : 1; }
  if (which == 14) { chain(6); for (int i = 0; i < 5; ++i) send(*nodes[i], 6); run(29000);
    if (n5.deliveredCount != 5) return 1;
    for (int i = 0; i < 5; ++i) if (nodes[i]->core.stats.confirmed != 1) return 2;
    return 0; }
  if (which == 15) { chain(5); uint8_t data[1] = {1};
    if (!n0.core.publish(5, data, 1, nowMs, Alarm)) return 1;
    run(6000); return n4.deliveredCount == 1 && n0.core.stats.confirmed == 1 ? 0 : 2; }
  if (which == 16) { Frame f; f.source = 1; f.destination = 5; f.session = 101; f.sequence = 1; f.type = Telemetry;
    n4.core.receive(f, nowMs); f.session = 102; n4.core.receive(f, nowMs);
    return n4.deliveredCount == 2 ? 0 : 1; }
  if (which == 17) { Frame f; f.source = 1; f.destination = 10; f.session = 101; f.sequence = 1; f.type = Telemetry;
    f.hops = 6; f.ttl = 2; n4.core.receive(f, nowMs);
    f.hops = 2; f.ttl = 6; n4.core.receive(f, nowMs);
    n4.core.receive(f, nowMs);
    return n4.core.stats.forwarded == 2 && n4.core.stats.duplicates == 1 ? 0 : 1; }
  return 99;
}
