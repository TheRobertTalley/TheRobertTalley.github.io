param([string]$Clang = $env:CHICKEN_MESH_CLANG)
$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
if (-not $Clang) {
    $taskCommand = Get-Command clang++ -ErrorAction SilentlyContinue
    if ($taskCommand) { $Clang = $taskCommand.Source }
}
if (-not $Clang) {
    $taskBundled = 'C:/Program Files/Unity/Hub/Editor/6000.3.2f1/Editor/Data/PlaybackEngines/WebGLSupport/BuildTools/Emscripten/llvm/clang++.exe'
    if (Test-Path -LiteralPath $taskBundled) { $Clang = $taskBundled }
}
if (-not $Clang) { throw 'Set CHICKEN_MESH_CLANG to a clang++ installation with WebAssembly support.' }
$taskWasm = Join-Path $PSScriptRoot 'core_test.wasm'
& $Clang --target=wasm32 -std=c++11 -O1 -Wall -Wextra -Werror -fno-builtin -fno-exceptions -fno-rtti -nostdlib -I (Join-Path $PSScriptRoot 'wasm_include') -I (Join-Path $taskRoot 'firmware/libraries/ChickenMesh/src') (Join-Path $PSScriptRoot 'core_test.cpp') '-Wl,--no-entry,--export=run_case,--export=__wasm_call_ctors,-z,stack-size=1048576' -o $taskWasm
if ($LASTEXITCODE) { throw 'C++ test compilation failed.' }
node (Join-Path $PSScriptRoot 'run_wasm_tests.js') $taskWasm
if ($LASTEXITCODE) { throw 'C++ mesh transport tests failed.' }
python -m unittest discover -s $PSScriptRoot -p 'test_*.py' -v
if ($LASTEXITCODE) { throw 'Collector tests failed.' }
node (Join-Path $taskRoot 'tests/dashboard_tests/mesh_nodes_api.test.js')
if ($LASTEXITCODE) { throw 'Mesh API tests failed.' }
