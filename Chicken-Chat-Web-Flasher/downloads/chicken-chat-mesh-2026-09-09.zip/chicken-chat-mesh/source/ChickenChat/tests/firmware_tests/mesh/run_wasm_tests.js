const fs = require('node:fs');
const assert = require('node:assert/strict');
const names = ['three-repeaters bidirectional', 'lost ACKs do not duplicate delivery',
  'alternate path bypasses failed repeater', 'broken chain reports failure',
  'loops and duplicate storm remain bounded', 'hop limit stops unreachable route',
  'pending capacity and expiry', 'millisecond rollover', 'destination storage backpressure',
  'wire codec rejects malformed packets', 'gateway ping round trip',
  'radio outage expires pending delivery', 'sensor and feeder telemetry codec',
  'eight-hop boundary succeeds', 'repeaters sample while forwarding', 'alarm delivery',
  'reboot sessions have separate message identities', 'shorter path supersedes earlier long path'];
(async () => {
  const bytes = fs.readFileSync(process.argv[2]);
  for (let i = 0; i < names.length; ++i) {
    const {instance} = await WebAssembly.instantiate(bytes, {});
    instance.exports.__wasm_call_ctors();
    assert.equal(instance.exports.run_case(i), 0, names[i]);
    console.log(`PASS ${names[i]}`);
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
