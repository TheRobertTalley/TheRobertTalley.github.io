import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import sqlite3
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from contextlib import closing

spec = importlib.util.spec_from_file_location("mesh_tool", Path(__file__).parents[3] / "tools/mesh/mesh_tool.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def event(sequence=1):
    return {"id": f"0000000000000001_0000000000000065_{sequence:08x}",
            "source": "0000000000000001", "session": "0000000000000065", "sequence": sequence,
            "hops": 4, "gateway_session": "0000000000000069", "received_uptime_ms": 10000,
            "source_uptime_ms": 5000, "node_name": "Far sensor", "house_id": "house-01", "zone_id": "far-end",
            "role": "repeater_sensor", "analog_raw": 2048, "contact_closed": True}


class FakeGateway:
    def __init__(self, events):
        self.batch = {"gateway_session": "0000000000000069", "uptime_ms": 20000, "events": events}
        self.acks = []
        self.before_ack = None

    def request(self, path, post=False):
        if not post:
            return copy.deepcopy(self.batch)
        if self.before_ack:
            self.before_ack()
        self.acks.append(path)
        return {"saved": True}


class CollectorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.collector = module.Collector(self.root / "mesh.sqlite3", self.root / "mesh_nodes.json")

    def tearDown(self):
        self.collector.db.close()
        self.temp.cleanup()

    def test_commit_before_ack_and_roundtrip(self):
        gateway = FakeGateway([event()])
        def independent_read():
            with closing(sqlite3.connect(self.root / "mesh.sqlite3")) as connection:
                self.assertEqual(connection.execute("SELECT count(*) FROM events").fetchone()[0], 1)
        gateway.before_ack = independent_read
        self.assertEqual(self.collector.poll(gateway, now=1000), 1)
        data = json.loads((self.root / "mesh_nodes.json").read_text())
        self.assertEqual(data["nodes"][0]["hops"], 4)
        self.assertEqual(data["nodes"][0]["status"], "online")
        self.assertEqual(len(gateway.acks), 1)

    def test_retry_after_lost_host_ack_does_not_refresh_old_record(self):
        gateway = FakeGateway([event()])
        self.collector.poll(gateway, now=1000)
        self.collector.poll(gateway, now=2000)
        self.assertEqual(self.collector.db.execute("SELECT count(*) FROM events").fetchone()[0], 1)
        node = json.loads((self.root / "mesh_nodes.json").read_text())["nodes"][0]
        self.assertEqual(node["status"], "stale")
        self.assertEqual(node["received_at_utc"], module.utc(990))

    def test_gateway_reboot_preserves_records_but_does_not_invent_age(self):
        gateway = FakeGateway([event()])
        gateway.batch["gateway_session"] = "0000000000000070"
        self.collector.poll(gateway, now=1000)
        node = json.loads((self.root / "mesh_nodes.json").read_text())["nodes"][0]
        self.assertIsNone(node["received_at_utc"])
        self.assertEqual(node["status"], "stale")

    def test_malformed_batch_is_not_partly_committed_or_acked(self):
        bad = event(2)
        bad["source"] = "other"
        gateway = FakeGateway([event(), bad])
        with self.assertRaises(ValueError):
            self.collector.poll(gateway, now=1000)
        self.assertFalse(gateway.acks)
        self.assertEqual(self.collector.db.execute("SELECT count(*) FROM events").fetchone()[0], 0)

    def test_snapshot_write_failure_retains_gateway_copy(self):
        gateway = FakeGateway([event()])
        self.collector.snapshot = self.root  # Cannot replace a directory with a file.
        with self.assertRaises(OSError):
            self.collector.poll(gateway, now=1000)
        self.assertFalse(gateway.acks)

    def test_late_old_batch_does_not_replace_new_reading(self):
        latest = event(2)
        latest["received_uptime_ms"] = 19000
        self.collector.poll(FakeGateway([latest]), now=1000)
        self.collector.poll(FakeGateway([event()]), now=1001)
        node = json.loads((self.root / "mesh_nodes.json").read_text())["nodes"][0]
        self.assertEqual(node["sequence"], 2)

    def test_gateway_clock_beyond_32bit_does_not_wrap(self):
        gateway = FakeGateway([event()])
        gateway.batch["uptime_ms"] = 0x100000000 + 20000
        self.collector.poll(gateway, now=1000)
        node = json.loads((self.root / "mesh_nodes.json").read_text())["nodes"][0]
        self.assertEqual(node["status"], "stale")

    def test_unknown_freshness_cannot_replace_current_record(self):
        self.collector.poll(FakeGateway([event()]), now=1000)
        gateway = FakeGateway([event(2)])
        gateway.batch["gateway_session"] = "0000000000000070"
        self.collector.poll(gateway, now=1001)
        node = json.loads((self.root / "mesh_nodes.json").read_text())["nodes"][0]
        self.assertEqual(node["sequence"], 1)

    def test_database_write_failure_never_releases_gateway_record(self):
        gateway = FakeGateway([event()])
        self.collector.db.execute("PRAGMA query_only=ON")
        with self.assertRaises(sqlite3.OperationalError):
            self.collector.poll(gateway, now=1000)
        self.assertFalse(gateway.acks)

    def test_http_gateway_to_durable_hub_roundtrip(self):
        batch = FakeGateway([event()]).batch
        acknowledgments = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass
            def do_GET(self):
                if self.headers.get("X-Chicken-Mesh-Token") != "test-token":
                    self.send_error(401)
                    return
                data = json.dumps(batch).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            def do_POST(self):
                if self.headers.get("X-Chicken-Mesh-Token") != "test-token":
                    self.send_error(401)
                    return
                acknowledgments.append(self.path)
                data = b'{"saved":true}'
                self.send_response(200)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            gateway = module.Gateway(f"http://127.0.0.1:{server.server_port}", "test-token")
            self.assertEqual(self.collector.poll(gateway, now=1000), 1)
            self.assertEqual(len(acknowledgments), 1)
        finally:
            server.shutdown()
            server.server_close()
            thread.join()

    def test_release_checksum_verification_rejects_modified_binary(self):
        parts = []
        for i, offset in enumerate((0x1000, 0x8000, 0xe000, 0x10000)):
            data = bytes([i + 1]) * 16
            filename = f"part-{i}.bin"
            (self.root / filename).write_bytes(data)
            parts.append({"file": filename, "offset": offset, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        manifest = self.root / "manifest.json"
        manifest.write_text(json.dumps({"format": 1, "chip": "esp32", "builds": {"repeater": {"parts": parts}}}))
        self.assertEqual(len(module.release_parts(manifest, "repeater")), 8)
        (self.root / "part-3.bin").write_bytes(b"altered")
        with self.assertRaises(ValueError):
            module.release_parts(manifest, "repeater")

    def test_release_rejects_wrong_flash_offsets(self):
        manifest = self.root / "manifest.json"
        manifest.write_text(json.dumps({"format": 1, "chip": "esp32", "builds": {"repeater": {"parts": [
            {"file": "part.bin", "offset": 0, "size": 1, "sha256": "wrong"}] * 4}}}))
        with self.assertRaises(ValueError):
            module.release_parts(manifest, "repeater")


if __name__ == "__main__":
    unittest.main()
