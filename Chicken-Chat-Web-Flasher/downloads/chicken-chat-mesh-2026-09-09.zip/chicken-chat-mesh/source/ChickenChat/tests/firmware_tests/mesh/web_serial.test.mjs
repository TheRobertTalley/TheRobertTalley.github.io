import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {createNetwork, validateNetwork, makeConfig} from '../../../../web-pages/Chicken-Chat-Web-Flasher/assets/mesh-config.mjs';
const source=readFileSync(new URL('../../../../web-pages/Chicken-Chat-Web-Flasher/assets/mesh-setup.mjs',import.meta.url),'utf8').replace(/^import[^\n]+\n/,'');
function fixture(writeFailure=false){
 const elements=new Map(), sent=[]; let readResolve, closed=false;
 const defaults={'mesh-role':'gateway','mesh-channel':'6','mesh-name':'Gateway','mesh-house':'house-01','mesh-zone':'north','mesh-ssid':' Open WiFi ','mesh-password':'','mesh-analog':'-1','mesh-contact':'-1'};
 const get=id=>{if(!elements.has(id))elements.set(id,{value:defaults[id]||'',dataset:{},events:{},addEventListener(n,fn){this.events[n]=fn;},setAttribute(n,v){this[n]=v;}});return elements.get(id);};
 const push=o=>{const r=readResolve;readResolve=null;r({value:new TextEncoder().encode(JSON.stringify(o)+'\n'),done:false});};
 const reader={read:()=>new Promise(r=>{readResolve=r;}),cancel:async()=>{readResolve?.({done:true});},releaseLock(){}};
 const writer={write:async bytes=>{if(writeFailure)throw Error('USB write failed');const o=JSON.parse(new TextDecoder().decode(bytes));sent.push(o);push(o.op==='status'?{id:'000004577cdf948c',configured:true}:{saved:true});},releaseLock(){}};
 const port={open:async()=>{},setSignals:async()=>{},readable:{getReader:()=>reader},writable:{getWriter:()=>writer},close:async()=>{closed=true;}};
 const sandbox={createNetwork,validateNetwork,makeConfig,document:{getElementById:get,createElement:()=>({click(){}})},navigator:{serial:{requestPort:async()=>port}},TextEncoder,TextDecoder,Uint8Array,Uint32Array,Blob,URL,crypto:globalThis.crypto,setTimeout,clearTimeout};
 vm.runInNewContext(source,sandbox);
 return {get,sent,closed:()=>closed,disconnectRadio:()=>readResolve?.({done:true}),event:async(id,name='click',event={})=>get(id).events[name](event)};
}
test('USB status, private network load, exact Wi-Fi save, and clean disconnect',async()=>{
 const f=fixture();await f.event('usb-connect');assert.match(f.get('board-id').textContent,/000004577cdf948c/);
 const network=createNetwork('000004577cdf948c',6);await f.event('network-file','change',{target:{files:[{size:300,text:async()=>JSON.stringify(network)}]}});
 await f.event('mesh-form','submit',{preventDefault(){}});assert.equal(f.sent[1].ssid,' Open WiFi ');assert.equal(f.sent[1].key,network.key);assert.equal(f.closed(),true);assert.match(f.get('setup-status').textContent,/Settings saved/);assert.equal(f.get('mesh-save').disabled,false);
});
test('USB write failure releases the port and presents a recoverable error',async()=>{const f=fixture(true);await f.event('usb-connect');assert.equal(f.closed(),true);assert.equal(f.get('usb-connect').disabled,false);assert.match(f.get('setup-status').textContent,/USB write failed/);});
test('physical USB disconnection resets the UI',async()=>{const f=fixture();await f.event('usb-connect');f.disconnectRadio();await new Promise(r=>setImmediate(r));assert.equal(f.closed(),true);assert.equal(f.get('usb-connect').disabled,false);assert.match(f.get('setup-status').textContent,/connection lost/);});
