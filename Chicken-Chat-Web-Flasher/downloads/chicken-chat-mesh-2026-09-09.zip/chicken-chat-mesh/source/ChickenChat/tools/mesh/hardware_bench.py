"""Explicit USB bench operations; evidence and credentials stay in an ignored directory."""
import argparse
import json
from pathlib import Path
import secrets
import time
from mesh_tool import serial_request, atomic_json

ROOT = Path(__file__).resolve().parents[3]
PRIVATE = ROOT / "ChickenChat/data/mesh-bench"


def status(port):
    return serial_request(port, {"op": "status"}, "id")


def provision(args):
    first, second = status(args.gateway_port), status(args.repeater_port)
    expected = {"COM14": "000004577cdf948c", "COM15": "0000a0e228a50528"}
    assert first["id"] == expected[args.gateway_port] and second["id"] == expected[args.repeater_port], "Unexpected board identity"
    network_path = PRIVATE / "network.private.json"
    net = json.loads(network_path.read_text()) if network_path.exists() else {
        "network": secrets.randbelow(0x7ffffffe) + 1, "key": secrets.token_hex(32), "token": secrets.token_hex(32)}
    net.update(gateway=first["id"], channel=args.channel)
    atomic_json(network_path, net)
    for port, is_gateway in ((args.repeater_port, False), (args.gateway_port, True)):
        config = {"op": "configure", **net, "name": "Bench gateway" if is_gateway else "Bench repeater",
                  "house": "bench", "zone": "gateway" if is_gateway else "relay", "forward": True,
                  "analog_pin": -1, "contact_pin": -1, "interval_ms": 10000,
                  "ssid": args.ssid if is_gateway else "", "password": "", "token": net["token"] if is_gateway else ""}
        print(port, serial_request(port, config, "saved"), flush=True)


def probe(args):
    baseline = status(args.repeater_port)
    records = []
    for i in range(args.count):
        seq = int(time.time()) + i
        for retry in range(10):
            answer = serial_request(args.gateway_port, {"op": "bench_probe", "sequence": seq}, "probe_sent")
            if answer["probe_sent"]:
                break
            time.sleep(0.1)
        if not answer["probe_sent"]:
            raise RuntimeError("Gateway could not transmit probe")
        records.append(answer["record_id"])
        time.sleep(0.35)
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        batch = serial_request(args.gateway_port, {"op": "bench_events"}, "events")
        matched = [e for e in batch["events"] if e["id"] in records and e["hops"] >= 2]
        if len(matched) == len(records):
            break
        time.sleep(1)
    after = status(args.repeater_port)
    result = {"probe_count": len(records), "returned_via_repeater": len(matched),
              "repeater_forwarded_delta": after["forwarded"] - baseline["forwarded"],
              "gateway": status(args.gateway_port), "repeater": after,
              "events": batch["events"]}
    atomic_json(PRIVATE / "radio-results.json", result)
    print(json.dumps({k: v for k, v in result.items() if k != "events"}, indent=2), flush=True)
    if len(matched) != len(records) or result["repeater_forwarded_delta"] < args.count:
        raise RuntimeError("Physical forwarding acceptance failed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=["provision", "probe", "status"])
    parser.add_argument("--gateway-port", default="COM14")
    parser.add_argument("--repeater-port", default="COM15")
    parser.add_argument("--channel", type=int, default=6)
    parser.add_argument("--ssid", default="DERPAnet")
    parser.add_argument("--count", type=int, default=20)
    args = parser.parse_args()
    if args.operation == "provision":
        provision(args)
    elif args.operation == "probe":
        probe(args)
    else:
        print(json.dumps({args.gateway_port: status(args.gateway_port), args.repeater_port: status(args.repeater_port)}, indent=2))


if __name__ == "__main__":
    main()
