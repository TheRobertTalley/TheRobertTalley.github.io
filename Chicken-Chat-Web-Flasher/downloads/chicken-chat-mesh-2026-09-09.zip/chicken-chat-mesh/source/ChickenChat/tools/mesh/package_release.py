"""Package successful PlatformIO builds with verified flash offsets and SHA-256 hashes."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[3]
BUILDS = {
    "repeater": ("ChickenChat/firmware/mesh_node", "repeater", "Standard ESP32 DevKit; optional configured ADC1 and contact inputs"),
    "gateway": ("ChickenChat/firmware/mesh_node", "gateway", "Standard ESP32 DevKit; Wi-Fi bridge, no output pins"),
    "bin-commander-devkit": ("Feeder Bin Bot", "esp32dev-mesh", "Original esp32dev feeder pin map"),
    "bin-commander-production": ("Feeder Bin Bot", "fbb-production-pcb-mesh", "Production PCB pin map; hardware E-stop input"),
    "bin-commander-prototype": ("Feeder Bin Bot", "prototype-shield-mesh", "Prototype shield pin map; retains existing disabled hardware E-stop input"),
    "cluck-o-magic-prototype": ("Feeder Bin Bot", "cluck-o-magic-mesh", "Cluck-o-Magic prototype shield pin map"),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--hardware-evidence", type=Path, help="Local completed bench result; verifies production binary hashes")
    parser.add_argument("--boot-app", type=Path, default=Path.home() / ".platformio/packages/framework-arduinoespressif32/tools/partitions/boot_app0.bin")
    args = parser.parse_args()
    sources = []
    shared_sources = list((ROOT / "ChickenChat/firmware/libraries/ChickenMesh/src").glob("*.h")) + list((ROOT / "ChickenChat/firmware/libraries/ChickenMesh/src").glob("*.cpp"))
    for role, (project, env, hardware) in BUILDS.items():
        build = ROOT / project / ".pio/build" / env
        dependencies = shared_sources + [ROOT / project / "src/main.cpp", ROOT / project / "platformio.ini"]
        if not (build / "firmware.bin").is_file() or (build / "firmware.bin").stat().st_mtime < max(p.stat().st_mtime for p in dependencies):
            raise ValueError(f"Build {env} again; its firmware is missing or older than its sources")
        for file, offset in (("bootloader.bin", 0x1000), ("partitions.bin", 0x8000), ("boot_app0.bin", 0xe000), ("firmware.bin", 0x10000)):
            source = args.boot_app if file == "boot_app0.bin" else build / file
            if not source.is_file():
                raise FileNotFoundError(f"Build {env} first; missing {source}")
            sources.append((role, env, hardware, source, file, offset))
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = {"format": 1, "chip": "esp32", "release": "2026-09-09-mesh-1", "radio_tested": False, "field_tested": False, "builds": {}}
    if args.hardware_evidence:
        evidence = json.loads(args.hardware_evidence.read_text())
        for role in ("gateway", "repeater"):
            project, env, _ = BUILDS[role]
            binary = ROOT / project / ".pio/build" / env / "firmware.bin"
            key = "production_firmware_sha256" if role == "gateway" else "production_repeater_sha256"
            if evidence.get(key) != hashlib.sha256(binary.read_bytes()).hexdigest():
                raise ValueError(f"Hardware evidence does not match {role} image")
        if not evidence.get("wifi_collection") or not evidence.get("bench_commands_absent") or evidence.get("production_repeater_status", {}).get("confirmed", 0) < 2:
            raise ValueError("Incomplete production hardware evidence")
        manifest.update(radio_tested=True, hardware_scope="Two ESP32 boards: forwarded out-and-back radio probes, acknowledgments, reboot recovery, and production Wi-Fi collection. Physical multi-repeater chains and farm range remain untested.")
    for role, env, hardware, source, file, offset in sources:
        dest = args.output / role / file
        dest.parent.mkdir(exist_ok=True)
        shutil.copyfile(source, dest)
        data = dest.read_bytes()
        entry = manifest["builds"].setdefault(role, {"environment": env, "hardware": hardware, "parts": []})
        entry["parts"].append({"file": f"{role}/{file}", "offset": offset, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    source_files = shared_sources + [ROOT / "ChickenChat/firmware/mesh_node/src/main.cpp", ROOT / "Feeder Bin Bot/src/main.cpp"]
    fingerprints = {str(p.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    (args.output / "source-sha256.json").write_text(json.dumps(fingerprints, indent=2) + "\n", encoding="utf-8")
    print(f"Packaged {len(BUILDS)} firmware builds in {args.output}")


if __name__ == "__main__":
    main()
