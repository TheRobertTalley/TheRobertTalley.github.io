#pragma once

#include <stdint.h>

constexpr uint8_t ESPNOW_MAGIC = 0xA5;
constexpr uint8_t ESPNOW_LED_IGNORE = 255;
constexpr uint8_t ESPNOW_MODULE_MAGIC = 0xC7;
constexpr uint8_t ESPNOW_MODULE_VERSION = 1;
constexpr uint8_t ESPNOW_MODULE_NAME_LEN = 18;

enum EspNowRelay : uint8_t {
  ESPNOW_RELAY_NONE = 0,
  ESPNOW_RELAY_1 = 1,
  ESPNOW_RELAY_2 = 2,
  ESPNOW_RELAY_BOTH = 3
};

enum EspNowAction : uint8_t {
  ESPNOW_ACTION_OFF = 0,
  ESPNOW_ACTION_ON = 1,
  ESPNOW_ACTION_TOGGLE = 2
};

struct EspNowCommand {
  uint8_t magic;
  uint8_t relay;
  uint8_t action;
  uint8_t led;
};

enum EspNowModuleRole : uint8_t {
  ESPNOW_ROLE_UNKNOWN = 0,
  ESPNOW_ROLE_BIN_COMMANDER = 1,
  ESPNOW_ROLE_CLUCK_MAGIC = 2
};

enum EspNowModuleMessageType : uint8_t {
  ESPNOW_MODULE_HELLO = 1,
  ESPNOW_MODULE_COMMAND = 2,
  ESPNOW_MODULE_STATE = 3
};

enum EspNowModuleFlags : uint8_t {
  ESPNOW_MODULE_RELAY1_ON = 1 << 0,
  ESPNOW_MODULE_RELAY2_ON = 1 << 1,
  ESPNOW_MODULE_ESTOP = 1 << 2,
  ESPNOW_MODULE_FAULT = 1 << 3
};

struct EspNowModulePacket {
  uint8_t magic;
  uint8_t version;
  uint8_t type;
  uint8_t role;
  uint8_t relay;
  uint8_t action;
  uint8_t flags;
  uint16_t sequence;
  char name[ESPNOW_MODULE_NAME_LEN];
};
