#include <Arduino.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_task_wdt.h>
#include <esp_system.h>
#include <limits.h>
#include <HTTPClient.h>
#include <HTTPUpdateServer.h>
#include <Preferences.h>
#include <WebServer.h>
#include <WiFi.h>

#include "espnow_protocol.h"
#ifdef FBB_CHICKEN_MESH
#include <ChickenMeshRadio.h>
#include <MeshTelemetry.h>
chickenmesh::Radio chickenMesh;
#endif

namespace {
#ifdef FBB_CLUCK_O_MAGIC
constexpr bool CLUCK_MAGIC_ROLE = true;
constexpr char AP_SSID[] = "CLUCK-O-MAGIC";
constexpr char NETWORK_NAME[] = "Cluck-o-Magic";
constexpr char DEVICE_ROLE_NAME[] = "cluck_o_magic";
constexpr uint8_t DEVICE_ESPNOW_ROLE = ESPNOW_ROLE_CLUCK_MAGIC;
#else
constexpr bool CLUCK_MAGIC_ROLE = false;
constexpr char AP_SSID[] = "BIN COMMANDER";
constexpr char NETWORK_NAME[] = "Bin Commander";
constexpr char DEVICE_ROLE_NAME[] = "bin_commander";
constexpr uint8_t DEVICE_ESPNOW_ROLE = ESPNOW_ROLE_BIN_COMMANDER;
#endif
constexpr uint8_t AP_CHANNEL = 6;
constexpr uint8_t AP_MAX_CONNECTIONS = 4;
constexpr unsigned long WIFI_RESET_SETTLE_MS = 200;
constexpr unsigned long AP_START_SETTLE_MS = 300;
constexpr int8_t WIFI_MAX_TX_POWER_QUARTER_DBM = 78;
constexpr unsigned long WIFI_STATION_RETRY_INTERVAL_MS = 30000;
constexpr unsigned long STATUS_LOG_INTERVAL_MS = 10000;
constexpr unsigned long AP_RETRY_INTERVAL_MS = 5000;
constexpr unsigned long AP_DISCONNECT_OFF_DELAY_MS = 5000;
constexpr unsigned long ESPNOW_RETRY_INTERVAL_MS = 5000;
constexpr unsigned long CLUCK_MAGIC_ANNOUNCE_INTERVAL_MS = 3000;
constexpr unsigned long CLUCK_MAGIC_ONLINE_TIMEOUT_MS = 15000;
constexpr unsigned long ALARM_LED_FLASH_INTERVAL_MS = 500;
constexpr unsigned long DEFAULT_NO_RUNOUT_ALARM_MS = 6UL * 60UL * 60UL * 1000UL;
constexpr unsigned long DEFAULT_EMPTY_TOO_LONG_ALARM_MS = 20UL * 60UL * 1000UL;
constexpr unsigned long MIN_ALARM_MS = 30UL * 1000UL;
constexpr unsigned long MAX_ALARM_MS = 72UL * 60UL * 60UL * 1000UL;
#ifdef FBB_CHICKEN_MESH
constexpr char FIRMWARE_VERSION[] = "fbb-2026.09.09.mesh1";
#else
constexpr char FIRMWARE_VERSION[] = "fbb-2026.06.15.01";
#endif
#ifndef FBB_BUILD_PROFILE
constexpr char BUILD_PROFILE[] = "esp32dev";
#else
constexpr char BUILD_PROFILE[] = FBB_BUILD_PROFILE;
#endif
#ifndef FBB_OPEN_TEST_ACCESS
constexpr bool OPEN_TEST_ACCESS = false;
#else
constexpr bool OPEN_TEST_ACCESS = FBB_OPEN_TEST_ACCESS;
#endif
constexpr uint32_t CONFIG_VERSION = 4;
constexpr uint32_t WDT_TIMEOUT_S = 10;
constexpr unsigned long DEFAULT_MANUAL_OVERRIDE_TIMEOUT_MS = 2UL * 60UL * 1000UL;
constexpr unsigned long DEFAULT_RELAY_MAX_RUNTIME_MS = 15UL * 60UL * 1000UL;
constexpr unsigned long DEFAULT_AUTOMATION_KEEPALIVE_MS = 60UL * 1000UL;
constexpr unsigned long REBOOT_DELAY_MS = 1000;
constexpr size_t MAX_EVENT_LOG_ENTRIES = 32;
constexpr size_t MAX_EVENT_LOG_MESSAGE = 120;
constexpr size_t HTML_SEND_CHUNK_BYTES = 1024;
constexpr unsigned long DEFAULT_LOGIC_ALTERNATE_MS = 12UL * 60UL * 60UL * 1000UL;
constexpr unsigned long DEFAULT_LOGIC_AUTO_SWITCH_MS = 5UL * 60UL * 1000UL;
constexpr unsigned long DEFAULT_LOGIC_TOP_OFF_MS = 20UL * 1000UL;
constexpr unsigned long MIN_LOGIC_ALTERNATE_MS = 1UL * 60UL * 1000UL;
constexpr unsigned long MAX_LOGIC_ALTERNATE_MS = 72UL * 60UL * 60UL * 1000UL;
constexpr unsigned long MIN_LOGIC_AUTO_SWITCH_MS = 10UL * 1000UL;
constexpr unsigned long MAX_LOGIC_AUTO_SWITCH_MS = 30UL * 60UL * 1000UL;
constexpr unsigned long MIN_LOGIC_TOP_OFF_MS = 0;
constexpr unsigned long MAX_LOGIC_TOP_OFF_MS = 30UL * 60UL * 1000UL;
constexpr uint16_t DEFAULT_HOUSE_PLANNER_NODES = 12;
constexpr uint16_t MIN_HOUSE_PLANNER_NODES = 1;
constexpr uint16_t MAX_HOUSE_PLANNER_NODES = 100;
constexpr unsigned long MAINTENANCE_SESSION_TIMEOUT_MS = 30UL * 60UL * 1000UL;
constexpr char MAINTENANCE_TOKEN_HEADER[] = "X-FBB-Maintenance-Token";
constexpr size_t MIN_ACCESS_PASSWORD_LENGTH = 8;
constexpr size_t MAX_ACCESS_PASSWORD_LENGTH = 63;
constexpr size_t MAX_WIFI_SSID_LENGTH = 32;
constexpr size_t MAX_WIFI_PASSWORD_LENGTH = 63;
constexpr size_t MAX_NOTIFICATION_EMAIL_LENGTH = 96;
constexpr size_t MAX_NOTIFICATION_URL_LENGTH = 160;
constexpr size_t MAX_CLUCK_MODULES = 4;

constexpr uint8_t UNUSED_PIN = 255;
// Default to safer, non-strapping GPIOs for the production board.
// Override these at compile time if a legacy board is still in service.
#ifndef FBB_PIN_BUTTON
constexpr uint8_t PIN_BUTTON = 35;
#else
constexpr uint8_t PIN_BUTTON = FBB_PIN_BUTTON;
#endif
#ifndef FBB_PIN_RELAY_1
constexpr uint8_t PIN_RELAY_1 = 26;
#else
constexpr uint8_t PIN_RELAY_1 = FBB_PIN_RELAY_1;
#endif
#ifndef FBB_PIN_RELAY_2
constexpr uint8_t PIN_RELAY_2 = 27;
#else
constexpr uint8_t PIN_RELAY_2 = FBB_PIN_RELAY_2;
#endif
#ifndef FBB_PIN_LED
constexpr uint8_t PIN_LED = 33;
#else
constexpr uint8_t PIN_LED = FBB_PIN_LED;
#endif
#ifndef FBB_PIN_FEED_SENSOR
constexpr uint8_t PIN_FEED_SENSOR = 34;
#else
constexpr uint8_t PIN_FEED_SENSOR = FBB_PIN_FEED_SENSOR;
#endif
#ifndef FBB_PIN_EMERGENCY_STOP
constexpr uint8_t PIN_EMERGENCY_STOP = UNUSED_PIN;
#else
constexpr uint8_t PIN_EMERGENCY_STOP = FBB_PIN_EMERGENCY_STOP;
#endif
constexpr bool FEED_PRESENT_WHEN_HIGH = true;
constexpr unsigned long FEED_DEBOUNCE_MS = 150;
constexpr unsigned long BUTTON_DEBOUNCE_MS = 50;
constexpr unsigned long BUTTON_LONG_PRESS_MS = 1500;

// Relay / LED / sensor polarity defaults can be overridden at compile time for
// board variants so first boot is already safe and wired correctly.
#ifndef FBB_RELAY_ACTIVE_HIGH
constexpr bool RELAY_ACTIVE_HIGH = true;
#else
constexpr bool RELAY_ACTIVE_HIGH = FBB_RELAY_ACTIVE_HIGH;
#endif
#ifndef FBB_LED_ACTIVE_HIGH
constexpr bool LED_ACTIVE_HIGH = false;
#else
constexpr bool LED_ACTIVE_HIGH = FBB_LED_ACTIVE_HIGH;
#endif
#ifndef FBB_FEED_SENSOR_ACTIVE_HIGH
constexpr bool FEED_SENSOR_ACTIVE_HIGH = true;
#else
constexpr bool FEED_SENSOR_ACTIVE_HIGH = FBB_FEED_SENSOR_ACTIVE_HIGH;
#endif
#ifndef FBB_EMERGENCY_STOP_ACTIVE_HIGH
constexpr bool EMERGENCY_STOP_ACTIVE_HIGH = true;
#else
constexpr bool EMERGENCY_STOP_ACTIVE_HIGH = FBB_EMERGENCY_STOP_ACTIVE_HIGH;
#endif

WebServer server(80);
HTTPUpdateServer httpUpdater;
Preferences preferences;
bool relay1On = false;
bool relay2On = false;
bool ledOn = false;
bool apRunning = false;
bool apSecure = true;
bool apPasswordEnabled = false;
bool espNowReady = false;
bool feedPresent = false;
bool feedCandidate = false;
bool alarmBlinkOn = false;
bool emergencyStopLatched = false;
bool faultLatched = false;
String faultReason = "";
String deviceWifiPassword;
String deviceAdminPassword;
bool hardwareEmergencyStopActive = false;
bool watchdogActive = false;
String bootReasonLabel = "unknown";
unsigned long lastStatusLogMs = 0;
unsigned long lastApRetryMs = 0;
unsigned long lastEspNowRetryMs = 0;
unsigned long lastAlarmBlinkMs = 0;
unsigned long lastConfigSaveMs = 0;
unsigned long apNoStationSinceMs = 0;
unsigned long apLastStationChangeMs = 0;
uint8_t apLastStationCount = 0;
bool apDisconnectGuardArmed = false;
unsigned long feedCandidateSinceMs = 0;
unsigned long lowFeedSinceMs = 0;
unsigned long feedPresentSinceMs = 0;
bool buttonRawPressed = false;
bool buttonStablePressed = false;
bool buttonLongPressHandled = false;
unsigned long buttonLastTransitionMs = 0;
unsigned long buttonPressStartedMs = 0;
unsigned long buttonLastActionMs = 0;
String buttonLastAction = "none";
unsigned long noRunoutAlarmDelayMs = DEFAULT_NO_RUNOUT_ALARM_MS;
unsigned long emptyTooLongAlarmDelayMs = DEFAULT_EMPTY_TOO_LONG_ALARM_MS;
unsigned long manualOverrideTimeoutMs = DEFAULT_MANUAL_OVERRIDE_TIMEOUT_MS;
unsigned long manualControlOverrideUntilMs = 0;
unsigned long relayMaxRuntimeMs = DEFAULT_RELAY_MAX_RUNTIME_MS;
unsigned long automationKeepaliveMs = DEFAULT_AUTOMATION_KEEPALIVE_MS;
unsigned long relayOnSinceMs[2] = {0, 0};
unsigned long relayLeaseUntilMs[2] = {0, 0};
uint8_t relayLeaseOwner[2] = {0, 0};
bool relayActiveHigh = RELAY_ACTIVE_HIGH;
bool ledActiveHigh = LED_ACTIVE_HIGH;
bool feedPresentWhenHigh = FEED_SENSOR_ACTIVE_HIGH;
bool configDirty = false;
bool configLoaded = false;
bool rebootPending = false;
unsigned long rebootRequestedMs = 0;
String rebootReason = "";
unsigned long lastConfigSaveAttemptMs = 0;
unsigned long configDirtySinceMs = 0;
bool configSaveFault = false;
String configSaveFaultReason = "";
String maintenanceSessionToken;
unsigned long maintenanceSessionCreatedMs = 0;
bool stationWifiEnabled = false;
String stationWifiSsid = "";
String stationWifiPassword = "";
bool stationWifiConnecting = false;
bool stationWifiEverConnected = false;
unsigned long stationWifiLastAttemptMs = 0;
unsigned long stationWifiConnectedAtMs = 0;
wl_status_t stationWifiLastStatus = WL_IDLE_STATUS;
bool notificationEmailEnabled = false;
String notificationEmailTo = "";
String notificationHubUrl = "";
String notificationLastStatus = "disabled";
unsigned long notificationLastAttemptMs = 0;
unsigned long notificationLastSuccessMs = 0;

enum class RelayOwner : uint8_t {
  None = 0,
  Manual = 1,
  Automation = 2,
  EspNow = 3
};

struct EventLogEntry {
  unsigned long ms;
  char message[MAX_EVENT_LOG_MESSAGE];
};

EventLogEntry eventLog[MAX_EVENT_LOG_ENTRIES];
size_t eventLogHead = 0;
size_t eventLogCount = 0;

struct CluckMagicModule {
  bool used;
  uint8_t mac[6];
  char name[ESPNOW_MODULE_NAME_LEN];
  unsigned long lastSeenMs;
  bool relay1On;
  bool relay2On;
  bool emergencyStop;
  bool fault;
  uint16_t sequence;
};

enum class AlarmState : uint8_t {
  Normal = 0,
  NoRunoutTooLong = 1,
  EmptyTooLong = 2
};

enum class ControllerState : uint8_t {
  Ready = 0,
  BootWait = 1,
  DisconnectGrace = 2,
  ApOffline = 3,
  EmergencyStop = 4,
  Fault = 5,
  RebootPending = 6
};

AlarmState alarmState = AlarmState::Normal;
AlarmState notificationLastAlarmState = AlarmState::Normal;
AlarmState alarmLastClearedState = AlarmState::Normal;
unsigned long alarmLastClearedMs = 0;
String alarmLastClearReason = "none";

enum class FeedLogicMode : uint8_t {
  Manual = 0,
  AutoSwitch = 1,
  AlternateCycle = 2,
  TimedAlternate = 3,
  SensorDemand = 4
};

FeedLogicMode feedLogicMode = FeedLogicMode::Manual;
String feedBin1Name = "Feed Bin 1";
String feedBin2Name = "Feed Bin 2";
unsigned long feedLogicAlternateMs = DEFAULT_LOGIC_ALTERNATE_MS;
unsigned long feedLogicAutoSwitchMs = DEFAULT_LOGIC_AUTO_SWITCH_MS;
unsigned long feedLogicTopOffMs = DEFAULT_LOGIC_TOP_OFF_MS;
unsigned long feedLogicLastAlternateMs = 0;
unsigned long feedLogicActiveBinSinceMs = 0;
unsigned long feedLogicTopOffStartedMs = 0;
uint8_t feedLogicPreferredBin = 1;
uint8_t feedLogicActiveBin = 0;
bool feedLogicSwitchedThisCycle = false;
bool feedLogicTopOffActive = false;

String plannerHouseName = "House 1";
String plannerNotes = "";
uint16_t plannerNodesTarget = DEFAULT_HOUSE_PLANNER_NODES;
bool plannerMeshEnabled = true;
bool plannerTrackBinLevel = true;
bool plannerTrackBinClog = true;
bool plannerTrackVibrator = true;
bool plannerTrackHopperAuger = true;
bool plannerTrackLineAuger = true;
bool plannerTrackMotorCurrent = true;

volatile bool espNowCommandPending = false;
EspNowCommand pendingEspNowCommand = {0, ESPNOW_RELAY_NONE, ESPNOW_ACTION_OFF, ESPNOW_LED_IGNORE};
volatile bool espNowModulePacketPending = false;
EspNowModulePacket pendingEspNowModulePacket = {};
uint8_t pendingEspNowModuleSender[6] = {0};
uint32_t espNowPacketsRx = 0;
uint32_t espNowPacketsTx = 0;
unsigned long espNowLastRxMs = 0;
unsigned long espNowLastTxMs = 0;
uint8_t espNowLastSender[6] = {0};
CluckMagicModule cluckMagicModules[MAX_CLUCK_MODULES] = {};
String cluckMagicSelectedMac = "";
String cluckMagicLastCommandStatus = "none";
unsigned long cluckMagicLastCommandMs = 0;
unsigned long cluckMagicLastAnnounceMs = 0;
uint16_t espNowModuleSequence = 0;
portMUX_TYPE espNowMux = portMUX_INITIALIZER_UNLOCKED;

int signalLevelForState(const bool logicalOn, const bool activeHigh) {
  return (logicalOn == activeHigh) ? HIGH : LOW;
}

bool pinIsConfigured(const uint8_t pin) {
  return pin != UNUSED_PIN;
}

void initializeOutputPinInactive(const uint8_t pin, const bool activeHigh) {
  if (!pinIsConfigured(pin)) {
    return;
  }

  // Preload the inactive state before switching the pad to an output.
  // This keeps the relay/LED line parked OFF during boot and reconfiguration.
  digitalWrite(pin, signalLevelForState(false, activeHigh));
  pinMode(pin, OUTPUT);
}

void initializeEmergencyStopInput() {
  if (!pinIsConfigured(PIN_EMERGENCY_STOP)) {
    return;
  }

  // Bias the stop loop so an open circuit resolves to the safe state.
  pinMode(PIN_EMERGENCY_STOP, EMERGENCY_STOP_ACTIVE_HIGH ? INPUT_PULLUP : INPUT_PULLDOWN);
}

bool buttonPressed() {
  return pinIsConfigured(PIN_BUTTON) && digitalRead(PIN_BUTTON) == LOW;
}

void applyOutputs() {
  if (pinIsConfigured(PIN_RELAY_1)) {
    digitalWrite(PIN_RELAY_1, signalLevelForState(relay1On, relayActiveHigh));
  }
  if (pinIsConfigured(PIN_RELAY_2)) {
    digitalWrite(PIN_RELAY_2, signalLevelForState(relay2On, relayActiveHigh));
  }
  if (pinIsConfigured(PIN_LED)) {
    digitalWrite(PIN_LED, signalLevelForState(ledOn, ledActiveHigh));
  }
}

bool readFeedRawActive() {
  if (!pinIsConfigured(PIN_FEED_SENSOR)) {
    return feedPresentWhenHigh;
  }
  return digitalRead(PIN_FEED_SENSOR) == HIGH;
}

bool decodeFeedPresent(const bool rawActive) {
  return feedPresentWhenHigh ? rawActive : !rawActive;
}

void logEvent(const String &message);
void engageEmergencyStop(const char *reason);
bool resetEmergencyStop();
void initializeEmergencyStopState();
void updateEmergencyStopState();
bool directControlLocked();
void markConfigDirty();
bool stationWifiConfigured();
bool stationWifiConnected();
bool accessPasswordRequired();
void beginStationWifi(const char *reason = nullptr);
void updateStationWifi();
void maybeSendAlarmNotification(const AlarmState state);
void clearFeedAlarm(const char *reason);
void forceAllRelaysOff(const char *reason, const bool logAction = true);
uint8_t oppositeBin(const uint8_t bin);
void setOnlyFeedBin(const uint8_t bin);
void updateLocalButtonState();
String formatDurationText(const unsigned long ms);
void clearMaintenanceSession(const char *reason = nullptr);
bool maintenanceSessionMatchesCurrentRequest();
unsigned long maintenanceSessionRemainingMs(const unsigned long now);
bool requireMaintenanceSession(const char *actionName);
void handleMaintenanceUnlock();

void initializeFeedSensorState() {
  const unsigned long now = millis();
  const bool raw = readFeedRawActive();
  feedPresent = decodeFeedPresent(raw);
  feedCandidate = feedPresent;
  feedCandidateSinceMs = now;
  lowFeedSinceMs = feedPresent ? 0 : now;
  feedPresentSinceMs = feedPresent ? now : 0;
}

bool readEmergencyStopRawActive() {
  return pinIsConfigured(PIN_EMERGENCY_STOP) && digitalRead(PIN_EMERGENCY_STOP) == HIGH;
}

bool decodeEmergencyStopActive(const bool rawActive) {
  return EMERGENCY_STOP_ACTIVE_HIGH ? rawActive : !rawActive;
}

bool hardwareEmergencyStopInputActive() {
  return decodeEmergencyStopActive(readEmergencyStopRawActive());
}

void initializeEmergencyStopState() {
  hardwareEmergencyStopActive = hardwareEmergencyStopInputActive();
  if (hardwareEmergencyStopActive) {
    engageEmergencyStop("hardware emergency stop input active at boot");
  }
}

void updateEmergencyStopState() {
  if (!pinIsConfigured(PIN_EMERGENCY_STOP)) {
    hardwareEmergencyStopActive = false;
    return;
  }

  const bool active = hardwareEmergencyStopInputActive();
  if (active != hardwareEmergencyStopActive) {
    hardwareEmergencyStopActive = active;
    logEvent(String("Hardware emergency stop input -> ") + (active ? "ACTIVE" : "CLEAR"));
  }

  if (active && !emergencyStopLatched) {
    engageEmergencyStop("hardware emergency stop input");
  }
}

void recordLocalButtonAction(const String &action) {
  buttonLastAction = action;
  buttonLastActionMs = millis();
}

void handleLocalButtonShortPress() {
  if (directControlLocked()) {
    recordLocalButtonAction("short press ignored (locked)");
    return;
  }

  if (feedLogicMode != FeedLogicMode::Manual) {
    recordLocalButtonAction("short press ignored (auto mode)");
    return;
  }

  if (relay1On || relay2On) {
    forceAllRelaysOff("local button short press");
    recordLocalButtonAction("short press -> outputs OFF");
    logEvent("Local button short press -> outputs OFF");
    return;
  }

  setOnlyFeedBin(feedLogicPreferredBin);
  recordLocalButtonAction(String("short press -> bin ") + String(feedLogicPreferredBin) + " ON");
  logEvent(String("Local button short press -> bin ") + String(feedLogicPreferredBin) + " ON");
}

void handleLocalButtonLongPress() {
  if (directControlLocked()) {
    recordLocalButtonAction("long press ignored (locked)");
    return;
  }

  feedLogicPreferredBin = oppositeBin(feedLogicPreferredBin);
  markConfigDirty();
  recordLocalButtonAction(String("long press -> preferred bin ") + String(feedLogicPreferredBin));
  logEvent(String("Local button long press -> preferred bin ") + String(feedLogicPreferredBin));
}

void updateLocalButtonState() {
  if (!pinIsConfigured(PIN_BUTTON)) {
    return;
  }

  const unsigned long now = millis();
  const bool rawPressed = buttonPressed();

  if (rawPressed != buttonRawPressed) {
    buttonRawPressed = rawPressed;
    buttonLastTransitionMs = now;
  }

  if (rawPressed != buttonStablePressed &&
      now - buttonLastTransitionMs >= BUTTON_DEBOUNCE_MS) {
    buttonStablePressed = rawPressed;

    if (buttonStablePressed) {
      buttonPressStartedMs = now;
      buttonLongPressHandled = false;
      logEvent("Local button pressed.");
      return;
    }

    const unsigned long heldMs =
        buttonPressStartedMs != 0 ? (now - buttonPressStartedMs) : 0;
    if (!buttonLongPressHandled && heldMs >= BUTTON_DEBOUNCE_MS) {
      handleLocalButtonShortPress();
    }
    buttonPressStartedMs = 0;
    buttonLongPressHandled = false;
    return;
  }

  if (buttonStablePressed && !buttonLongPressHandled && buttonPressStartedMs != 0 &&
      now - buttonPressStartedMs >= BUTTON_LONG_PRESS_MS) {
    buttonLongPressHandled = true;
    handleLocalButtonLongPress();
  }
}

void updateFeedSensorState() {
  const unsigned long now = millis();
  const bool raw = readFeedRawActive();
  const bool decoded = decodeFeedPresent(raw);

  if (decoded != feedCandidate) {
    feedCandidate = decoded;
    feedCandidateSinceMs = now;
  }

  if ((feedPresent != feedCandidate) && (now - feedCandidateSinceMs >= FEED_DEBOUNCE_MS)) {
    feedPresent = feedCandidate;
    if (feedPresent) {
      lowFeedSinceMs = 0;
      feedPresentSinceMs = now;
      Serial.println("Feed status: PRESENT");
      logEvent("Feed status: PRESENT");
    } else {
      lowFeedSinceMs = now;
      feedPresentSinceMs = 0;
      Serial.println("Feed status: LOW");
      logEvent("Feed status: LOW");
    }
  }
}

const char *alarmStateName(const AlarmState state) {
  switch (state) {
    case AlarmState::NoRunoutTooLong:
      return "no_runout_too_long";
    case AlarmState::EmptyTooLong:
      return "empty_too_long";
    case AlarmState::Normal:
    default:
      return "normal";
  }
}

unsigned long clampAlarmMs(const unsigned long valueMs) {
  if (valueMs < MIN_ALARM_MS) {
    return MIN_ALARM_MS;
  }
  if (valueMs > MAX_ALARM_MS) {
    return MAX_ALARM_MS;
  }
  return valueMs;
}

unsigned long scaleToMsClamped(const unsigned long value,
                               const uint64_t unitMs,
                               const unsigned long minMs,
                               const unsigned long maxMs) {
  const uint64_t rawMs = static_cast<uint64_t>(value) * unitMs;
  if (rawMs > static_cast<uint64_t>(maxMs)) {
    return maxMs;
  }
  unsigned long scaledMs = static_cast<unsigned long>(rawMs);
  if (scaledMs < minMs) {
    scaledMs = minMs;
  }
  if (scaledMs > maxMs) {
    scaledMs = maxMs;
  }
  return scaledMs;
}

unsigned long minutesToMsClamped(const unsigned long minutes) {
  return scaleToMsClamped(minutes, 60000ULL, MIN_ALARM_MS, MAX_ALARM_MS);
}

unsigned long clampRange(const unsigned long value,
                         const unsigned long minValue,
                         const unsigned long maxValue) {
  if (value < minValue) {
    return minValue;
  }
  if (value > maxValue) {
    return maxValue;
  }
  return value;
}

const char *feedLogicModeName(const FeedLogicMode mode) {
  switch (mode) {
    case FeedLogicMode::SensorDemand:
      return "sensor_demand";
    case FeedLogicMode::AutoSwitch:
      return "auto_switch";
    case FeedLogicMode::AlternateCycle:
      return "alternate_cycle";
    case FeedLogicMode::TimedAlternate:
      return "timed_alternate";
    case FeedLogicMode::Manual:
    default:
      return "manual";
  }
}

const char *feedLogicModeLabel(const FeedLogicMode mode) {
  switch (mode) {
    case FeedLogicMode::SensorDemand:
      return "Hopper Sensor";
    case FeedLogicMode::AutoSwitch:
      return "Auto Switch";
    case FeedLogicMode::AlternateCycle:
      return "Alternate Each Fill";
    case FeedLogicMode::TimedAlternate:
      return "Timed Alternate";
    case FeedLogicMode::Manual:
    default:
      return "Manual";
  }
}

const char *feedLogicModeRunRule(const FeedLogicMode mode) {
  switch (mode) {
    case FeedLogicMode::SensorDemand:
      return "Sensor low starts the preferred bin; feed present starts the hopper top-off timer, then stops both bins.";
    case FeedLogicMode::AutoSwitch:
      return "Sensor low starts the preferred bin; if feed does not recover before timeout, switch once, then use hopper top-off after feed is present.";
    case FeedLogicMode::AlternateCycle:
      return "Sensor low starts the preferred bin; after hopper top-off completes, stop both bins and make the other bin preferred next time.";
    case FeedLogicMode::TimedAlternate:
      return "Sensor low starts the preferred bin; feed present starts hopper top-off, and the preferred bin alternates by timer while idle.";
    case FeedLogicMode::Manual:
    default:
      return "Manual switches and buttons control the bins; the hopper sensor only reports status and alarms.";
  }
}

bool parseFeedLogicMode(String modeValue, FeedLogicMode &outMode) {
  modeValue.trim();
  modeValue.toLowerCase();

  if (modeValue == "manual") {
    outMode = FeedLogicMode::Manual;
    return true;
  }
  if (modeValue == "sensor_demand" || modeValue == "sensor_auto" ||
      modeValue == "hopper_sensor" || modeValue == "sensor") {
    outMode = FeedLogicMode::SensorDemand;
    return true;
  }
  if (modeValue == "auto_switch") {
    outMode = FeedLogicMode::AutoSwitch;
    return true;
  }
  if (modeValue == "alternate_cycle" || modeValue == "alternate") {
    outMode = FeedLogicMode::AlternateCycle;
    return true;
  }
  if (modeValue == "timed_alternate") {
    outMode = FeedLogicMode::TimedAlternate;
    return true;
  }
  return false;
}

String normalizedFeedBinName(const String &inputValue, const char *fallback) {
  String value = inputValue;
  value.trim();
  if (value.length() == 0) {
    return String(fallback);
  }
  if (value.length() > 32) {
    return value.substring(0, 32);
  }
  return value;
}

String normalizedLimited(const String &inputValue, const char *fallback, const size_t maxLen) {
  String value = inputValue;
  value.trim();
  if (value.length() == 0) {
    return String(fallback);
  }
  if (value.length() > maxLen) {
    return value.substring(0, maxLen);
  }
  return value;
}

String normalizedOptionalLimited(const String &inputValue, const size_t maxLen) {
  String value = inputValue;
  value.trim();
  if (value.length() > maxLen) {
    return value.substring(0, maxLen);
  }
  return value;
}

int hexNibble(const char c) {
  if (c >= '0' && c <= '9') {
    return c - '0';
  }
  if (c >= 'a' && c <= 'f') {
    return c - 'a' + 10;
  }
  if (c >= 'A' && c <= 'F') {
    return c - 'A' + 10;
  }
  return -1;
}

bool parseMacString(String value, uint8_t outMac[6]) {
  value.trim();
  if (value.length() == 0) {
    return false;
  }
  value.replace("-", ":");
  value.toUpperCase();
  if (value.length() != 17) {
    return false;
  }

  for (size_t i = 0; i < 6; ++i) {
    const size_t pos = i * 3;
    if (i < 5 && value[pos + 2] != ':') {
      return false;
    }
    const int hi = hexNibble(value[pos]);
    const int lo = hexNibble(value[pos + 1]);
    if (hi < 0 || lo < 0) {
      return false;
    }
    outMac[i] = static_cast<uint8_t>((hi << 4) | lo);
  }
  return true;
}

String normalizedMacString(const String &inputValue) {
  uint8_t mac[6] = {0};
  if (!parseMacString(inputValue, mac)) {
    return "";
  }

  char buf[18];
  snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(buf);
}

bool parseBoolLike(const String &value, bool &outValue) {
  String v = value;
  v.trim();
  v.toLowerCase();
  if (v == "1" || v == "true" || v == "on" || v == "yes") {
    outValue = true;
    return true;
  }
  if (v == "0" || v == "false" || v == "off" || v == "no") {
    outValue = false;
    return true;
  }
  return false;
}

bool sanitizePersistentConfig() {
  bool changed = false;

  const String sanitizedBin1 = normalizedFeedBinName(feedBin1Name, "Feed Bin 1");
  if (sanitizedBin1 != feedBin1Name) {
    feedBin1Name = sanitizedBin1;
    changed = true;
  }

  const String sanitizedBin2 = normalizedFeedBinName(feedBin2Name, "Feed Bin 2");
  if (sanitizedBin2 != feedBin2Name) {
    feedBin2Name = sanitizedBin2;
    changed = true;
  }

  const String sanitizedHouse = normalizedLimited(plannerHouseName, "House 1", 32);
  if (sanitizedHouse != plannerHouseName) {
    plannerHouseName = sanitizedHouse;
    changed = true;
  }

  const String sanitizedNotes = normalizedLimited(plannerNotes, "", 240);
  if (sanitizedNotes != plannerNotes) {
    plannerNotes = sanitizedNotes;
    changed = true;
  }

  const String sanitizedStationSsid = normalizedOptionalLimited(stationWifiSsid, MAX_WIFI_SSID_LENGTH);
  if (sanitizedStationSsid != stationWifiSsid) {
    stationWifiSsid = sanitizedStationSsid;
    changed = true;
  }

  const String sanitizedStationPassword =
      normalizedOptionalLimited(stationWifiPassword, MAX_WIFI_PASSWORD_LENGTH);
  if (sanitizedStationPassword != stationWifiPassword) {
    stationWifiPassword = sanitizedStationPassword;
    changed = true;
  }

  if (stationWifiEnabled && stationWifiSsid.length() == 0) {
    stationWifiEnabled = false;
    changed = true;
  }

  const String sanitizedNotificationEmail =
      normalizedOptionalLimited(notificationEmailTo, MAX_NOTIFICATION_EMAIL_LENGTH);
  if (sanitizedNotificationEmail != notificationEmailTo) {
    notificationEmailTo = sanitizedNotificationEmail;
    changed = true;
  }

  const String sanitizedNotificationUrl =
      normalizedOptionalLimited(notificationHubUrl, MAX_NOTIFICATION_URL_LENGTH);
  if (sanitizedNotificationUrl != notificationHubUrl) {
    notificationHubUrl = sanitizedNotificationUrl;
    changed = true;
  }

  if (notificationEmailEnabled &&
      (notificationEmailTo.length() == 0 || notificationHubUrl.length() == 0)) {
    notificationEmailEnabled = false;
    changed = true;
  }

  const String sanitizedCluckMac = normalizedMacString(cluckMagicSelectedMac);
  if (sanitizedCluckMac != cluckMagicSelectedMac) {
    cluckMagicSelectedMac = sanitizedCluckMac;
    changed = true;
  }

  if (feedLogicMode != FeedLogicMode::Manual &&
      feedLogicMode != FeedLogicMode::SensorDemand &&
      feedLogicMode != FeedLogicMode::AutoSwitch &&
      feedLogicMode != FeedLogicMode::AlternateCycle &&
      feedLogicMode != FeedLogicMode::TimedAlternate) {
    feedLogicMode = FeedLogicMode::Manual;
    changed = true;
  }

  if (feedLogicPreferredBin != 1 && feedLogicPreferredBin != 2) {
    feedLogicPreferredBin = 1;
    changed = true;
  }

  const unsigned long sanitizedNoRunout = clampAlarmMs(noRunoutAlarmDelayMs);
  if (sanitizedNoRunout != noRunoutAlarmDelayMs) {
    noRunoutAlarmDelayMs = sanitizedNoRunout;
    changed = true;
  }

  const unsigned long sanitizedEmptyTooLong = clampAlarmMs(emptyTooLongAlarmDelayMs);
  if (sanitizedEmptyTooLong != emptyTooLongAlarmDelayMs) {
    emptyTooLongAlarmDelayMs = sanitizedEmptyTooLong;
    changed = true;
  }

  const unsigned long sanitizedManualLease =
      clampRange(manualOverrideTimeoutMs, 10UL * 1000UL, 30UL * 60UL * 1000UL);
  if (sanitizedManualLease != manualOverrideTimeoutMs) {
    manualOverrideTimeoutMs = sanitizedManualLease;
    changed = true;
  }

  const unsigned long sanitizedRelayMax =
      clampRange(relayMaxRuntimeMs, 1UL * 60UL * 1000UL, 60UL * 60UL * 1000UL);
  if (sanitizedRelayMax != relayMaxRuntimeMs) {
    relayMaxRuntimeMs = sanitizedRelayMax;
    changed = true;
  }

  const unsigned long sanitizedAutomationKeepalive =
      clampRange(automationKeepaliveMs, 5UL * 1000UL, 5UL * 60UL * 1000UL);
  if (sanitizedAutomationKeepalive != automationKeepaliveMs) {
    automationKeepaliveMs = sanitizedAutomationKeepalive;
    changed = true;
  }

  const unsigned long sanitizedLogicAlternate =
      clampRange(feedLogicAlternateMs, MIN_LOGIC_ALTERNATE_MS, MAX_LOGIC_ALTERNATE_MS);
  if (sanitizedLogicAlternate != feedLogicAlternateMs) {
    feedLogicAlternateMs = sanitizedLogicAlternate;
    changed = true;
  }

  const unsigned long sanitizedLogicAutoSwitch =
      clampRange(feedLogicAutoSwitchMs, MIN_LOGIC_AUTO_SWITCH_MS, MAX_LOGIC_AUTO_SWITCH_MS);
  if (sanitizedLogicAutoSwitch != feedLogicAutoSwitchMs) {
    feedLogicAutoSwitchMs = sanitizedLogicAutoSwitch;
    changed = true;
  }

  const unsigned long sanitizedLogicTopOff =
      clampRange(feedLogicTopOffMs, MIN_LOGIC_TOP_OFF_MS, MAX_LOGIC_TOP_OFF_MS);
  if (sanitizedLogicTopOff != feedLogicTopOffMs) {
    feedLogicTopOffMs = sanitizedLogicTopOff;
    changed = true;
  }

  const uint16_t sanitizedPlannerNodes = static_cast<uint16_t>(clampRange(
      static_cast<unsigned long>(plannerNodesTarget),
      MIN_HOUSE_PLANNER_NODES,
      MAX_HOUSE_PLANNER_NODES));
  if (sanitizedPlannerNodes != plannerNodesTarget) {
    plannerNodesTarget = sanitizedPlannerNodes;
    changed = true;
  }

  return changed;
}

String jsonEscape(const String &input) {
  String out;
  out.reserve(input.length() + 8);
  for (size_t i = 0; i < input.length(); ++i) {
    const char c = input[i];
    if (c == '\"') {
      out += "\\\"";
    } else if (c == '\\') {
      out += "\\\\";
    } else if (c == '\n') {
      out += "\\n";
    } else if (c == '\r') {
      out += "\\r";
    } else if (c == '\t') {
      out += "\\t";
    } else {
      out += c;
    }
  }
  return out;
}

enum class JsonFieldResult : uint8_t {
  Missing = 0,
  Parsed = 1,
  Invalid = 2
};

bool parseUnsignedDigits(const char *text, size_t length, unsigned long &outValue);

bool jsonIsWhitespace(const char c) {
  return c == ' ' || c == '\t' || c == '\r' || c == '\n';
}

bool jsonValueTerminated(const String &json, const size_t valueEndPos) {
  if (valueEndPos >= json.length()) {
    return true;
  }

  const char next = json[valueEndPos];
  return jsonIsWhitespace(next) || next == ',' || next == '}' || next == ']';
}

bool jsonLocateFieldValue(const String &json, const char *key, size_t &valuePos) {
  const String needle = String("\"") + key + "\"";
  const int keyPos = json.indexOf(needle);
  if (keyPos < 0) {
    return false;
  }

  const int colonPos = json.indexOf(':', keyPos + static_cast<int>(needle.length()));
  if (colonPos < 0) {
    return false;
  }

  valuePos = static_cast<size_t>(colonPos + 1);
  while (valuePos < json.length() && jsonIsWhitespace(json[valuePos])) {
    ++valuePos;
  }
  return valuePos < json.length();
}

JsonFieldResult extractJsonStringField(const String &json, const char *key, String &out) {
  size_t valuePos = 0;
  if (!jsonLocateFieldValue(json, key, valuePos)) {
    return JsonFieldResult::Missing;
  }
  if (json[valuePos] != '"') {
    return JsonFieldResult::Invalid;
  }

  String value;
  bool escape = false;
  for (++valuePos; valuePos < json.length(); ++valuePos) {
    const char c = json[valuePos];
    if (escape) {
      switch (c) {
        case '"':
        case '\\':
        case '/':
          value += c;
          break;
        case 'b':
          value += '\b';
          break;
        case 'f':
          value += '\f';
          break;
        case 'n':
          value += '\n';
          break;
        case 'r':
          value += '\r';
          break;
        case 't':
          value += '\t';
          break;
        default:
          value += c;
          break;
      }
      escape = false;
      continue;
    }

    if (c == '\\') {
      escape = true;
      continue;
    }
    if (c == '"') {
      out = value;
      return JsonFieldResult::Parsed;
    }
    value += c;
  }

  return JsonFieldResult::Invalid;
}

JsonFieldResult extractJsonBoolField(const String &json, const char *key, bool &out) {
  size_t valuePos = 0;
  if (!jsonLocateFieldValue(json, key, valuePos)) {
    return JsonFieldResult::Missing;
  }

  if (json.startsWith("true", valuePos) && jsonValueTerminated(json, valuePos + 4)) {
    out = true;
    return JsonFieldResult::Parsed;
  }
  if (json.startsWith("false", valuePos) && jsonValueTerminated(json, valuePos + 5)) {
    out = false;
    return JsonFieldResult::Parsed;
  }
  if (json[valuePos] == '1' && jsonValueTerminated(json, valuePos + 1)) {
    out = true;
    return JsonFieldResult::Parsed;
  }
  if (json[valuePos] == '0' && jsonValueTerminated(json, valuePos + 1)) {
    out = false;
    return JsonFieldResult::Parsed;
  }

  return JsonFieldResult::Invalid;
}

JsonFieldResult extractJsonUnsignedField(const String &json, const char *key, unsigned long &out) {
  size_t valuePos = 0;
  if (!jsonLocateFieldValue(json, key, valuePos)) {
    return JsonFieldResult::Missing;
  }

  size_t endPos = valuePos;
  while (endPos < json.length() && isDigit(json[endPos])) {
    ++endPos;
  }
  if (endPos == valuePos) {
    return JsonFieldResult::Invalid;
  }
  if (!jsonValueTerminated(json, endPos)) {
    return JsonFieldResult::Invalid;
  }

  if (!parseUnsignedDigits(json.c_str() + valuePos, endPos - valuePos, out)) {
    return JsonFieldResult::Invalid;
  }
  return JsonFieldResult::Parsed;
}

String generateAccessPassword() {
  static constexpr char PASSWORD_ALPHABET[] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  char buf[21];
  for (size_t i = 0; i < 16; ++i) {
    buf[i] = PASSWORD_ALPHABET[esp_random() % (sizeof(PASSWORD_ALPHABET) - 1)];
  }
  buf[16] = '\0';
  return String("FBB-") + buf;
}

String generateMaintenanceToken() {
  static constexpr char TOKEN_ALPHABET[] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  char buf[21];
  for (size_t i = 0; i < 16; ++i) {
    buf[i] = TOKEN_ALPHABET[esp_random() % (sizeof(TOKEN_ALPHABET) - 1)];
  }
  buf[16] = '\0';
  return String("FBB-M-") + buf;
}

const char *relayOwnerName(const uint8_t ownerValue) {
  switch (static_cast<RelayOwner>(ownerValue)) {
    case RelayOwner::Manual:
      return "manual";
    case RelayOwner::Automation:
      return "automation";
    case RelayOwner::EspNow:
      return "espnow";
    case RelayOwner::None:
    default:
      return "none";
  }
}

const char *bootReasonName(const esp_reset_reason_t reason) {
  switch (reason) {
    case ESP_RST_POWERON:
      return "power_on";
    case ESP_RST_EXT:
      return "external_reset";
    case ESP_RST_SW:
      return "software_reset";
    case ESP_RST_PANIC:
      return "panic";
    case ESP_RST_INT_WDT:
      return "interrupt_watchdog";
    case ESP_RST_TASK_WDT:
      return "task_watchdog";
    case ESP_RST_WDT:
      return "other_watchdog";
    case ESP_RST_DEEPSLEEP:
      return "deep_sleep";
    case ESP_RST_BROWNOUT:
      return "brownout";
    case ESP_RST_SDIO:
      return "sdio";
    default:
      return "unknown";
  }
}

bool timeReached(const unsigned long now, const unsigned long targetMs) {
  return targetMs != 0 && static_cast<long>(now - targetMs) >= 0;
}

void logEvent(const String &message) {
  EventLogEntry &entry = eventLog[eventLogHead];
  entry.ms = millis();
  snprintf(entry.message, sizeof(entry.message), "%s", message.c_str());
  eventLogHead = (eventLogHead + 1) % MAX_EVENT_LOG_ENTRIES;
  if (eventLogCount < MAX_EVENT_LOG_ENTRIES) {
    ++eventLogCount;
  }

  Serial.print("[");
  Serial.print(entry.ms);
  Serial.print("] ");
  Serial.println(entry.message);
}

void sendSecurityHeaders() {
  server.sendHeader("X-Content-Type-Options", "nosniff");
  server.sendHeader("X-Frame-Options", "DENY");
  server.sendHeader("Referrer-Policy", "no-referrer");
  server.sendHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  server.sendHeader("Cross-Origin-Resource-Policy", "same-origin");
  server.sendHeader("Content-Security-Policy",
                    "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' "
                    "'unsafe-inline'; script-src 'self' 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'; "
                    "form-action 'self'");
}

void sendNoStoreHeaders() {
  sendSecurityHeaders();
  server.sendHeader("Cache-Control", "no-store, max-age=0");
  server.sendHeader("Pragma", "no-cache");
  server.sendHeader("Expires", "0");
}

void sendHtmlPage(PGM_P html) {
  if (html == nullptr) {
    server.send(500, "text/plain", "HTML page unavailable");
    return;
  }

  sendNoStoreHeaders();
  const size_t htmlLength = strlen_P(html);
  server.setContentLength(htmlLength);
  server.send(200, "text/html; charset=utf-8", "");

  for (size_t offset = 0; offset < htmlLength; offset += HTML_SEND_CHUNK_BYTES) {
    const size_t remaining = htmlLength - offset;
    const size_t chunkLength =
        remaining > HTML_SEND_CHUNK_BYTES ? HTML_SEND_CHUNK_BYTES : remaining;
    server.sendContent_P(html + offset, chunkLength);
    delay(0);
  }
}

String buildLogJson(const size_t limit) {
  String json = "[";
  const size_t available = eventLogCount;
  const size_t emitCount = limit == 0 || limit > available ? available : limit;
  const size_t start = (eventLogHead + MAX_EVENT_LOG_ENTRIES - emitCount) % MAX_EVENT_LOG_ENTRIES;

  for (size_t i = 0; i < emitCount; ++i) {
    if (i > 0) {
      json += ",";
    }
    const size_t idx = (start + i) % MAX_EVENT_LOG_ENTRIES;
    json += "{\"ms\":";
    json += String(eventLog[idx].ms);
    json += ",\"message\":\"";
    json += jsonEscape(String(eventLog[idx].message));
    json += "\"}";
  }
  json += "]";
  return json;
}

void markConfigDirty() {
  if (!configDirty) {
    configDirtySinceMs = millis();
  }
  configDirty = true;
}

bool savePersistentConfig();
bool parseUnsignedDigits(const char *text, size_t length, unsigned long &outValue);
bool parseUnsignedValue(const String &value, unsigned long &outValue);

void loadPersistentConfig() {
  if (!preferences.begin("fbbcfg", true)) {
    configLoaded = true;
    markConfigDirty();
    configSaveFault = true;
    configSaveFaultReason = "nvs_open_failed";
    Serial.println("ERROR: Failed to open NVS for persistent config load.");
    logEvent("Persistent config load failed: NVS open failed.");
    return;
  }

  const uint32_t version = preferences.getUInt("version", 0);
  if (version == CONFIG_VERSION) {
    feedBin1Name = preferences.getString("bin1", feedBin1Name);
    feedBin2Name = preferences.getString("bin2", feedBin2Name);
    feedLogicMode = static_cast<FeedLogicMode>(preferences.getUChar("logic", static_cast<uint8_t>(feedLogicMode)));
    feedLogicPreferredBin = preferences.getUChar("prefbin", feedLogicPreferredBin);
    feedLogicAlternateMs = preferences.getULong("logic_alt", feedLogicAlternateMs);
    feedLogicAutoSwitchMs = preferences.getULong("logic_auto", feedLogicAutoSwitchMs);
    feedLogicTopOffMs = preferences.getULong("logic_top2", feedLogicTopOffMs);
    plannerHouseName = preferences.getString("house", plannerHouseName);
    plannerNotes = preferences.getString("notes", plannerNotes);
    plannerNodesTarget = preferences.getUShort("nodes", plannerNodesTarget);
    plannerMeshEnabled = preferences.getBool("mesh", plannerMeshEnabled);
    plannerTrackBinLevel = preferences.getBool("trk_lvl", plannerTrackBinLevel);
    plannerTrackBinClog = preferences.getBool("trk_clog", plannerTrackBinClog);
    plannerTrackVibrator = preferences.getBool("trk_vib", plannerTrackVibrator);
    plannerTrackHopperAuger = preferences.getBool("trk_hop", plannerTrackHopperAuger);
    plannerTrackLineAuger = preferences.getBool("trk_line", plannerTrackLineAuger);
    plannerTrackMotorCurrent = preferences.getBool("trk_cur", plannerTrackMotorCurrent);
    noRunoutAlarmDelayMs = preferences.getULong("nr_alarm", noRunoutAlarmDelayMs);
    emptyTooLongAlarmDelayMs = preferences.getULong("empty_alarm", emptyTooLongAlarmDelayMs);
    manualOverrideTimeoutMs = preferences.getULong("manual_lease", manualOverrideTimeoutMs);
    relayMaxRuntimeMs = preferences.getULong("relay_max", relayMaxRuntimeMs);
    automationKeepaliveMs = preferences.getULong("auto_keep", automationKeepaliveMs);
    relayActiveHigh = preferences.getBool("relay_ah", relayActiveHigh);
    ledActiveHigh = preferences.getBool("led_ah", ledActiveHigh);
    feedPresentWhenHigh = preferences.getBool("sensor_hi", feedPresentWhenHigh);
    apPasswordEnabled = preferences.getBool("ap_pw_en", apPasswordEnabled);
    stationWifiEnabled = preferences.getBool("sta_en", stationWifiEnabled);
    stationWifiSsid = preferences.getString("sta_ssid", stationWifiSsid);
    stationWifiPassword = preferences.getString("sta_pw", stationWifiPassword);
    notificationEmailEnabled = preferences.getBool("notify_en", notificationEmailEnabled);
    notificationEmailTo = preferences.getString("notify_to", notificationEmailTo);
    notificationHubUrl = preferences.getString("notify_url", notificationHubUrl);
    cluckMagicSelectedMac = preferences.getString("cluck_mac", cluckMagicSelectedMac);
    configLoaded = true;
    configDirty = false;
    configDirtySinceMs = 0;
    configSaveFault = false;
    configSaveFaultReason = "";
  } else {
    configLoaded = true;
    markConfigDirty();
    configSaveFault = false;
    configSaveFaultReason = "";
    if (version != 0) {
      logEvent(String("Persistent config version mismatch: stored ") + String(version) +
               ", firmware expects " + String(CONFIG_VERSION));
    }
  }

  const String storedAccessPassword = preferences.getString("access_pw", "");
  if (storedAccessPassword.length() >= MIN_ACCESS_PASSWORD_LENGTH &&
      storedAccessPassword.length() <= MAX_ACCESS_PASSWORD_LENGTH) {
    deviceWifiPassword = storedAccessPassword;
  } else {
    markConfigDirty();
    logEvent(storedAccessPassword.length() > 0
                 ? "Persistent access password invalid; generated replacement will be saved."
                 : "Generated new persistent access password.");
  }
  deviceAdminPassword = deviceWifiPassword;
  preferences.end();

  if (sanitizePersistentConfig()) {
    markConfigDirty();
    logEvent("Loaded persistent config sanitized to safe ranges.");
  }
}

bool savePersistentConfig() {
  lastConfigSaveAttemptMs = millis();

  if (!preferences.begin("fbbcfg", false)) {
    configSaveFault = true;
    configSaveFaultReason = "nvs_open_failed";
    Serial.println("ERROR: Failed to open NVS for persistent config save.");
    logEvent("Persistent config save failed: NVS open failed.");
    return false;
  }

  bool saveOk = true;
  String saveFailureField;
  auto recordWrite = [&](const size_t written, const char *fieldName) {
    if (written == 0) {
      saveOk = false;
      if (saveFailureField.length() == 0) {
        saveFailureField = fieldName;
      }
    }
  };
  auto recordStringWrite = [&](const size_t written, const char *fieldName, const String &value) {
    if (written != value.length()) {
      saveOk = false;
      if (saveFailureField.length() == 0) {
        saveFailureField = fieldName;
      }
    }
  };

  recordWrite(preferences.putUInt("version", CONFIG_VERSION), "version");
  recordStringWrite(preferences.putString("access_pw", deviceWifiPassword), "access_pw", deviceWifiPassword);
  recordWrite(preferences.putBool("ap_pw_en", apPasswordEnabled), "ap_pw_en");
  recordStringWrite(preferences.putString("bin1", feedBin1Name), "bin1", feedBin1Name);
  recordStringWrite(preferences.putString("bin2", feedBin2Name), "bin2", feedBin2Name);
  recordWrite(preferences.putUChar("logic", static_cast<uint8_t>(feedLogicMode)), "logic");
  recordWrite(preferences.putUChar("prefbin", feedLogicPreferredBin), "prefbin");
  recordWrite(preferences.putULong("logic_alt", feedLogicAlternateMs), "logic_alt");
  recordWrite(preferences.putULong("logic_auto", feedLogicAutoSwitchMs), "logic_auto");
  recordWrite(preferences.putULong("logic_top2", feedLogicTopOffMs), "logic_top2");
  recordStringWrite(preferences.putString("house", plannerHouseName), "house", plannerHouseName);
  recordStringWrite(preferences.putString("notes", plannerNotes), "notes", plannerNotes);
  recordWrite(preferences.putUShort("nodes", plannerNodesTarget), "nodes");
  recordWrite(preferences.putBool("mesh", plannerMeshEnabled), "mesh");
  recordWrite(preferences.putBool("trk_lvl", plannerTrackBinLevel), "trk_lvl");
  recordWrite(preferences.putBool("trk_clog", plannerTrackBinClog), "trk_clog");
  recordWrite(preferences.putBool("trk_vib", plannerTrackVibrator), "trk_vib");
  recordWrite(preferences.putBool("trk_hop", plannerTrackHopperAuger), "trk_hop");
  recordWrite(preferences.putBool("trk_line", plannerTrackLineAuger), "trk_line");
  recordWrite(preferences.putBool("trk_cur", plannerTrackMotorCurrent), "trk_cur");
  recordWrite(preferences.putULong("nr_alarm", noRunoutAlarmDelayMs), "nr_alarm");
  recordWrite(preferences.putULong("empty_alarm", emptyTooLongAlarmDelayMs), "empty_alarm");
  recordWrite(preferences.putULong("manual_lease", manualOverrideTimeoutMs), "manual_lease");
  recordWrite(preferences.putULong("relay_max", relayMaxRuntimeMs), "relay_max");
  recordWrite(preferences.putULong("auto_keep", automationKeepaliveMs), "auto_keep");
  recordWrite(preferences.putBool("relay_ah", relayActiveHigh), "relay_ah");
  recordWrite(preferences.putBool("led_ah", ledActiveHigh), "led_ah");
  recordWrite(preferences.putBool("sensor_hi", feedPresentWhenHigh), "sensor_hi");
  recordWrite(preferences.putBool("sta_en", stationWifiEnabled), "sta_en");
  recordStringWrite(preferences.putString("sta_ssid", stationWifiSsid), "sta_ssid", stationWifiSsid);
  recordStringWrite(preferences.putString("sta_pw", stationWifiPassword), "sta_pw", stationWifiPassword);
  recordWrite(preferences.putBool("notify_en", notificationEmailEnabled), "notify_en");
  recordStringWrite(preferences.putString("notify_to", notificationEmailTo), "notify_to", notificationEmailTo);
  recordStringWrite(preferences.putString("notify_url", notificationHubUrl), "notify_url", notificationHubUrl);
  recordStringWrite(preferences.putString("cluck_mac", cluckMagicSelectedMac), "cluck_mac", cluckMagicSelectedMac);
  preferences.end();

  if (!saveOk) {
    configSaveFault = true;
    configSaveFaultReason = String("write_failed:") + saveFailureField;
    Serial.println("ERROR: Failed to write one or more persistent config fields.");
    logEvent(String("Persistent config save failed: NVS write failed") +
             (saveFailureField.length() > 0 ? String(" on ") + saveFailureField : String()));
    return false;
  }

  configSaveFault = false;
  configSaveFaultReason = "";
  configDirty = false;
  configDirtySinceMs = 0;
  lastConfigSaveMs = millis();
  return true;
}

void maybeSavePersistentConfig() {
  if (!configDirty) {
    return;
  }

  const unsigned long now = millis();
  const unsigned long retryIntervalMs = configSaveFault ? 30000UL : 500UL;
  if (now - lastConfigSaveAttemptMs > retryIntervalMs) {
    savePersistentConfig();
  }
}

void forceAllRelaysOff(const char *reason, const bool logAction);
void stopFeedLogicCycle();

bool directControlLocked() {
  return rebootPending || emergencyStopLatched || faultLatched ||
         alarmState == AlarmState::EmptyTooLong;
}

bool guiFeedControlLocked() {
  return emergencyStopLatched || hardwareEmergencyStopActive;
}

unsigned long manualControlOverrideRemainingMs(const unsigned long now) {
  return manualControlOverrideUntilMs != 0 && !timeReached(now, manualControlOverrideUntilMs)
             ? (manualControlOverrideUntilMs - now)
             : 0;
}

bool manualControlOverrideActive(const unsigned long now) {
  return manualControlOverrideRemainingMs(now) > 0;
}

void noteManualControlOverride() {
  manualControlOverrideUntilMs = millis() + manualOverrideTimeoutMs;
  stopFeedLogicCycle();
}

void touchMaintenanceSession() {
  maintenanceSessionCreatedMs = millis();
}

unsigned long maintenanceSessionRemainingMs(const unsigned long now) {
  if (maintenanceSessionToken.length() == 0 || maintenanceSessionCreatedMs == 0) {
    return 0;
  }

  const unsigned long ageMs = now - maintenanceSessionCreatedMs;
  if (ageMs >= MAINTENANCE_SESSION_TIMEOUT_MS) {
    return 0;
  }
  return MAINTENANCE_SESSION_TIMEOUT_MS - ageMs;
}

bool maintenanceSessionMatchesCurrentRequest() {
  if (!accessPasswordRequired()) {
    return true;
  }

  const unsigned long now = millis();
  if (maintenanceSessionRemainingMs(now) == 0) {
    return false;
  }

  if (!server.hasHeader(MAINTENANCE_TOKEN_HEADER)) {
    return false;
  }

  const String providedToken = server.header(MAINTENANCE_TOKEN_HEADER);
  return providedToken.length() > 0 && providedToken == maintenanceSessionToken;
}

void clearMaintenanceSession(const char *reason) {
  const bool hadSession = maintenanceSessionToken.length() > 0 || maintenanceSessionCreatedMs != 0;
  maintenanceSessionToken = "";
  maintenanceSessionCreatedMs = 0;
  if (hadSession && reason != nullptr && reason[0] != '\0') {
    logEvent(String("Maintenance session cleared: ") + reason);
  }
}

void sendMaintenanceUnlockRequiredResponse(const char *actionName) {
  sendNoStoreHeaders();
  String json = "{\"error\":\"Maintenance unlock required\"";
  if (actionName != nullptr && actionName[0] != '\0') {
    json += ",\"action\":\"";
    json += jsonEscape(String(actionName));
    json += "\"";
  }
  json += ",\"maintenance_unlocked\":false";
  json += ",\"maintenance_session_remaining_ms\":0}";
  server.send(403, "application/json", json);
}

bool requireMaintenanceSession(const char *actionName) {
  if (!accessPasswordRequired()) {
    return true;
  }

  if (maintenanceSessionMatchesCurrentRequest()) {
    touchMaintenanceSession();
    return true;
  }

  sendMaintenanceUnlockRequiredResponse(actionName);
  return false;
}

bool relayChannelIsValid(const uint8_t relay) {
  return relay == 1 || relay == 2;
}

ControllerState currentControllerState(const unsigned long now) {
  if (rebootPending) {
    return ControllerState::RebootPending;
  }
  if (faultLatched) {
    return ControllerState::Fault;
  }
  if (emergencyStopLatched) {
    return ControllerState::EmergencyStop;
  }
  if (!apRunning) {
    return ControllerState::ApOffline;
  }
  if (!apDisconnectGuardArmed) {
    return ControllerState::BootWait;
  }
  if (apNoStationSinceMs != 0) {
    const unsigned long elapsedSinceNoStation = now - apNoStationSinceMs;
    if (elapsedSinceNoStation < AP_DISCONNECT_OFF_DELAY_MS) {
      return ControllerState::DisconnectGrace;
    }
  }
  return ControllerState::Ready;
}

const char *controllerStateName(const unsigned long now) {
  switch (currentControllerState(now)) {
    case ControllerState::RebootPending:
      return "reboot_pending";
    case ControllerState::Fault:
      return "fault";
    case ControllerState::EmergencyStop:
      return "emergency_stop";
    case ControllerState::ApOffline:
      return "ap_offline";
    case ControllerState::BootWait:
      return "boot_wait";
    case ControllerState::DisconnectGrace:
      return "disconnect_grace";
    case ControllerState::Ready:
    default:
      return "ready";
  }
}

uint8_t controllerStateCode(const unsigned long now) {
  return static_cast<uint8_t>(currentControllerState(now));
}

String controllerStateDetail(const unsigned long now) {
  switch (currentControllerState(now)) {
    case ControllerState::RebootPending:
      return rebootReason.length() > 0 ? rebootReason : String("controller reboot pending");
    case ControllerState::Fault:
      return faultReason.length() > 0 ? faultReason : String("controller fault latched");
    case ControllerState::EmergencyStop:
      if (hardwareEmergencyStopActive) {
        return "hardware emergency stop input active";
      }
      return "manual emergency stop latched";
    case ControllerState::ApOffline:
      return "access point is retrying";
    case ControllerState::BootWait:
      return "waiting for first AP client before disconnect guard arms";
    case ControllerState::DisconnectGrace: {
      const unsigned long elapsedSinceNoStation = now - apNoStationSinceMs;
      const unsigned long remainingMs = AP_DISCONNECT_OFF_DELAY_MS - elapsedSinceNoStation;
      return String("AP disconnect grace timer active: ") + formatDurationText(remainingMs) + " remaining";
    }
    case ControllerState::Ready:
    default:
      return "controller ready";
  }
}

String formatDurationText(const unsigned long ms) {
  const unsigned long totalSeconds = ms / 1000UL;
  const unsigned long days = totalSeconds / 86400UL;
  const unsigned long hours = (totalSeconds % 86400UL) / 3600UL;
  const unsigned long minutes = (totalSeconds % 3600UL) / 60UL;
  const unsigned long seconds = totalSeconds % 60UL;

  if (days > 0) {
    return String(days) + "d " + String(hours) + "h " + String(minutes) + "m";
  }
  if (hours > 0) {
    return String(hours) + "h " + String(minutes) + "m " + String(seconds) + "s";
  }
  if (minutes > 0) {
    return String(minutes) + "m " + String(seconds) + "s";
  }
  return String(seconds) + "s";
}

struct HealthSnapshot {
  String level;
  String title;
  String detail;
  bool ok;
};

uint8_t healthLevelCode(const String &level) {
  String normalized = level;
  normalized.trim();
  normalized.toLowerCase();

  if (normalized == "good") {
    return 0;
  }
  if (normalized == "info") {
    return 1;
  }
  if (normalized == "warn") {
    return 2;
  }
  if (normalized == "alarm") {
    return 3;
  }
  if (normalized == "offline") {
    return 4;
  }
  return 1;
}

HealthSnapshot buildHealthSnapshot(const unsigned long now) {
  const uint8_t stationCount = WiFi.softAPgetStationNum();
  const unsigned long apNoStationElapsedMs = (apNoStationSinceMs != 0) ? (now - apNoStationSinceMs) : 0;
  const unsigned long apDisconnectGraceRemainingMs =
      (apDisconnectGuardArmed && stationCount == 0 && apNoStationSinceMs != 0 &&
       apNoStationElapsedMs < AP_DISCONNECT_OFF_DELAY_MS)
          ? (AP_DISCONNECT_OFF_DELAY_MS - apNoStationElapsedMs)
          : 0;
  const unsigned long relay1LeaseRemaining =
      relayLeaseUntilMs[0] != 0 && !timeReached(now, relayLeaseUntilMs[0])
          ? (relayLeaseUntilMs[0] - now)
          : 0;
  const unsigned long relay2LeaseRemaining =
      relayLeaseUntilMs[1] != 0 && !timeReached(now, relayLeaseUntilMs[1])
          ? (relayLeaseUntilMs[1] - now)
          : 0;

  HealthSnapshot health = {"good",
                           "Ready",
                           "All outputs are OFF and the controller is waiting for work.",
                           true};

  const bool bin1On = relay1On;
  const bool bin2On = relay2On;
  const unsigned long manualOverrideRemaining = manualControlOverrideRemainingMs(now);
  const String bin1Name = feedBin1Name;
  const String bin2Name = feedBin2Name;
  String bin1Owner = String(relayOwnerName(relayLeaseOwner[0]));
  String bin2Owner = String(relayOwnerName(relayLeaseOwner[1]));
  bin1Owner.toUpperCase();
  bin2Owner.toUpperCase();

  String configDirtyAge = "";
  if (configDirty && configDirtySinceMs != 0) {
    configDirtyAge = formatDurationText(now - configDirtySinceMs);
  }
  String configSaveAttemptAge = "";
  if (lastConfigSaveAttemptMs != 0) {
    configSaveAttemptAge = formatDurationText(now - lastConfigSaveAttemptMs);
  }
  String configLastSavedAge = "";
  if (lastConfigSaveMs != 0) {
    configLastSavedAge = formatDurationText(now - lastConfigSaveMs);
  }

  if (rebootPending) {
    health.level = "info";
    health.title = "Reboot pending";
    health.detail = String("Outputs were forced OFF and the controller will restart in ") +
                    formatDurationText(REBOOT_DELAY_MS) + ".";
    health.ok = true;
    return health;
  }

  if (faultLatched) {
    health.level = "alarm";
    health.title = "Fault latched";
    health.detail = String("Controller outputs are OFF until the fault is cleared: ") +
                    (faultReason.length() > 0 ? faultReason : String("unknown fault"));
    health.ok = false;
    return health;
  }

  if (emergencyStopLatched) {
    health.level = "alarm";
    health.title = "Emergency stop latched";
    health.detail = hardwareEmergencyStopActive
                         ? String("The hard stop input is active, so the controller is refusing to energize either auger.")
                         : String("Outputs are forced OFF until the emergency stop is reset.");
    health.ok = false;
    return health;
  }

  if (pinIsConfigured(PIN_EMERGENCY_STOP) && hardwareEmergencyStopActive) {
    health.level = "warn";
    health.title = "Hardware stop active";
    health.detail = "The normally-closed stop loop is open. Restore the loop before attempting a reset.";
    health.ok = false;
    return health;
  }

  if (!apRunning) {
    health.level = "alarm";
    health.title = "Access point restarting";
    health.detail = "The controller AP is not advertising yet. Wait for Wi-Fi recovery or check the access-point service.";
    health.ok = false;
    return health;
  }

  if (apDisconnectGuardArmed && apDisconnectGraceRemainingMs > 0) {
    health.level = "warn";
    health.title = "Disconnect guard armed";
    health.detail = String("A client was present and then disconnected. Reconnect before the AP grace timer expires in ") +
                    formatDurationText(apDisconnectGraceRemainingMs) + ".";
    health.ok = false;
    return health;
  }

  if (alarmState == AlarmState::EmptyTooLong) {
    health.level = "alarm";
    health.title = "Feed bin empty too long";
    health.detail = manualOverrideRemaining > 0
                        ? String("The hopper stayed low past the empty-too-long limit, but manual GUI control is active for ") +
                              formatDurationText(manualOverrideRemaining) + "."
                        : String("The hopper stayed low past the empty-too-long limit. Check feed, bridging, auger, and sensor; manual GUI controls remain available unless emergency stop is active.");
    health.ok = false;
    return health;
  }

  if (alarmState == AlarmState::NoRunoutTooLong) {
    health.level = "warn";
    health.title = "No runout too long";
    health.detail = "The hopper sensor stayed covered past the no-runout limit. Check feed flow and sensor placement, then clear the alarm if the condition has been reviewed.";
    health.ok = false;
    return health;
  }

  if (relay1On || relay2On) {
    String details;
    if (relay1On) {
      details += bin1Name;
      details += ": ";
      details += bin1Owner;
      if (relay1LeaseRemaining > 0) {
        details += ", lease ";
        details += formatDurationText(relay1LeaseRemaining);
        details += " left";
      }
    }
    if (relay2On) {
      if (details.length() > 0) {
        details += " | ";
      }
      details += bin2Name;
      details += ": ";
      details += bin2Owner;
      if (relay2LeaseRemaining > 0) {
        details += ", lease ";
        details += formatDurationText(relay2LeaseRemaining);
        details += " left";
      }
    }
    if (configSaveFault) {
      if (details.length() > 0) {
        details += " | ";
      }
      details += configSaveFaultReason.length() > 0 ? String("storage fault: ") + configSaveFaultReason : String("storage fault");
    }
    if (!feedPresent) {
      if (details.length() > 0) {
        details += " | ";
      }
      details += "hopper sensor still low; if it does not recover, check empty bin, bridging, or stuck auger";
    }

    health.level = configSaveFault ? "warn" : "info";
    health.title = bin1On && bin2On ? "Both augers running" : String(bin1On ? bin1Name : bin2Name) + " running";
    health.detail = details;
    health.ok = !configSaveFault;
    return health;
  }

  if (configSaveFault) {
    health.level = "warn";
    health.title = "Persistent storage fault";
    health.detail = (configSaveFaultReason.length() > 0 ? String("NVS save failed (") + configSaveFaultReason + ")" : String("NVS save failed"));
    if (configSaveAttemptAge.length() > 0) {
      health.detail += " ";
      health.detail += configSaveAttemptAge;
      health.detail += " ago";
    }
    health.detail += ". Settings remain dirty until storage recovers.";
    if (configLastSavedAge.length() > 0) {
      health.detail += " Last successful save was ";
      health.detail += configLastSavedAge;
      health.detail += " ago.";
    }
    health.ok = false;
    return health;
  }

  if (feedLogicMode != FeedLogicMode::Manual) {
    health.level = "info";
    health.title = "Feed logic armed";
    health.detail = String(feedLogicModeLabel(feedLogicMode)) + ": " +
                    feedLogicModeRunRule(feedLogicMode) +
                    " Manual GUI controls override automation for the manual lease.";
    health.ok = true;
    return health;
  }

  if (configDirty) {
    health.level = "info";
    health.title = "Configuration pending save";
    health.detail = configDirtyAge.length() > 0
                        ? String("Settings changed ") + configDirtyAge + " ago and will be written to NVS shortly."
                        : String("Settings changed and will be written to NVS shortly.");
    health.ok = true;
    return health;
  }

  return health;
}

void requestControllerReboot(const char *reason) {
  if (rebootPending) {
    return;
  }

  rebootPending = true;
  rebootRequestedMs = millis();
  rebootReason = (reason != nullptr && reason[0] != '\0') ? reason : "controller reboot";

  stopFeedLogicCycle();
  forceAllRelaysOff("reboot request");
  clearMaintenanceSession("reboot requested");
  if (configDirty) {
    savePersistentConfig();
  }

  logEvent(String("Reboot requested: ") + rebootReason);
}

void processPendingReboot() {
  if (!rebootPending) {
    return;
  }

  const unsigned long now = millis();
  if (!timeReached(now, rebootRequestedMs + REBOOT_DELAY_MS)) {
    return;
  }

  logEvent(String("Rebooting controller: ") + rebootReason);
  delay(50);
  ESP.restart();
}

void clearFault();
void stopFeedLogicCycle();

void enterFault(const String &reason) {
  if (!faultLatched || faultReason != reason) {
    faultLatched = true;
    faultReason = reason;
    logEvent(String("FAULT: ") + reason);
  }
  stopFeedLogicCycle();
  relay1On = false;
  relay2On = false;
  relayLeaseUntilMs[0] = 0;
  relayLeaseUntilMs[1] = 0;
  relayLeaseOwner[0] = static_cast<uint8_t>(RelayOwner::None);
  relayLeaseOwner[1] = static_cast<uint8_t>(RelayOwner::None);
  relayOnSinceMs[0] = 0;
  relayOnSinceMs[1] = 0;
  applyOutputs();
}

void clearFault() {
  faultLatched = false;
  faultReason = "";
  logEvent("Fault cleared.");
}

unsigned long relayLeaseRemainingMs(const uint8_t relay) {
  uint8_t idx = 0;
  if (!relayChannelIsValid(relay)) {
    return 0;
  }
  idx = relay - 1;
  const unsigned long now = millis();
  if (relayLeaseUntilMs[idx] == 0 || !timeReached(now, relayLeaseUntilMs[idx])) {
    return relayLeaseUntilMs[idx] == 0 ? 0 : relayLeaseUntilMs[idx] - now;
  }
  return 0;
}

void setRelayChannel(const uint8_t relay,
                     const bool on,
                     const RelayOwner owner,
                     const unsigned long leaseMs,
                     const char *reason) {
  if (!relayChannelIsValid(relay)) {
    if (reason != nullptr && reason[0] != '\0') {
      logEvent(String("Ignored invalid relay channel ") + String(relay) + " [" + reason + "]");
    } else {
      logEvent(String("Ignored invalid relay channel ") + String(relay));
    }
    return;
  }

  const uint8_t idx = relay - 1;
  bool &state = (idx == 0) ? relay1On : relay2On;
  const unsigned long now = millis();

  if (owner == RelayOwner::Manual) {
    noteManualControlOverride();
  }

  if (on) {
    if (state) {
      relayLeaseUntilMs[idx] = now + leaseMs;
      relayLeaseOwner[idx] = static_cast<uint8_t>(owner);
      return;
    }
  } else {
    relayLeaseUntilMs[idx] = 0;
    relayLeaseOwner[idx] = static_cast<uint8_t>(RelayOwner::None);
    relayOnSinceMs[idx] = 0;
    if (!state) {
      return;
    }
    state = false;
    applyOutputs();
    String msg = "Relay ";
    msg += String(relay);
    msg += " OFF";
    if (reason != nullptr && reason[0] != '\0') {
      msg += " [";
      msg += reason;
      msg += "]";
    }
    logEvent(msg);
    return;
  }

  state = true;
  relayLeaseOwner[idx] = static_cast<uint8_t>(owner);
  relayLeaseUntilMs[idx] = now + leaseMs;
  relayOnSinceMs[idx] = now;
  applyOutputs();

  String msg = "Relay ";
  msg += String(relay);
  msg += " ON";
  if (reason != nullptr && reason[0] != '\0') {
    msg += " [";
    msg += reason;
    msg += "]";
  }
  logEvent(msg);
}

void forceAllRelaysOff(const char *reason, const bool logAction) {
  relay1On = false;
  relay2On = false;
  relayLeaseUntilMs[0] = 0;
  relayLeaseUntilMs[1] = 0;
  relayLeaseOwner[0] = static_cast<uint8_t>(RelayOwner::None);
  relayLeaseOwner[1] = static_cast<uint8_t>(RelayOwner::None);
  relayOnSinceMs[0] = 0;
  relayOnSinceMs[1] = 0;
  applyOutputs();
  if (logAction) {
    if (reason != nullptr && reason[0] != '\0') {
      logEvent(String("Outputs forced OFF: ") + reason);
    } else {
      logEvent("Outputs forced OFF.");
    }
  }
}

uint8_t oppositeBin(const uint8_t bin) {
  return (bin == 1) ? 2 : 1;
}

void setFeedBins(const bool bin1On, const bool bin2On) {
  setRelayChannel(1, bin1On, RelayOwner::Manual, manualOverrideTimeoutMs, "manual");
  setRelayChannel(2, bin2On, RelayOwner::Manual, manualOverrideTimeoutMs, "manual");
}

void setFeedBinsForAutomation(const bool bin1On, const bool bin2On, const char *reason) {
  setRelayChannel(1, bin1On, RelayOwner::Automation, automationKeepaliveMs, reason);
  setRelayChannel(2, bin2On, RelayOwner::Automation, automationKeepaliveMs, reason);
}

void setOnlyFeedBin(const uint8_t bin) {
  if (bin == 1) {
    setFeedBins(true, false);
  } else if (bin == 2) {
    setFeedBins(false, true);
  } else {
    setFeedBins(false, false);
  }
}

void setOnlyFeedBinForAutomation(const uint8_t bin, const char *reason) {
  if (bin == 1) {
    setFeedBinsForAutomation(true, false, reason);
  } else if (bin == 2) {
    setFeedBinsForAutomation(false, true, reason);
  } else {
    setFeedBinsForAutomation(false, false, reason);
  }
}

void stopFeedLogicCycle() {
  feedLogicActiveBin = 0;
  feedLogicActiveBinSinceMs = 0;
  feedLogicSwitchedThisCycle = false;
  feedLogicTopOffActive = false;
  feedLogicTopOffStartedMs = 0;
}

void startFeedLogicCycle(const uint8_t bin, const unsigned long now) {
  feedLogicActiveBin = bin;
  feedLogicActiveBinSinceMs = now;
  feedLogicSwitchedThisCycle = false;
  feedLogicTopOffActive = false;
  feedLogicTopOffStartedMs = 0;
  setOnlyFeedBinForAutomation(bin, "feed logic start");
  Serial.print("Feed logic started cycle with bin ");
  Serial.println(bin);
  logEvent(String("Feed logic cycle started with bin ") + String(bin));
}

unsigned long feedLogicTopOffRemainingMs(const unsigned long now) {
  if (!feedLogicTopOffActive) {
    return 0;
  }
  const unsigned long elapsed = now - feedLogicTopOffStartedMs;
  if (elapsed >= feedLogicTopOffMs) {
    return 0;
  }
  return feedLogicTopOffMs - elapsed;
}

void completeFeedLogicCycle(const unsigned long now) {
  setFeedBinsForAutomation(false, false, "feed logic complete");
  if (feedLogicMode == FeedLogicMode::AlternateCycle) {
    feedLogicPreferredBin = oppositeBin(feedLogicPreferredBin);
  }
  stopFeedLogicCycle();
  feedLogicLastAlternateMs = now;
  Serial.println("Feed logic cycle complete.");
  logEvent("Feed logic cycle complete.");
}

void updateFeedLogic() {
  const unsigned long now = millis();

  if (rebootPending) {
    stopFeedLogicCycle();
    return;
  }

  if (feedLogicMode == FeedLogicMode::Manual) {
    stopFeedLogicCycle();
    return;
  }

  if (emergencyStopLatched || faultLatched) {
    stopFeedLogicCycle();
    return;
  }

  if (manualControlOverrideActive(now)) {
    stopFeedLogicCycle();
    return;
  }
  manualControlOverrideUntilMs = 0;

  if (alarmState != AlarmState::Normal) {
    stopFeedLogicCycle();
    setFeedBinsForAutomation(false, false, "feed alarm active");
    return;
  }

  const bool hopperNeedsFeed = !feedPresent;

  if (feedLogicMode == FeedLogicMode::TimedAlternate &&
      feedLogicActiveBin == 0 &&
      !hopperNeedsFeed &&
      (now - feedLogicLastAlternateMs >= feedLogicAlternateMs)) {
    feedLogicPreferredBin = oppositeBin(feedLogicPreferredBin);
    feedLogicLastAlternateMs = now;
    Serial.print("Feed logic timed alternate -> preferred bin ");
    Serial.println(feedLogicPreferredBin);
    logEvent(String("Feed logic preferred bin -> ") + String(feedLogicPreferredBin));
  }

  if (!hopperNeedsFeed) {
    if (feedLogicActiveBin != 0) {
      if (feedLogicTopOffMs == 0) {
        completeFeedLogicCycle(now);
        return;
      }

      if (!feedLogicTopOffActive) {
        feedLogicTopOffActive = true;
        feedLogicTopOffStartedMs = now;
        Serial.print("Feed logic hopper top-off started for ");
        Serial.print(feedLogicTopOffMs / 1000UL);
        Serial.println(" sec.");
        logEvent(String("Feed logic hopper top-off started: ") +
                 String(feedLogicTopOffMs / 1000UL) + " sec");
      }

      setOnlyFeedBinForAutomation(feedLogicActiveBin, "feed logic top-off");
      if (feedLogicTopOffRemainingMs(now) == 0) {
        completeFeedLogicCycle(now);
        return;
      }
    }
    return;
  }

  if (feedLogicTopOffActive) {
    feedLogicTopOffActive = false;
    feedLogicTopOffStartedMs = 0;
    Serial.println("Feed logic hopper top-off cancelled; sensor clear.");
    logEvent("Feed logic hopper top-off cancelled; sensor clear.");
  }

  if (feedLogicActiveBin == 0) {
    startFeedLogicCycle(feedLogicPreferredBin, now);
    return;
  }

  setOnlyFeedBinForAutomation(feedLogicActiveBin, "feed logic keepalive");

  if (feedLogicMode == FeedLogicMode::AutoSwitch && !feedLogicSwitchedThisCycle &&
      (now - feedLogicActiveBinSinceMs >= feedLogicAutoSwitchMs)) {
    const uint8_t nextBin = oppositeBin(feedLogicActiveBin);
    feedLogicActiveBin = nextBin;
    feedLogicPreferredBin = nextBin;
    feedLogicActiveBinSinceMs = now;
    feedLogicSwitchedThisCycle = true;
    setOnlyFeedBinForAutomation(nextBin, "feed logic auto-switch");
    Serial.print("Feed logic auto-switched to bin ");
    Serial.println(nextBin);
    logEvent(String("Feed logic auto-switched to bin ") + String(nextBin));
  }
}

bool notificationReadyForSend() {
  return notificationEmailEnabled &&
         notificationEmailTo.length() > 0 &&
         notificationHubUrl.length() > 0 &&
         stationWifiConnected();
}

String notificationStatusDetail() {
  if (!notificationEmailEnabled) {
    return "disabled";
  }
  if (notificationEmailTo.length() == 0) {
    return "email_missing";
  }
  if (notificationHubUrl.length() == 0) {
    return "hub_url_missing";
  }
  if (!stationWifiConnected()) {
    return stationWifiConfigured() ? "wifi_not_connected" : "wifi_not_configured";
  }
  return "ready";
}

bool sendHubAlertNotification(const String &alertId,
                              const String &severity,
                              const String &title,
                              const String &cause,
                              const String &currentValue,
                              const String &suggestedAction) {
  notificationLastAttemptMs = millis();
  const unsigned long alertUptimeMs = notificationLastAttemptMs;

  if (!notificationReadyForSend()) {
    notificationLastStatus = notificationStatusDetail();
    return false;
  }

  if (!notificationHubUrl.startsWith("http://") && !notificationHubUrl.startsWith("https://")) {
    notificationLastStatus = "hub_url_invalid";
    logEvent("Notification send skipped: hub URL must start with http:// or https://");
    return false;
  }

  String payload = "{\"alert\":{";
  payload.reserve(1100);
  payload += "\"record_type\":\"alert_event\",";
  payload += "\"alert_id\":\"" + jsonEscape(alertId) + "\",";
  payload += "\"title\":\"" + jsonEscape(title) + "\",";
  payload += "\"farm_name\":\"Chicken Chat\",";
  payload += "\"house_name\":\"" + jsonEscape(plannerHouseName) + "\",";
  payload += "\"house_id\":\"" + jsonEscape(plannerHouseName) + "\",";
  payload += "\"zone_id\":\"feed\",";
  payload += "\"zone_name\":\"Feed zone\",";
  payload += "\"node_id\":\"feeder-bin-bot\",";
  payload += "\"node_name\":\"Bin Commander\",";
  payload += "\"severity\":\"" + jsonEscape(severity) + "\",";
  payload += "\"location\":\"" + jsonEscape(plannerHouseName + String(" feed bins")) + "\",";
  payload += "\"cause\":\"" + jsonEscape(cause) + "\",";
  payload += "\"current_value\":\"" + jsonEscape(currentValue) + "\",";
  payload += "\"expected_range\":{\"low\":\"normal\",\"high\":\"normal\",\"units\":\"state\",\"description\":\"configured feed alarm window\"},";
  payload += "\"suggested_action\":\"" + jsonEscape(suggestedAction) + "\",";
  payload += "\"detected_since\":\"Controller uptime " + jsonEscape(formatDurationText(alertUptimeMs)) + "\",";
  payload += "\"detected_uptime_ms\":" + String(alertUptimeMs) + ",";
  payload += "\"active\":true,";
  payload += "\"acknowledged\":false,";
  payload += "\"source\":\"feeder-bin-bot\",";
  payload += "\"notification_email\":\"" + jsonEscape(notificationEmailTo) + "\",";
  payload += "\"notes\":\"Controller uptime ";
  payload += String(alertUptimeMs);
  payload += " ms\"}}";

  HTTPClient http;
  http.setTimeout(5000);
  if (!http.begin(notificationHubUrl)) {
    notificationLastStatus = "hub_begin_failed";
    logEvent("Notification send failed: hub URL begin failed.");
    return false;
  }

  http.addHeader("Content-Type", "application/json");
  const int code = http.POST(payload);
  http.end();

  if (code >= 200 && code < 300) {
    notificationLastSuccessMs = millis();
    notificationLastStatus = String("sent_") + String(code);
    logEvent(String("Notification sent to hub: ") + title);
    return true;
  }

  notificationLastStatus = String("http_") + String(code);
  logEvent(String("Notification send failed: HTTP ") + String(code));
  return false;
}

void maybeSendAlarmNotification(const AlarmState state) {
  if (state == notificationLastAlarmState) {
    return;
  }

  notificationLastAlarmState = state;
  if (state == AlarmState::Normal) {
    return;
  }

  if (state == AlarmState::NoRunoutTooLong) {
    sendHubAlertNotification(
        "fbb-no-runout-too-long",
        "warning",
        "Feed has not run out",
        "Feed stayed present at the hopper sensor longer than the no-runout alarm delay.",
        String("Feed present for ") + formatDurationText(feedPresentSinceMs != 0 ? millis() - feedPresentSinceMs : 0),
        "Check feed flow, sensor placement, and whether the line is actually using feed.");
    return;
  }

  if (state == AlarmState::EmptyTooLong) {
    sendHubAlertNotification(
        "fbb-empty-too-long",
        "critical",
        "Feed bin is empty too long",
        "The hopper sensor stayed low longer than the empty-too-long alarm delay.",
        String("Feed low for ") + formatDurationText(lowFeedSinceMs != 0 ? millis() - lowFeedSinceMs : 0),
        "Check bin level, bridging, auger motor, and feed line before birds run short.");
  }
}

void updateAlarmStateAndLed() {
  const unsigned long now = millis();

  AlarmState nextState = AlarmState::Normal;
  if (feedPresent && feedPresentSinceMs != 0 && (now - feedPresentSinceMs >= noRunoutAlarmDelayMs)) {
    nextState = AlarmState::NoRunoutTooLong;
  } else if (!feedPresent && lowFeedSinceMs != 0 && (now - lowFeedSinceMs >= emptyTooLongAlarmDelayMs)) {
    nextState = AlarmState::EmptyTooLong;
  }

  if (nextState != alarmState) {
    alarmState = nextState;
    Serial.print("Alarm state: ");
    Serial.println(alarmStateName(alarmState));
    logEvent(String("Alarm state: ") + alarmStateName(alarmState));
    if (alarmState == AlarmState::EmptyTooLong) {
      stopFeedLogicCycle();
      if (!manualControlOverrideActive(now)) {
        forceAllRelaysOff("feed alarm 2 active");
      }
    } else {
      alarmBlinkOn = false;
    }
    maybeSendAlarmNotification(alarmState);
  }

  bool desiredLed = false;
  if (alarmState == AlarmState::NoRunoutTooLong) {
    desiredLed = true;
  } else if (alarmState == AlarmState::EmptyTooLong) {
    if (now - lastAlarmBlinkMs >= ALARM_LED_FLASH_INTERVAL_MS) {
      lastAlarmBlinkMs = now;
      alarmBlinkOn = !alarmBlinkOn;
    }
    desiredLed = alarmBlinkOn;
  } else {
    desiredLed = false;
  }

  if (ledOn != desiredLed) {
    ledOn = desiredLed;
    applyOutputs();
  }
}

void clearFeedAlarm(const char *reason) {
  const unsigned long now = millis();
  const AlarmState clearedState = alarmState;
  const char *clearReason = (reason != nullptr && reason[0] != '\0') ? reason : "operator clear";

  alarmLastClearedState = clearedState;
  alarmLastClearedMs = now;
  alarmLastClearReason = clearReason;
  if (alarmLastClearReason.length() > 64) {
    alarmLastClearReason = alarmLastClearReason.substring(0, 64);
  }

  stopFeedLogicCycle();
  forceAllRelaysOff("feed alarm clear");

  const bool currentFeedPresent = decodeFeedPresent(readFeedRawActive());
  feedPresent = currentFeedPresent;
  feedCandidate = currentFeedPresent;
  feedCandidateSinceMs = now;
  lowFeedSinceMs = currentFeedPresent ? 0 : now;
  feedPresentSinceMs = currentFeedPresent ? now : 0;

  alarmState = AlarmState::Normal;
  notificationLastAlarmState = AlarmState::Normal;
  alarmBlinkOn = false;
  lastAlarmBlinkMs = now;
  ledOn = false;
  applyOutputs();

  logEvent(String("Feed alarm cleared: ") + alarmLastClearReason +
           " (was " + alarmStateName(clearedState) + ")");
}

void monitorRelaySafety() {
  const unsigned long now = millis();

  for (uint8_t relay = 1; relay <= 2; ++relay) {
    const uint8_t idx = relay - 1;
    if (!((idx == 0) ? relay1On : relay2On)) {
      continue;
    }

    if (relayLeaseUntilMs[idx] != 0 && timeReached(now, relayLeaseUntilMs[idx])) {
      setRelayChannel(relay, false, RelayOwner::None, 0, "lease expired");
      continue;
    }

    if (relayOnSinceMs[idx] != 0 && (now - relayOnSinceMs[idx] > relayMaxRuntimeMs)) {
      String reason = "Relay ";
      reason += String(relay);
      reason += " runtime exceeded ";
      reason += String(relayMaxRuntimeMs / 1000UL);
      reason += "s";
      enterFault(reason);
      return;
    }
  }

  if ((faultLatched || emergencyStopLatched) && (relay1On || relay2On)) {
    forceAllRelaysOff("interlock");
  }
}

void enforceDisconnectFailSafe() {
  if (OPEN_TEST_ACCESS) {
    return;
  }

  const unsigned long now = millis();
  const uint8_t stationCount = WiFi.softAPgetStationNum();

  if (stationCount != apLastStationCount) {
    apLastStationCount = stationCount;
    apLastStationChangeMs = now;
    String msg = "AP station count -> ";
    msg += String(stationCount);
    logEvent(msg);
  }

  if (stationCount > 0) {
    if (!apDisconnectGuardArmed) {
      logEvent("AP disconnect guard armed.");
    }
    apDisconnectGuardArmed = true;
    apNoStationSinceMs = 0;
    return;
  }

  if (!apDisconnectGuardArmed || faultLatched || emergencyStopLatched) {
    return;
  }

  if (apNoStationSinceMs == 0) {
    apNoStationSinceMs = now;
    return;
  }

  if (now - apNoStationSinceMs < AP_DISCONNECT_OFF_DELAY_MS) {
    return;
  }

  enterFault("AP disconnected");
}

void resetApDisconnectFailSafeState() {
  const bool hadHistory = apDisconnectGuardArmed || apNoStationSinceMs != 0 ||
                          apLastStationCount != 0 || apLastStationChangeMs != 0;

  apDisconnectGuardArmed = false;
  apNoStationSinceMs = 0;
  apLastStationCount = 0;
  apLastStationChangeMs = 0;

  if (hadHistory) {
    logEvent("AP disconnect guard reset for fresh AP session.");
  }
}

bool stationWifiConfigured() {
  return stationWifiEnabled && stationWifiSsid.length() > 0;
}

bool stationWifiConnected() {
  return stationWifiConfigured() && WiFi.status() == WL_CONNECTED;
}

bool accessPasswordRequired() {
  return !OPEN_TEST_ACCESS && apPasswordEnabled;
}

const char *stationWifiStatusName(const wl_status_t status) {
  switch (status) {
    case WL_CONNECTED:
      return "connected";
    case WL_NO_SSID_AVAIL:
      return "ssid_not_found";
    case WL_CONNECT_FAILED:
      return "connect_failed";
    case WL_CONNECTION_LOST:
      return "connection_lost";
    case WL_DISCONNECTED:
      return "disconnected";
    case WL_IDLE_STATUS:
      return "idle";
    default:
      return "unknown";
  }
}

String stationWifiHostname() {
  String host = "bin-commander-";
  String mac = WiFi.macAddress();
  mac.replace(":", "");
  if (mac.length() >= 4) {
    host += mac.substring(mac.length() - 4);
  } else {
    host += "fbb";
  }
  host.toLowerCase();
  return host;
}

void beginStationWifi(const char *reason) {
  if (!stationWifiConfigured()) {
    stationWifiConnecting = false;
    return;
  }

  if (apRunning) {
    WiFi.mode(WIFI_AP_STA);
  } else {
    WiFi.mode(WIFI_STA);
  }
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  WiFi.setHostname(stationWifiHostname().c_str());
  WiFi.disconnect(false, false);
  delay(20);
  WiFi.begin(stationWifiSsid.c_str(), stationWifiPassword.length() > 0 ? stationWifiPassword.c_str() : nullptr);
  stationWifiConnecting = true;
  stationWifiLastAttemptMs = millis();
  stationWifiLastStatus = WiFi.status();
  logEvent(String("Station Wi-Fi connect started") +
           (reason != nullptr && reason[0] != '\0' ? String(": ") + reason : String()) +
           " -> " + stationWifiSsid);
}

void updateStationWifi() {
  if (!stationWifiConfigured()) {
    stationWifiConnecting = false;
    stationWifiEverConnected = false;
    return;
  }

  const unsigned long now = millis();
  const wl_status_t status = WiFi.status();
  if (status != stationWifiLastStatus) {
    stationWifiLastStatus = status;
    logEvent(String("Station Wi-Fi status: ") + stationWifiStatusName(status));
  }

  if (status == WL_CONNECTED) {
    if (!stationWifiEverConnected) {
      stationWifiConnectedAtMs = now;
      stationWifiEverConnected = true;
      logEvent(String("Station Wi-Fi connected: ") + WiFi.localIP().toString());
    }
    stationWifiConnecting = false;
    return;
  }

  stationWifiConnecting = false;
  if (now - stationWifiLastAttemptMs >= WIFI_STATION_RETRY_INTERVAL_MS) {
    beginStationWifi("retry");
  }
}

bool startAccessPoint() {
  if (espNowReady) {
    esp_now_deinit();
    espNowReady = false;
  }

  resetApDisconnectFailSafeState();

  WiFi.persistent(false);
  WiFi.setAutoReconnect(stationWifiConfigured());
  WiFi.disconnect(true, false);
  WiFi.mode(WIFI_OFF);
  delay(WIFI_RESET_SETTLE_MS);

  WiFi.mode(stationWifiConfigured() ? WIFI_AP_STA : WIFI_AP);
  WiFi.setSleep(false);
  WiFi.softAPdisconnect(true);
  delay(WIFI_RESET_SETTLE_MS);

  const IPAddress apIp(192, 168, 4, 1);
  const IPAddress apGateway(192, 168, 4, 1);
  const IPAddress apSubnet(255, 255, 255, 0);
  if (!WiFi.softAPConfig(apIp, apGateway, apSubnet)) {
    Serial.println("WARN: softAPConfig failed.");
  }

  bool ok = !accessPasswordRequired()
                ? WiFi.softAP(AP_SSID, nullptr, AP_CHANNEL, 0, AP_MAX_CONNECTIONS)
                : WiFi.softAP(AP_SSID, deviceWifiPassword.c_str(), AP_CHANNEL, 0, AP_MAX_CONNECTIONS);
  apSecure = ok && accessPasswordRequired();

  if (ok) {
    delay(AP_START_SETTLE_MS);
    if (esp_wifi_set_max_tx_power(WIFI_MAX_TX_POWER_QUARTER_DBM) != ESP_OK) {
      Serial.println("WARN: Failed to raise WiFi TX power.");
    }
    if (stationWifiConfigured()) {
      beginStationWifi("access point start");
    }
    lastEspNowRetryMs = millis() - ESPNOW_RETRY_INTERVAL_MS;
    logEvent(String("Access point started on channel ") + String(AP_CHANNEL));
  } else {
    logEvent("Access point start failed.");
  }

  apRunning = ok;
  return ok;
}

String macToString(const uint8_t *mac) {
  if (mac == nullptr) {
    return "00:00:00:00:00:00";
  }

  char buf[18];
  snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(buf);
}

bool macEquals(const uint8_t left[6], const uint8_t right[6]) {
  return memcmp(left, right, 6) == 0;
}

uint8_t currentModuleFlags() {
  uint8_t flags = 0;
  if (relay1On) flags |= ESPNOW_MODULE_RELAY1_ON;
  if (relay2On) flags |= ESPNOW_MODULE_RELAY2_ON;
  if (emergencyStopLatched || hardwareEmergencyStopActive) flags |= ESPNOW_MODULE_ESTOP;
  if (faultLatched) flags |= ESPNOW_MODULE_FAULT;
  return flags;
}

EspNowModulePacket makeModulePacket(const uint8_t type,
                                    const uint8_t relay,
                                    const uint8_t action) {
  EspNowModulePacket packet = {};
  packet.magic = ESPNOW_MODULE_MAGIC;
  packet.version = ESPNOW_MODULE_VERSION;
  packet.type = type;
  packet.role = DEVICE_ESPNOW_ROLE;
  packet.relay = relay;
  packet.action = action;
  packet.flags = currentModuleFlags();
  packet.sequence = ++espNowModuleSequence;
  snprintf(packet.name, sizeof(packet.name), "%s", NETWORK_NAME);
  return packet;
}

bool ensureEspNowPeer(const uint8_t mac[6]) {
  if (!espNowReady || mac == nullptr) {
    return false;
  }
  if (esp_now_is_peer_exist(mac)) {
    return true;
  }

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, mac, 6);
  peer.channel = AP_CHANNEL;
  peer.encrypt = false;
  const esp_err_t result = esp_now_add_peer(&peer);
  if (result == ESP_OK || result == ESP_ERR_ESPNOW_EXIST) {
    return true;
  }
  logEvent(String("ESP-NOW peer add failed: ") + macToString(mac));
  return false;
}

bool sendEspNowModulePacket(const uint8_t mac[6], const EspNowModulePacket &packet) {
  if (!ensureEspNowPeer(mac)) {
    cluckMagicLastCommandStatus = "peer_unavailable";
    cluckMagicLastCommandMs = millis();
    return false;
  }
  const esp_err_t result =
      esp_now_send(mac, reinterpret_cast<const uint8_t *>(&packet), sizeof(packet));
  if (result == ESP_OK) {
    espNowPacketsTx++;
    espNowLastTxMs = millis();
    return true;
  }
  cluckMagicLastCommandStatus = "send_failed";
  cluckMagicLastCommandMs = millis();
  logEvent(String("ESP-NOW send failed to ") + macToString(mac));
  return false;
}

bool selectedCluckMagicMac(uint8_t outMac[6]) {
  if (cluckMagicSelectedMac.length() == 0) {
    return false;
  }
  return parseMacString(cluckMagicSelectedMac, outMac);
}

int findCluckMagicModuleByMac(const uint8_t mac[6]) {
  for (size_t i = 0; i < MAX_CLUCK_MODULES; ++i) {
    if (cluckMagicModules[i].used && macEquals(cluckMagicModules[i].mac, mac)) {
      return static_cast<int>(i);
    }
  }
  return -1;
}

int firstOnlineCluckMagicModule(const unsigned long now) {
  for (size_t i = 0; i < MAX_CLUCK_MODULES; ++i) {
    if (cluckMagicModules[i].used &&
        now - cluckMagicModules[i].lastSeenMs <= CLUCK_MAGIC_ONLINE_TIMEOUT_MS) {
      return static_cast<int>(i);
    }
  }
  return -1;
}

int selectedCluckMagicModule(const unsigned long now) {
  uint8_t selectedMac[6] = {0};
  if (selectedCluckMagicMac(selectedMac)) {
    const int idx = findCluckMagicModuleByMac(selectedMac);
    if (idx >= 0 &&
        now - cluckMagicModules[idx].lastSeenMs <= CLUCK_MAGIC_ONLINE_TIMEOUT_MS) {
      return idx;
    }
    return -1;
  }
  return firstOnlineCluckMagicModule(now);
}

bool effectiveCluckMagicMac(uint8_t outMac[6]) {
  if (selectedCluckMagicMac(outMac)) {
    return true;
  }
  const int idx = firstOnlineCluckMagicModule(millis());
  if (idx >= 0) {
    memcpy(outMac, cluckMagicModules[idx].mac, 6);
    return true;
  }
  return false;
}

void updateCluckMagicModule(const uint8_t mac[6], const EspNowModulePacket &packet) {
  if (mac == nullptr || packet.role != ESPNOW_ROLE_CLUCK_MAGIC) {
    return;
  }

  int target = findCluckMagicModuleByMac(mac);
  if (target < 0) {
    for (size_t i = 0; i < MAX_CLUCK_MODULES; ++i) {
      if (!cluckMagicModules[i].used) {
        target = static_cast<int>(i);
        break;
      }
    }
  }
  if (target < 0) {
    unsigned long oldest = ULONG_MAX;
    for (size_t i = 0; i < MAX_CLUCK_MODULES; ++i) {
      if (cluckMagicModules[i].lastSeenMs < oldest) {
        oldest = cluckMagicModules[i].lastSeenMs;
        target = static_cast<int>(i);
      }
    }
  }
  if (target < 0) {
    return;
  }

  CluckMagicModule &module = cluckMagicModules[target];
  const bool firstSeen = !module.used;
  module.used = true;
  memcpy(module.mac, mac, 6);
  snprintf(module.name, sizeof(module.name), "%s",
           packet.name[0] != '\0' ? packet.name : "Cluck-o-Magic");
  module.lastSeenMs = millis();
  module.relay1On = (packet.flags & ESPNOW_MODULE_RELAY1_ON) != 0;
  module.relay2On = (packet.flags & ESPNOW_MODULE_RELAY2_ON) != 0;
  module.emergencyStop = (packet.flags & ESPNOW_MODULE_ESTOP) != 0;
  module.fault = (packet.flags & ESPNOW_MODULE_FAULT) != 0;
  module.sequence = packet.sequence;
  if (firstSeen) {
    logEvent(String("Detected Cluck-o-Magic: ") + macToString(mac));
  }
}

bool applyModuleRelayAction(const uint8_t relay, const uint8_t action) {
  auto targetFor = [&](const bool current, bool &outTarget) -> bool {
    if (action == ESPNOW_ACTION_OFF) {
      outTarget = false;
      return true;
    }
    if (action == ESPNOW_ACTION_ON) {
      outTarget = true;
      return true;
    }
    if (action == ESPNOW_ACTION_TOGGLE) {
      outTarget = !current;
      return true;
    }
    return false;
  };

  bool changed = false;
  if (relay == ESPNOW_RELAY_1 || relay == ESPNOW_RELAY_BOTH) {
    bool target = relay1On;
    if (!targetFor(relay1On, target)) {
      return false;
    }
    setRelayChannel(1, target, RelayOwner::EspNow, manualOverrideTimeoutMs, "cluck magic");
    changed = true;
  }
  if (relay == ESPNOW_RELAY_2 || relay == ESPNOW_RELAY_BOTH) {
    bool target = relay2On;
    if (!targetFor(relay2On, target)) {
      return false;
    }
    setRelayChannel(2, target, RelayOwner::EspNow, manualOverrideTimeoutMs, "cluck magic");
    changed = true;
  }
  return changed;
}

bool sendCluckMagicState(const uint8_t mac[6], const uint8_t type) {
  const EspNowModulePacket packet = makeModulePacket(type, ESPNOW_RELAY_NONE, ESPNOW_ACTION_OFF);
  return sendEspNowModulePacket(mac, packet);
}

void processEspNowModulePacket(const EspNowModulePacket &packet, const uint8_t sender[6]) {
  if (packet.magic != ESPNOW_MODULE_MAGIC || packet.version != ESPNOW_MODULE_VERSION) {
    return;
  }

  if (packet.role == ESPNOW_ROLE_CLUCK_MAGIC &&
      (packet.type == ESPNOW_MODULE_HELLO || packet.type == ESPNOW_MODULE_STATE)) {
    updateCluckMagicModule(sender, packet);
    return;
  }

  if (!CLUCK_MAGIC_ROLE || packet.type != ESPNOW_MODULE_COMMAND ||
      packet.role != ESPNOW_ROLE_BIN_COMMANDER) {
    return;
  }

  if (rebootPending || emergencyStopLatched || hardwareEmergencyStopActive || faultLatched) {
    logEvent("Cluck-o-Magic command ignored: safety interlock active.");
    sendCluckMagicState(sender, ESPNOW_MODULE_STATE);
    return;
  }

  if (applyModuleRelayAction(packet.relay, packet.action)) {
    logEvent(String("Cluck-o-Magic relay command from ") + macToString(sender));
  }
  sendCluckMagicState(sender, ESPNOW_MODULE_STATE);
}

void updateCluckMagicAnnounce() {
  if (!CLUCK_MAGIC_ROLE || !espNowReady) {
    return;
  }
  const unsigned long now = millis();
  if (now - cluckMagicLastAnnounceMs < CLUCK_MAGIC_ANNOUNCE_INTERVAL_MS) {
    return;
  }
  static const uint8_t broadcastMac[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  cluckMagicLastAnnounceMs = now;
  sendCluckMagicState(broadcastMac, ESPNOW_MODULE_HELLO);
}

bool sendCluckMagicCommand(const uint8_t relay, const uint8_t action) {
  if (CLUCK_MAGIC_ROLE) {
    cluckMagicLastCommandStatus = "local_shaker_role";
    cluckMagicLastCommandMs = millis();
    return false;
  }
  if (!espNowReady) {
    cluckMagicLastCommandStatus = "espnow_not_ready";
    cluckMagicLastCommandMs = millis();
    return false;
  }
  if (emergencyStopLatched || hardwareEmergencyStopActive) {
    cluckMagicLastCommandStatus = "emergency_stop";
    cluckMagicLastCommandMs = millis();
    return false;
  }

  uint8_t mac[6] = {0};
  if (!effectiveCluckMagicMac(mac)) {
    cluckMagicLastCommandStatus = "no_module_selected";
    cluckMagicLastCommandMs = millis();
    return false;
  }

  const EspNowModulePacket packet = makeModulePacket(ESPNOW_MODULE_COMMAND, relay, action);
  const bool ok = sendEspNowModulePacket(mac, packet);
  cluckMagicLastCommandStatus = ok ? "sent" : cluckMagicLastCommandStatus;
  cluckMagicLastCommandMs = millis();
  if (ok) {
    logEvent(String("Cluck-o-Magic command sent to ") + macToString(mac));
  }
  return ok;
}

void onEspNowDataReceived(const uint8_t *mac, const uint8_t *incomingData, int len) {
#ifdef FBB_CHICKEN_MESH
  if (chickenMesh.accept(incomingData, len)) return;
#endif
  if (incomingData == nullptr || len <= 0) {
    return;
  }

  if (incomingData[0] == ESPNOW_MODULE_MAGIC &&
      len >= static_cast<int>(sizeof(EspNowModulePacket))) {
    EspNowModulePacket packet;
    memcpy(&packet, incomingData, sizeof(packet));
    if (packet.version != ESPNOW_MODULE_VERSION) {
      return;
    }

    portENTER_CRITICAL(&espNowMux);
    pendingEspNowModulePacket = packet;
    espNowModulePacketPending = true;
    espNowPacketsRx++;
    espNowLastRxMs = millis();
    if (mac != nullptr) {
      memcpy(pendingEspNowModuleSender, mac, sizeof(pendingEspNowModuleSender));
      memcpy(espNowLastSender, mac, sizeof(espNowLastSender));
    }
    portEXIT_CRITICAL(&espNowMux);
    return;
  }

  if (len < static_cast<int>(sizeof(EspNowCommand))) {
    return;
  }

  EspNowCommand cmd;
  memcpy(&cmd, incomingData, sizeof(EspNowCommand));
  if (cmd.magic != ESPNOW_MAGIC) {
    return;
  }

  portENTER_CRITICAL(&espNowMux);
  pendingEspNowCommand = cmd;
  espNowCommandPending = true;
  espNowPacketsRx++;
  espNowLastRxMs = millis();
  if (mac != nullptr) {
    memcpy(espNowLastSender, mac, sizeof(espNowLastSender));
  }
  portEXIT_CRITICAL(&espNowMux);
}

bool initEspNow() {
  espNowReady = false;
  esp_now_deinit();

  if (!apRunning && esp_wifi_set_channel(AP_CHANNEL, WIFI_SECOND_CHAN_NONE) != ESP_OK) {
    Serial.println("WARN: Failed to set WiFi channel for ESP-NOW.");
  }

  if (esp_now_init() != ESP_OK) {
    Serial.println("ERROR: esp_now_init failed.");
    logEvent("ESP-NOW init failed.");
    espNowReady = false;
    return false;
  }

  if (esp_now_register_recv_cb(onEspNowDataReceived) != ESP_OK) {
    Serial.println("ERROR: esp_now_register_recv_cb failed.");
    logEvent("ESP-NOW receive callback registration failed.");
    esp_now_deinit();
    espNowReady = false;
    return false;
  }

  espNowReady = true;
#ifdef FBB_CHICKEN_MESH
  if (chickenMesh.configured && !chickenMesh.begin([](const chickenmesh::Frame &f) {
        return f.type == chickenmesh::Pong;
      }, false)) {
    logEvent("Chicken Chat mesh initialization failed.");
  }
#endif
  logEvent("ESP-NOW ready.");
  return true;
}

void processEspNowCommands() {
  if (espNowModulePacketPending) {
    EspNowModulePacket packet;
    uint8_t sender[6];

    portENTER_CRITICAL(&espNowMux);
    packet = pendingEspNowModulePacket;
    espNowModulePacketPending = false;
    memcpy(sender, pendingEspNowModuleSender, sizeof(sender));
    portEXIT_CRITICAL(&espNowMux);

    processEspNowModulePacket(packet, sender);
  }

  if (!espNowCommandPending) {
    return;
  }

  EspNowCommand cmd;
  uint8_t sender[6];

  portENTER_CRITICAL(&espNowMux);
  cmd = pendingEspNowCommand;
  espNowCommandPending = false;
  memcpy(sender, espNowLastSender, sizeof(sender));
  portEXIT_CRITICAL(&espNowMux);

  if (directControlLocked()) {
    Serial.println("ESP-NOW command ignored: control lockout active.");
    return;
  }

  if (feedLogicMode != FeedLogicMode::Manual) {
    Serial.println("ESP-NOW relay command ignored: feed logic mode active.");
    return;
  }

  bool outputsChanged = false;

  auto applyAction = [&](bool &state) {
    if (cmd.action == ESPNOW_ACTION_OFF) {
      state = false;
      return true;
    }
    if (cmd.action == ESPNOW_ACTION_ON) {
      state = true;
      return true;
    }
    if (cmd.action == ESPNOW_ACTION_TOGGLE) {
      state = !state;
      return true;
    }
    return false;
  };

  if (cmd.relay == ESPNOW_RELAY_1) {
    outputsChanged = applyAction(relay1On) || outputsChanged;
  } else if (cmd.relay == ESPNOW_RELAY_2) {
    outputsChanged = applyAction(relay2On) || outputsChanged;
  } else if (cmd.relay == ESPNOW_RELAY_BOTH) {
    const bool left = applyAction(relay1On);
    const bool right = applyAction(relay2On);
    outputsChanged = left || right || outputsChanged;
  }

  if (outputsChanged) {
    if (cmd.relay == ESPNOW_RELAY_1) {
      setRelayChannel(1, relay1On, RelayOwner::EspNow, manualOverrideTimeoutMs, "espnow");
    } else if (cmd.relay == ESPNOW_RELAY_2) {
      setRelayChannel(2, relay2On, RelayOwner::EspNow, manualOverrideTimeoutMs, "espnow");
    } else if (cmd.relay == ESPNOW_RELAY_BOTH) {
      setRelayChannel(1, relay1On, RelayOwner::EspNow, manualOverrideTimeoutMs, "espnow");
      setRelayChannel(2, relay2On, RelayOwner::EspNow, manualOverrideTimeoutMs, "espnow");
    }
  }

  Serial.print("ESP-NOW cmd from ");
  Serial.print(macToString(sender));
  Serial.print(" relay=");
  Serial.print(cmd.relay);
  Serial.print(" action=");
  Serial.print(cmd.action);
  Serial.print(" led=");
  Serial.println(cmd.led);
  logEvent(String("ESP-NOW relay command from ") + macToString(sender));
}

String buildCluckMagicModulesJson(const unsigned long now) {
  String json = "[";
  bool first = true;
  for (size_t i = 0; i < MAX_CLUCK_MODULES; ++i) {
    const CluckMagicModule &module = cluckMagicModules[i];
    if (!module.used) {
      continue;
    }
    if (!first) {
      json += ",";
    }
    first = false;
    const unsigned long ageMs = now - module.lastSeenMs;
    json += "{\"mac\":\"";
    json += macToString(module.mac);
    json += "\",\"name\":\"";
    json += jsonEscape(String(module.name));
    json += "\",\"age_ms\":";
    json += String(ageMs);
    json += ",\"online\":";
    json += ageMs <= CLUCK_MAGIC_ONLINE_TIMEOUT_MS ? "true" : "false";
    json += ",\"relay1_on\":";
    json += module.relay1On ? "true" : "false";
    json += ",\"relay2_on\":";
    json += module.relay2On ? "true" : "false";
    json += ",\"emergency_stop\":";
    json += module.emergencyStop ? "true" : "false";
    json += ",\"fault\":";
    json += module.fault ? "true" : "false";
    json += "}";
  }
  json += "]";
  return json;
}

void sendStatusJson() {
  const unsigned long now = millis();
  const uint8_t stationCount = WiFi.softAPgetStationNum();
  const HealthSnapshot health = buildHealthSnapshot(now);
  const bool feedRawActive = readFeedRawActive();
  const bool lowFeed = !feedPresent;
  const unsigned long lowFeedDurationMs = (lowFeed && lowFeedSinceMs != 0) ? (now - lowFeedSinceMs) : 0;
  const unsigned long feedPresentDurationMs =
      (feedPresent && feedPresentSinceMs != 0) ? (now - feedPresentSinceMs) : 0;
  const unsigned long relay1RuntimeMs = relayOnSinceMs[0] != 0 ? (now - relayOnSinceMs[0]) : 0;
  const unsigned long relay2RuntimeMs = relayOnSinceMs[1] != 0 ? (now - relayOnSinceMs[1]) : 0;
  const unsigned long relay1LeaseRemaining =
      relayLeaseUntilMs[0] != 0 && !timeReached(now, relayLeaseUntilMs[0])
          ? (relayLeaseUntilMs[0] - now)
          : 0;
  const unsigned long relay2LeaseRemaining =
      relayLeaseUntilMs[1] != 0 && !timeReached(now, relayLeaseUntilMs[1])
          ? (relayLeaseUntilMs[1] - now)
          : 0;
  const unsigned long apNoStationElapsedMs = (apNoStationSinceMs != 0) ? (now - apNoStationSinceMs) : 0;
  const unsigned long apStationChangeMs = apLastStationChangeMs;
  const unsigned long apDisconnectGraceRemainingMs =
      (apDisconnectGuardArmed && stationCount == 0 && apNoStationSinceMs != 0 &&
       apNoStationElapsedMs < AP_DISCONNECT_OFF_DELAY_MS)
          ? (AP_DISCONNECT_OFF_DELAY_MS - apNoStationElapsedMs)
          : 0;
  const unsigned long rebootTargetMs = rebootRequestedMs + REBOOT_DELAY_MS;
  const unsigned long rebootRemainingMs =
      (rebootPending && !timeReached(now, rebootTargetMs)) ? (rebootTargetMs - now) : 0;
  const bool maintenanceUnlocked = maintenanceSessionMatchesCurrentRequest();
  const unsigned long maintenanceRemainingMs = maintenanceSessionRemainingMs(now);
  const unsigned long buttonLastActionAgeMs =
      buttonLastActionMs != 0 ? (now - buttonLastActionMs) : 0;
  const unsigned long feedLogicTopOffRemaining = feedLogicTopOffRemainingMs(now);
  const unsigned long manualControlOverrideRemaining = manualControlOverrideRemainingMs(now);
  const unsigned long alarmLastClearAgeMs =
      alarmLastClearedMs != 0 ? (now - alarmLastClearedMs) : 0;
  const int cluckSelectedIdx = selectedCluckMagicModule(now);
  const CluckMagicModule *selectedCluck =
      cluckSelectedIdx >= 0 ? &cluckMagicModules[cluckSelectedIdx] : nullptr;
  uint8_t effectiveCluckMacValue[6] = {0};
  const bool hasEffectiveCluckMac = effectiveCluckMagicMac(effectiveCluckMacValue);
  const unsigned long cluckLastCommandAgeMs =
      cluckMagicLastCommandMs != 0 ? (now - cluckMagicLastCommandMs) : 0;

  sendNoStoreHeaders();
  String json = "{";
  json.reserve(4300);
  json += "\"uptime_ms\":" + String(now) + ",";
  json += "\"firmware_version\":\"" + jsonEscape(String(FIRMWARE_VERSION)) + "\",";
  json += "\"build_profile\":\"" + jsonEscape(String(BUILD_PROFILE)) + "\",";
  json += "\"config_version\":" + String(CONFIG_VERSION) + ",";
  json += "\"test_open_access\":" + String(OPEN_TEST_ACCESS ? "true" : "false") + ",";
  json += "\"open_access\":" + String(!accessPasswordRequired() ? "true" : "false") + ",";
  json += "\"boot_reason\":\"" + jsonEscape(bootReasonLabel) + "\",";
  json += "\"controller_state\":\"" + jsonEscape(String(controllerStateName(now))) + "\",";
  json += "\"controller_state_detail\":\"" + jsonEscape(controllerStateDetail(now)) + "\",";
  json += "\"controller_state_code\":" + String(controllerStateCode(now)) + ",";
  json += "\"maintenance_unlocked\":" + String(maintenanceUnlocked ? "true" : "false") + ",";
  json += "\"maintenance_session_remaining_ms\":" + String(maintenanceRemainingMs) + ",";
  json += "\"health_ok\":" + String(health.ok ? "true" : "false") + ",";
  json += "\"health_level\":\"" + jsonEscape(health.level) + "\",";
  json += "\"health_level_code\":" + String(healthLevelCode(health.level)) + ",";
  json += "\"health_title\":\"" + jsonEscape(health.title) + "\",";
  json += "\"health_detail\":\"" + jsonEscape(health.detail) + "\",";
  json += "\"free_heap\":" + String(ESP.getFreeHeap()) + ",";
  json += "\"min_free_heap\":" + String(ESP.getMinFreeHeap()) + ",";
  json += "\"chip_model\":\"" + String(ESP.getChipModel()) + "\",";
  json += "\"chip_revision\":" + String(ESP.getChipRevision()) + ",";
  json += "\"network_name\":\"" + jsonEscape(String(NETWORK_NAME)) + "\",";
  json += "\"device_role\":\"" + jsonEscape(String(DEVICE_ROLE_NAME)) + "\",";
  json += "\"cpu_mhz\":" + String(ESP.getCpuFreqMHz()) + ",";
  json += "\"flash_mb\":" + String(ESP.getFlashChipSize() / (1024 * 1024)) + ",";
  json += "\"ap_ssid\":\"" + String(AP_SSID) + "\",";
  json += "\"ap_ip\":\"" + WiFi.softAPIP().toString() + "\",";
  json += "\"ap_running\":" + String(apRunning ? "true" : "false") + ",";
  json += "\"ap_secure\":" + String(apSecure ? "true" : "false") + ",";
  json += "\"ap_password_enabled\":" + String(apPasswordEnabled ? "true" : "false") + ",";
  json += "\"ap_channel\":" + String(AP_CHANNEL) + ",";
  json += "\"ap_disconnect_guard_armed\":" + String(apDisconnectGuardArmed ? "true" : "false") + ",";
  json += "\"station_wifi_enabled\":" + String(stationWifiEnabled ? "true" : "false") + ",";
  json += "\"station_wifi_configured\":" + String(stationWifiConfigured() ? "true" : "false") + ",";
  json += "\"station_wifi_connecting\":" + String(stationWifiConnecting ? "true" : "false") + ",";
  json += "\"station_wifi_connected\":" + String(stationWifiConnected() ? "true" : "false") + ",";
  json += "\"station_wifi_ssid\":\"" + jsonEscape(stationWifiSsid) + "\",";
  json += "\"station_wifi_password_set\":" + String(stationWifiPassword.length() > 0 ? "true" : "false") + ",";
  json += "\"station_wifi_status\":\"" + jsonEscape(String(stationWifiStatusName(WiFi.status()))) + "\",";
  json += "\"station_wifi_ip\":\"" + String(stationWifiConnected() ? WiFi.localIP().toString() : String("0.0.0.0")) + "\",";
  json += "\"station_wifi_rssi\":" + String(stationWifiConnected() ? WiFi.RSSI() : 0) + ",";
  json += "\"wifi_channel\":" + String(WiFi.channel()) + ",";
  json += "\"station_wifi_connected_ms\":" +
          String(stationWifiConnected() && stationWifiConnectedAtMs != 0 ? (now - stationWifiConnectedAtMs) : 0) + ",";
  json += "\"network_update_url\":\"" +
          String(stationWifiConnected() ? String("http://") + WiFi.localIP().toString() + "/update" : String("")) + "\",";
  json += "\"notification_email_enabled\":" + String(notificationEmailEnabled ? "true" : "false") + ",";
  json += "\"notification_email_to\":\"" + jsonEscape(notificationEmailTo) + "\",";
  json += "\"notification_hub_url\":\"" + jsonEscape(notificationHubUrl) + "\",";
  json += "\"notification_status\":\"" + jsonEscape(notificationStatusDetail()) + "\",";
  json += "\"notification_last_status\":\"" + jsonEscape(notificationLastStatus) + "\",";
  json += "\"notification_last_attempt_ms\":" + String(notificationLastAttemptMs) + ",";
  json += "\"notification_last_success_ms\":" + String(notificationLastSuccessMs) + ",";
  json += "\"button_gpio\":" + String(PIN_BUTTON) + ",";
  json += "\"relay_1_gpio\":" + String(PIN_RELAY_1) + ",";
  json += "\"relay_2_gpio\":" + String(PIN_RELAY_2) + ",";
  json += "\"status_led_gpio\":" + String(PIN_LED) + ",";
  json += "\"relay_active_high\":" + String(relayActiveHigh ? "true" : "false") + ",";
  json += "\"led_active_high\":" + String(ledActiveHigh ? "true" : "false") + ",";
  json += "\"feed_sensor_active_high\":" + String(feedPresentWhenHigh ? "true" : "false") + ",";
  json += "\"hardware_emergency_stop_gpio\":" + String(PIN_EMERGENCY_STOP) + ",";
  json += "\"hardware_emergency_stop_enabled\":" + String(pinIsConfigured(PIN_EMERGENCY_STOP) ? "true" : "false") + ",";
  json += "\"hardware_emergency_stop_active\":" + String(hardwareEmergencyStopActive ? "true" : "false") + ",";
  json += "\"hardware_emergency_stop_active_high\":" + String(EMERGENCY_STOP_ACTIVE_HIGH ? "true" : "false") + ",";
  json += "\"espnow_ready\":" + String(espNowReady ? "true" : "false") + ",";
  json += "\"espnow_packets_rx\":" + String(espNowPacketsRx) + ",";
  json += "\"espnow_packets_tx\":" + String(espNowPacketsTx) + ",";
  json += "\"espnow_last_rx_ms\":" + String(espNowLastRxMs) + ",";
  json += "\"espnow_last_tx_ms\":" + String(espNowLastTxMs) + ",";
  json += "\"espnow_last_sender\":\"" + macToString(espNowLastSender) + "\",";
  json += "\"cluck_magic_role\":" + String(CLUCK_MAGIC_ROLE ? "true" : "false") + ",";
  json += "\"cluck_magic_selected_mac\":\"" + jsonEscape(cluckMagicSelectedMac) + "\",";
  json += "\"cluck_magic_effective_mac\":\"" +
          String(hasEffectiveCluckMac ? macToString(effectiveCluckMacValue) : String("")) + "\",";
  json += "\"cluck_magic_selected_online\":" + String(selectedCluck != nullptr ? "true" : "false") + ",";
  json += "\"cluck_magic_selected_name\":\"" +
          jsonEscape(selectedCluck != nullptr ? String(selectedCluck->name) : String("")) + "\",";
  json += "\"cluck_magic_bin1_on\":" +
          String(selectedCluck != nullptr && selectedCluck->relay1On ? "true" : "false") + ",";
  json += "\"cluck_magic_bin2_on\":" +
          String(selectedCluck != nullptr && selectedCluck->relay2On ? "true" : "false") + ",";
  json += "\"cluck_magic_emergency_stop\":" +
          String(selectedCluck != nullptr && selectedCluck->emergencyStop ? "true" : "false") + ",";
  json += "\"cluck_magic_fault\":" +
          String(selectedCluck != nullptr && selectedCluck->fault ? "true" : "false") + ",";
  json += "\"cluck_magic_last_command_status\":\"" + jsonEscape(cluckMagicLastCommandStatus) + "\",";
  json += "\"cluck_magic_last_command_age_ms\":" + String(cluckLastCommandAgeMs) + ",";
  json += "\"cluck_magic_modules\":";
  json += buildCluckMagicModulesJson(now);
  json += ",";
  json += "\"stations\":" + String(stationCount) + ",";
  json += "\"ap_station_last_change_ms\":" + String(apStationChangeMs) + ",";
  json += "\"ap_disconnect_grace_remaining_ms\":" + String(apDisconnectGraceRemainingMs) + ",";
  json += "\"button_pressed\":" + String(buttonPressed() ? "true" : "false") + ",";
  json += "\"button_last_action\":\"" + jsonEscape(buttonLastAction) + "\",";
  json += "\"button_last_action_ms\":" + String(buttonLastActionMs) + ",";
  json += "\"button_last_action_age_ms\":" + String(buttonLastActionAgeMs) + ",";
  json += "\"feed_sensor_gpio\":" + String(PIN_FEED_SENSOR) + ",";
  json += "\"feed_raw_high\":" + String(feedRawActive ? "true" : "false") + ",";
  json += "\"feed_present\":" + String(feedPresent ? "true" : "false") + ",";
  json += "\"feed_present_ms\":" + String(feedPresentDurationMs) + ",";
  json += "\"low_feed\":" + String(lowFeed ? "true" : "false") + ",";
  json += "\"low_feed_ms\":" + String(lowFeedDurationMs) + ",";
  json += "\"alarm_state\":\"" + String(alarmStateName(alarmState)) + "\",";
  json += "\"alarm_no_runout\":" + String(alarmState == AlarmState::NoRunoutTooLong ? "true" : "false") + ",";
  json += "\"alarm_empty_too_long\":" + String(alarmState == AlarmState::EmptyTooLong ? "true" : "false") + ",";
  json += "\"feed_alarm_active\":" + String(alarmState != AlarmState::Normal ? "true" : "false") + ",";
  json += "\"alarm_clear_available\":" + String(alarmState != AlarmState::Normal ? "true" : "false") + ",";
  json += "\"alarm_last_cleared_ms\":" + String(alarmLastClearedMs) + ",";
  json += "\"alarm_last_clear_age_ms\":" + String(alarmLastClearAgeMs) + ",";
  json += "\"alarm_last_cleared_state\":\"" + String(alarmStateName(alarmLastClearedState)) + "\",";
  json += "\"alarm_last_clear_reason\":\"" + jsonEscape(alarmLastClearReason) + "\",";
  json += "\"no_runout_alarm_after_ms\":" + String(noRunoutAlarmDelayMs) + ",";
  json += "\"empty_too_long_alarm_after_ms\":" + String(emptyTooLongAlarmDelayMs) + ",";
  json += "\"manual_override_timeout_ms\":" + String(manualOverrideTimeoutMs) + ",";
  json += "\"manual_control_override_active\":" +
          String(manualControlOverrideRemaining > 0 ? "true" : "false") + ",";
  json += "\"manual_control_override_remaining_ms\":" + String(manualControlOverrideRemaining) + ",";
  json += "\"relay_max_runtime_ms\":" + String(relayMaxRuntimeMs) + ",";
  json += "\"automation_keepalive_ms\":" + String(automationKeepaliveMs) + ",";
  json += "\"alarm_led_on\":" + String(ledOn ? "true" : "false") + ",";
  json += "\"emergency_stop_latched\":" + String(emergencyStopLatched ? "true" : "false") + ",";
  json += "\"fault_latched\":" + String(faultLatched ? "true" : "false") + ",";
  json += "\"fault_reason\":\"" + jsonEscape(faultReason) + "\",";
  json += "\"feed_bin1_name\":\"" + jsonEscape(feedBin1Name) + "\",";
  json += "\"feed_bin2_name\":\"" + jsonEscape(feedBin2Name) + "\",";
  json += "\"feed_bin1_on\":" + String(relay1On ? "true" : "false") + ",";
  json += "\"feed_bin2_on\":" + String(relay2On ? "true" : "false") + ",";
  json += "\"feed_bin1_owner\":\"" + String(relayOwnerName(relayLeaseOwner[0])) + "\",";
  json += "\"feed_bin2_owner\":\"" + String(relayOwnerName(relayLeaseOwner[1])) + "\",";
  json += "\"feed_bin1_lease_remaining_ms\":" + String(relay1LeaseRemaining) + ",";
  json += "\"feed_bin2_lease_remaining_ms\":" + String(relay2LeaseRemaining) + ",";
  json += "\"feed_bin1_runtime_ms\":" + String(relay1RuntimeMs) + ",";
  json += "\"feed_bin2_runtime_ms\":" + String(relay2RuntimeMs) + ",";
  json += "\"feed_logic_mode\":\"" + String(feedLogicModeName(feedLogicMode)) + "\",";
  json += "\"feed_logic_mode_label\":\"" + jsonEscape(String(feedLogicModeLabel(feedLogicMode))) + "\",";
  json += "\"feed_logic_run_rule\":\"" + jsonEscape(String(feedLogicModeRunRule(feedLogicMode))) + "\",";
  json += "\"feed_logic_preferred_bin\":" + String(feedLogicPreferredBin) + ",";
  json += "\"feed_logic_active_bin\":" + String(feedLogicActiveBin) + ",";
  json += "\"feed_logic_alternate_ms\":" + String(feedLogicAlternateMs) + ",";
  json += "\"feed_logic_auto_switch_ms\":" + String(feedLogicAutoSwitchMs) + ",";
  json += "\"feed_logic_top_off_ms\":" + String(feedLogicTopOffMs) + ",";
  json += "\"feed_logic_top_off_active\":" + String(feedLogicTopOffActive ? "true" : "false") + ",";
  json += "\"feed_logic_top_off_remaining_ms\":" + String(feedLogicTopOffRemaining) + ",";
  json += "\"feed_logic_switched_cycle\":" + String(feedLogicSwitchedThisCycle ? "true" : "false") + ",";
  json += "\"house_planner_name\":\"" + jsonEscape(plannerHouseName) + "\",";
  json += "\"house_planner_notes\":\"" + jsonEscape(plannerNotes) + "\",";
  json += "\"house_planner_nodes_target\":" + String(plannerNodesTarget) + ",";
  json += "\"house_planner_mesh_enabled\":" + String(plannerMeshEnabled ? "true" : "false") + ",";
  json += "\"house_planner_track_bin_level\":" + String(plannerTrackBinLevel ? "true" : "false") + ",";
  json += "\"house_planner_track_bin_clog\":" + String(plannerTrackBinClog ? "true" : "false") + ",";
  json += "\"house_planner_track_vibrator\":" + String(plannerTrackVibrator ? "true" : "false") + ",";
  json += "\"house_planner_track_hopper_auger\":" + String(plannerTrackHopperAuger ? "true" : "false") + ",";
  json += "\"house_planner_track_line_auger\":" + String(plannerTrackLineAuger ? "true" : "false") + ",";
  json += "\"house_planner_track_motor_current\":" + String(plannerTrackMotorCurrent ? "true" : "false") + ",";
  json += "\"config_loaded\":" + String(configLoaded ? "true" : "false") + ",";
  json += "\"config_dirty\":" + String(configDirty ? "true" : "false") + ",";
  json += "\"config_dirty_since_ms\":" + String(configDirtySinceMs) + ",";
  json += "\"config_dirty_age_ms\":" +
          String(configDirty && configDirtySinceMs != 0 ? (now - configDirtySinceMs) : 0) + ",";
  json += "\"config_save_fault\":" + String(configSaveFault ? "true" : "false") + ",";
  json += "\"config_save_fault_reason\":\"" + jsonEscape(configSaveFaultReason) + "\",";
  json += "\"config_last_save_attempt_ms\":" + String(lastConfigSaveAttemptMs) + ",";
  json += "\"config_last_save_attempt_age_ms\":" +
          String(lastConfigSaveAttemptMs != 0 ? (now - lastConfigSaveAttemptMs) : 0) + ",";
  json += "\"config_last_saved_ms\":" + String(lastConfigSaveMs) + ",";
  json += "\"config_last_saved_age_ms\":" +
          String(lastConfigSaveMs != 0 ? (now - lastConfigSaveMs) : 0) + ",";
  json += "\"reboot_pending\":" + String(rebootPending ? "true" : "false") + ",";
  json += "\"reboot_reason\":\"" + jsonEscape(rebootReason) + "\",";
  json += "\"reboot_remaining_ms\":" + String(rebootRemainingMs) + ",";
  json += "\"event_log_count\":" + String(eventLogCount) + ",";
  json += "\"silo1_on\":" + String(relay1On ? "true" : "false") + ",";
  json += "\"silo2_on\":" + String(relay2On ? "true" : "false") + ",";
  json += "\"relay1_on\":" + String(relay1On ? "true" : "false") + ",";
  json += "\"relay2_on\":" + String(relay2On ? "true" : "false") + ",";
  json += "\"led_on\":" + String(ledOn ? "true" : "false");
  json += "}";

  server.send(200, "application/json", json);
}

void sendConfigSaveFailureResponse(const char *context) {
  const unsigned long now = millis();
  const HealthSnapshot health = buildHealthSnapshot(now);
  sendNoStoreHeaders();

  String json = "{";
  json.reserve(1000);
  json += "\"error\":\"Persistent configuration save failed\",";
  json += "\"context\":\"" +
          jsonEscape(String(context != nullptr && context[0] != '\0' ? context : "config update")) +
          "\",";
  json += "\"config_save_fault\":true,";
  json += "\"config_save_fault_reason\":\"" + jsonEscape(configSaveFaultReason) + "\",";
  json += "\"config_dirty\":" + String(configDirty ? "true" : "false") + ",";
  json += "\"config_dirty_since_ms\":" + String(configDirtySinceMs) + ",";
  json += "\"config_last_save_attempt_ms\":" + String(lastConfigSaveAttemptMs) + ",";
  json += "\"config_last_saved_ms\":" + String(lastConfigSaveMs) + ",";
  json += "\"controller_state\":\"" + jsonEscape(String(controllerStateName(now))) + "\",";
  json += "\"controller_state_code\":" + String(controllerStateCode(now)) + ",";
  json += "\"health_level\":\"" + jsonEscape(health.level) + "\",";
  json += "\"health_level_code\":" + String(healthLevelCode(health.level)) + ",";
  json += "\"health_title\":\"" + jsonEscape(health.title) + "\",";
  json += "\"health_detail\":\"" + jsonEscape(health.detail) + "\"";
  json += "}";

  server.send(503, "application/json", json);
}

String buildHealthJson(const HealthSnapshot &health, const unsigned long now) {
  const uint8_t stationCount = WiFi.softAPgetStationNum();
  const unsigned long apNoStationElapsedMs = (apNoStationSinceMs != 0) ? (now - apNoStationSinceMs) : 0;
  const unsigned long apDisconnectGraceRemainingMs =
      (apDisconnectGuardArmed && stationCount == 0 && apNoStationSinceMs != 0 &&
       apNoStationElapsedMs < AP_DISCONNECT_OFF_DELAY_MS)
          ? (AP_DISCONNECT_OFF_DELAY_MS - apNoStationElapsedMs)
          : 0;
  const unsigned long configDirtyAgeMs =
      (configDirty && configDirtySinceMs != 0) ? (now - configDirtySinceMs) : 0;
  const unsigned long configSaveAttemptAgeMs = lastConfigSaveAttemptMs != 0 ? (now - lastConfigSaveAttemptMs) : 0;
  const unsigned long configLastSavedAgeMs = lastConfigSaveMs != 0 ? (now - lastConfigSaveMs) : 0;

  String json = "{";
  json.reserve(1200);
  json += "\"ok\":" + String(health.ok ? "true" : "false") + ",";
  json += "\"health_ok\":" + String(health.ok ? "true" : "false") + ",";
  json += "\"level\":\"" + jsonEscape(health.level) + "\",";
  json += "\"health_level_code\":" + String(healthLevelCode(health.level)) + ",";
  json += "\"title\":\"" + jsonEscape(health.title) + "\",";
  json += "\"detail\":\"" + jsonEscape(health.detail) + "\",";
  json += "\"controller_state\":\"" + jsonEscape(String(controllerStateName(now))) + "\",";
  json += "\"controller_state_detail\":\"" + jsonEscape(controllerStateDetail(now)) + "\",";
  json += "\"controller_state_code\":" + String(controllerStateCode(now)) + ",";
  json += "\"boot_reason\":\"" + jsonEscape(bootReasonLabel) + "\",";
  json += "\"uptime_ms\":" + String(now) + ",";
  json += "\"ap_running\":" + String(apRunning ? "true" : "false") + ",";
  json += "\"ap_secure\":" + String(apSecure ? "true" : "false") + ",";
  json += "\"ap_disconnect_guard_armed\":" + String(apDisconnectGuardArmed ? "true" : "false") + ",";
  json += "\"ap_disconnect_grace_remaining_ms\":" + String(apDisconnectGraceRemainingMs) + ",";
  json += "\"reboot_pending\":" + String(rebootPending ? "true" : "false") + ",";
  json += "\"reboot_reason\":\"" + jsonEscape(rebootReason) + "\",";
  json += "\"fault_latched\":" + String(faultLatched ? "true" : "false") + ",";
  json += "\"fault_reason\":\"" + jsonEscape(faultReason) + "\",";
  json += "\"emergency_stop_latched\":" + String(emergencyStopLatched ? "true" : "false") + ",";
  json += "\"hardware_emergency_stop_active\":" + String(hardwareEmergencyStopActive ? "true" : "false") + ",";
  json += "\"alarm_state\":\"" + String(alarmStateName(alarmState)) + "\",";
  json += "\"feed_alarm_active\":" + String(alarmState != AlarmState::Normal ? "true" : "false") + ",";
  json += "\"alarm_clear_available\":" + String(alarmState != AlarmState::Normal ? "true" : "false") + ",";
  json += "\"config_loaded\":" + String(configLoaded ? "true" : "false") + ",";
  json += "\"config_dirty\":" + String(configDirty ? "true" : "false") + ",";
  json += "\"config_dirty_age_ms\":" + String(configDirtyAgeMs) + ",";
  json += "\"config_save_fault\":" + String(configSaveFault ? "true" : "false") + ",";
  json += "\"config_save_fault_reason\":\"" + jsonEscape(configSaveFaultReason) + "\",";
  json += "\"config_last_save_attempt_age_ms\":" + String(configSaveAttemptAgeMs) + ",";
  json += "\"config_last_saved_age_ms\":" + String(configLastSavedAgeMs) + ",";
  json += "\"relay_1_on\":" + String(relay1On ? "true" : "false") + ",";
  json += "\"relay_2_on\":" + String(relay2On ? "true" : "false") + ",";
  json += "\"manual_override_timeout_ms\":" + String(manualOverrideTimeoutMs) + ",";
  json += "\"automation_keepalive_ms\":" + String(automationKeepaliveMs) + ",";
  json += "\"relay_max_runtime_ms\":" + String(relayMaxRuntimeMs);
  json += "}";
  return json;
}

String buildConfigExportJson() {
  String json = "{";
  json.reserve(2000);
  json += "\"firmware_version\":\"" + jsonEscape(String(FIRMWARE_VERSION)) + "\",";
  json += "\"build_profile\":\"" + jsonEscape(String(BUILD_PROFILE)) + "\",";
  json += "\"config_version\":" + String(CONFIG_VERSION) + ",";
  json += "\"exported_at_ms\":" + String(millis()) + ",";
  json += "\"button_gpio\":" + String(PIN_BUTTON) + ",";
  json += "\"relay_1_gpio\":" + String(PIN_RELAY_1) + ",";
  json += "\"relay_2_gpio\":" + String(PIN_RELAY_2) + ",";
  json += "\"status_led_gpio\":" + String(PIN_LED) + ",";
  json += "\"feed_sensor_gpio\":" + String(PIN_FEED_SENSOR) + ",";
  json += "\"hardware_emergency_stop_gpio\":" + String(PIN_EMERGENCY_STOP) + ",";
  json += "\"hardware_emergency_stop_enabled\":" + String(pinIsConfigured(PIN_EMERGENCY_STOP) ? "true" : "false") + ",";
  json += "\"hardware_emergency_stop_active_high\":" + String(EMERGENCY_STOP_ACTIVE_HIGH ? "true" : "false") + ",";
  json += "\"ap_password_enabled\":" + String(apPasswordEnabled ? "true" : "false") + ",";
  json += "\"feed_bin1_name\":\"" + jsonEscape(feedBin1Name) + "\",";
  json += "\"feed_bin2_name\":\"" + jsonEscape(feedBin2Name) + "\",";
  json += "\"feed_logic_mode\":\"" + String(feedLogicModeName(feedLogicMode)) + "\",";
  json += "\"feed_logic_preferred_bin\":" + String(feedLogicPreferredBin) + ",";
  json += "\"feed_logic_alternate_ms\":" + String(feedLogicAlternateMs) + ",";
  json += "\"feed_logic_auto_switch_ms\":" + String(feedLogicAutoSwitchMs) + ",";
  json += "\"feed_logic_top_off_ms\":" + String(feedLogicTopOffMs) + ",";
  json += "\"no_runout_alarm_after_ms\":" + String(noRunoutAlarmDelayMs) + ",";
  json += "\"empty_too_long_alarm_after_ms\":" + String(emptyTooLongAlarmDelayMs) + ",";
  json += "\"manual_override_timeout_ms\":" + String(manualOverrideTimeoutMs) + ",";
  json += "\"relay_max_runtime_ms\":" + String(relayMaxRuntimeMs) + ",";
  json += "\"automation_keepalive_ms\":" + String(automationKeepaliveMs) + ",";
  json += "\"relay_active_high\":" + String(relayActiveHigh ? "true" : "false") + ",";
  json += "\"led_active_high\":" + String(ledActiveHigh ? "true" : "false") + ",";
  json += "\"feed_sensor_active_high\":" + String(feedPresentWhenHigh ? "true" : "false") + ",";
  json += "\"station_wifi_enabled\":" + String(stationWifiEnabled ? "true" : "false") + ",";
  json += "\"station_wifi_ssid\":\"" + jsonEscape(stationWifiSsid) + "\",";
  json += "\"station_wifi_password_saved\":" + String(stationWifiPassword.length() > 0 ? "true" : "false") + ",";
  json += "\"notification_email_enabled\":" + String(notificationEmailEnabled ? "true" : "false") + ",";
  json += "\"notification_email_to\":\"" + jsonEscape(notificationEmailTo) + "\",";
  json += "\"notification_hub_url\":\"" + jsonEscape(notificationHubUrl) + "\",";
  json += "\"cluck_magic_selected_mac\":\"" + jsonEscape(cluckMagicSelectedMac) + "\",";
  json += "\"house_planner_name\":\"" + jsonEscape(plannerHouseName) + "\",";
  json += "\"house_planner_notes\":\"" + jsonEscape(plannerNotes) + "\",";
  json += "\"house_planner_nodes_target\":" + String(plannerNodesTarget) + ",";
  json += "\"house_planner_mesh_enabled\":" + String(plannerMeshEnabled ? "true" : "false") + ",";
  json += "\"house_planner_track_bin_level\":" + String(plannerTrackBinLevel ? "true" : "false") + ",";
  json += "\"house_planner_track_bin_clog\":" + String(plannerTrackBinClog ? "true" : "false") + ",";
  json += "\"house_planner_track_vibrator\":" + String(plannerTrackVibrator ? "true" : "false") + ",";
  json += "\"house_planner_track_hopper_auger\":" + String(plannerTrackHopperAuger ? "true" : "false") + ",";
  json += "\"house_planner_track_line_auger\":" + String(plannerTrackLineAuger ? "true" : "false") + ",";
  json += "\"house_planner_track_motor_current\":" + String(plannerTrackMotorCurrent ? "true" : "false");
  json += "}";
  return json;
}

void handleConfigExport() {
  sendNoStoreHeaders();
  server.sendHeader("Content-Disposition", "attachment; filename=\"fbb-config.json\"");
  server.send(200, "application/json", buildConfigExportJson());
}

void handleConfigImport() {
  if (!requireMaintenanceSession("configuration restore")) {
    return;
  }

  String body = server.hasArg("plain") ? server.arg("plain") : String();
  const bool useJsonBody = body.length() > 0;
  if (useJsonBody) {
    body.trim();
    if (body.length() == 0 || body[0] != '{') {
      server.send(400, "application/json",
                  "{\"error\":\"Config restore body must be JSON or query args\"}");
      return;
    }
  }

  String newFeedBin1Name = feedBin1Name;
  String newFeedBin2Name = feedBin2Name;
  FeedLogicMode newFeedLogicMode = feedLogicMode;
  uint8_t newFeedLogicPreferredBin = feedLogicPreferredBin;
  unsigned long newFeedLogicAlternateMs = feedLogicAlternateMs;
  unsigned long newFeedLogicAutoSwitchMs = feedLogicAutoSwitchMs;
  unsigned long newFeedLogicTopOffMs = feedLogicTopOffMs;
  String newPlannerHouseName = plannerHouseName;
  String newPlannerNotes = plannerNotes;
  uint16_t newPlannerNodesTarget = plannerNodesTarget;
  bool newPlannerMeshEnabled = plannerMeshEnabled;
  bool newPlannerTrackBinLevel = plannerTrackBinLevel;
  bool newPlannerTrackBinClog = plannerTrackBinClog;
  bool newPlannerTrackVibrator = plannerTrackVibrator;
  bool newPlannerTrackHopperAuger = plannerTrackHopperAuger;
  bool newPlannerTrackLineAuger = plannerTrackLineAuger;
  bool newPlannerTrackMotorCurrent = plannerTrackMotorCurrent;
  unsigned long newNoRunoutAlarmDelayMs = noRunoutAlarmDelayMs;
  unsigned long newEmptyTooLongAlarmDelayMs = emptyTooLongAlarmDelayMs;
  unsigned long newManualOverrideTimeoutMs = manualOverrideTimeoutMs;
  unsigned long newRelayMaxRuntimeMs = relayMaxRuntimeMs;
  unsigned long newAutomationKeepaliveMs = automationKeepaliveMs;
  bool newApPasswordEnabled = apPasswordEnabled;
  bool newRelayActiveHigh = relayActiveHigh;
  bool newLedActiveHigh = ledActiveHigh;
  bool newFeedPresentWhenHigh = feedPresentWhenHigh;
  bool newStationWifiEnabled = stationWifiEnabled;
  String newStationWifiSsid = stationWifiSsid;
  String newStationWifiPassword = stationWifiPassword;
  bool newNotificationEmailEnabled = notificationEmailEnabled;
  String newNotificationEmailTo = notificationEmailTo;
  String newNotificationHubUrl = notificationHubUrl;
  String newCluckMagicSelectedMac = cluckMagicSelectedMac;
  unsigned long preferredBinValue = newFeedLogicPreferredBin;
  unsigned long plannerNodesValue = newPlannerNodesTarget;

  size_t restoredFields = 0;
  String warning;

  auto readStringField = [&](const char *key, String &target) -> JsonFieldResult {
    if (useJsonBody) {
      return extractJsonStringField(body, key, target);
    }
    if (!server.hasArg(key)) {
      return JsonFieldResult::Missing;
    }
    target = server.arg(key);
    return JsonFieldResult::Parsed;
  };

  auto readBoolField = [&](const char *key, bool &target) -> JsonFieldResult {
    if (useJsonBody) {
      return extractJsonBoolField(body, key, target);
    }
    if (!server.hasArg(key)) {
      return JsonFieldResult::Missing;
    }
    if (!parseBoolLike(server.arg(key), target)) {
      return JsonFieldResult::Invalid;
    }
    return JsonFieldResult::Parsed;
  };

  auto readUnsignedField = [&](const char *key, unsigned long &target) -> JsonFieldResult {
    if (useJsonBody) {
      return extractJsonUnsignedField(body, key, target);
    }
    if (!server.hasArg(key)) {
      return JsonFieldResult::Missing;
    }
    if (!parseUnsignedValue(server.arg(key), target)) {
      return JsonFieldResult::Invalid;
    }
    return JsonFieldResult::Parsed;
  };

  unsigned long importedVersion = CONFIG_VERSION;
  const JsonFieldResult versionResult = readUnsignedField("config_version", importedVersion);
  if (versionResult == JsonFieldResult::Invalid) {
    server.send(400, "application/json", "{\"error\":\"config_version must be an integer\"}");
    return;
  }
  if (versionResult == JsonFieldResult::Parsed && importedVersion != CONFIG_VERSION) {
    server.send(409, "application/json",
                "{\"error\":\"Config snapshot version does not match this firmware\"}");
    return;
  }

  auto applyStringField = [&](const char *key, String &target) -> bool {
    String value = target;
    const JsonFieldResult result = readStringField(key, value);
    if (result == JsonFieldResult::Invalid) {
      server.send(400, "application/json",
                  String("{\"error\":\"") + key + " must be a JSON string\"}");
      return false;
    }
    if (result == JsonFieldResult::Parsed) {
      target = value;
      ++restoredFields;
    }
    return true;
  };

  auto applyBoolField = [&](const char *key, bool &target) -> bool {
    bool value = target;
    const JsonFieldResult result = readBoolField(key, value);
    if (result == JsonFieldResult::Invalid) {
      server.send(400, "application/json",
                  String("{\"error\":\"") + key + " must be true/false or 1/0\"}");
      return false;
    }
    if (result == JsonFieldResult::Parsed) {
      target = value;
      ++restoredFields;
    }
    return true;
  };

  auto applyUnsignedField = [&](const char *key, unsigned long &target) -> bool {
    unsigned long value = target;
    const JsonFieldResult result = readUnsignedField(key, value);
    if (result == JsonFieldResult::Invalid) {
      server.send(400, "application/json",
                  String("{\"error\":\"") + key + " must be a non-negative integer\"}");
      return false;
    }
    if (result == JsonFieldResult::Parsed) {
      target = value;
      ++restoredFields;
    }
    return true;
  };

  if (!applyStringField("feed_bin1_name", newFeedBin1Name)) return;
  if (!applyStringField("feed_bin2_name", newFeedBin2Name)) return;

  String modeValue = feedLogicModeName(newFeedLogicMode);
  const JsonFieldResult modeResult = readStringField("feed_logic_mode", modeValue);
  if (modeResult == JsonFieldResult::Invalid) {
    server.send(400, "application/json", "{\"error\":\"feed_logic_mode must be a JSON string\"}");
    return;
  }
  if (modeResult == JsonFieldResult::Parsed) {
    FeedLogicMode parsedMode = newFeedLogicMode;
    if (!parseFeedLogicMode(modeValue, parsedMode)) {
      server.send(400, "application/json",
                  "{\"error\":\"feed_logic_mode must be manual, sensor_demand, auto_switch, alternate_cycle, or timed_alternate\"}");
      return;
    }
    newFeedLogicMode = parsedMode;
    ++restoredFields;
  }

  if (!applyUnsignedField("feed_logic_preferred_bin", preferredBinValue)) {
    return;
  }
  if (preferredBinValue != 1 && preferredBinValue != 2) {
    server.send(400, "application/json", "{\"error\":\"feed_logic_preferred_bin must be 1 or 2\"}");
    return;
  }
  newFeedLogicPreferredBin = static_cast<uint8_t>(preferredBinValue);

  if (!applyUnsignedField("feed_logic_alternate_ms", newFeedLogicAlternateMs)) return;
  if (!applyUnsignedField("feed_logic_auto_switch_ms", newFeedLogicAutoSwitchMs)) return;
  if (!applyUnsignedField("feed_logic_top_off_ms", newFeedLogicTopOffMs)) return;
  if (!applyStringField("house_planner_name", newPlannerHouseName)) return;
  if (!applyStringField("house_planner_notes", newPlannerNotes)) return;
  if (!applyUnsignedField("house_planner_nodes_target", plannerNodesValue)) {
    return;
  }
  newPlannerNodesTarget = static_cast<uint16_t>(plannerNodesValue);
  if (!applyBoolField("house_planner_mesh_enabled", newPlannerMeshEnabled)) return;
  if (!applyBoolField("house_planner_track_bin_level", newPlannerTrackBinLevel)) return;
  if (!applyBoolField("house_planner_track_bin_clog", newPlannerTrackBinClog)) return;
  if (!applyBoolField("house_planner_track_vibrator", newPlannerTrackVibrator)) return;
  if (!applyBoolField("house_planner_track_hopper_auger", newPlannerTrackHopperAuger)) return;
  if (!applyBoolField("house_planner_track_line_auger", newPlannerTrackLineAuger)) return;
  if (!applyBoolField("house_planner_track_motor_current", newPlannerTrackMotorCurrent)) return;
  if (!applyUnsignedField("no_runout_alarm_after_ms", newNoRunoutAlarmDelayMs)) return;
  if (!applyUnsignedField("empty_too_long_alarm_after_ms", newEmptyTooLongAlarmDelayMs)) return;
  if (!applyUnsignedField("manual_override_timeout_ms", newManualOverrideTimeoutMs)) return;
  if (!applyUnsignedField("relay_max_runtime_ms", newRelayMaxRuntimeMs)) return;
  if (!applyUnsignedField("automation_keepalive_ms", newAutomationKeepaliveMs)) return;
  if (!applyBoolField("ap_password_enabled", newApPasswordEnabled)) return;
  if (!applyBoolField("relay_active_high", newRelayActiveHigh)) return;
  if (!applyBoolField("led_active_high", newLedActiveHigh)) return;
  if (!applyBoolField("feed_sensor_active_high", newFeedPresentWhenHigh)) return;
  if (!applyBoolField("station_wifi_enabled", newStationWifiEnabled)) return;
  if (!applyStringField("station_wifi_ssid", newStationWifiSsid)) return;
  if (!applyStringField("station_wifi_password", newStationWifiPassword)) return;
  if (!applyBoolField("notification_email_enabled", newNotificationEmailEnabled)) return;
  if (!applyStringField("notification_email_to", newNotificationEmailTo)) return;
  if (!applyStringField("notification_hub_url", newNotificationHubUrl)) return;
  if (!applyStringField("cluck_magic_selected_mac", newCluckMagicSelectedMac)) return;

  newStationWifiSsid = normalizedOptionalLimited(newStationWifiSsid, MAX_WIFI_SSID_LENGTH);
  newStationWifiPassword = normalizedOptionalLimited(newStationWifiPassword, MAX_WIFI_PASSWORD_LENGTH);
  newNotificationEmailTo = normalizedOptionalLimited(newNotificationEmailTo, MAX_NOTIFICATION_EMAIL_LENGTH);
  newNotificationHubUrl = normalizedOptionalLimited(newNotificationHubUrl, MAX_NOTIFICATION_URL_LENGTH);
  newCluckMagicSelectedMac = normalizedMacString(newCluckMagicSelectedMac);

  if (newStationWifiEnabled && newStationWifiSsid.length() == 0) {
    server.send(400, "application/json",
                "{\"error\":\"station_wifi_ssid is required when station_wifi_enabled is true\"}");
    return;
  }

  if (newNotificationEmailEnabled &&
      (newNotificationEmailTo.length() == 0 || newNotificationHubUrl.length() == 0)) {
    server.send(400, "application/json",
                "{\"error\":\"notification_email_to and notification_hub_url are required when notification_email_enabled is true\"}");
    return;
  }

  bool importedHardStopActiveHigh = EMERGENCY_STOP_ACTIVE_HIGH;
  const JsonFieldResult hardStopResult = readBoolField("hardware_emergency_stop_active_high", importedHardStopActiveHigh);
  if (hardStopResult == JsonFieldResult::Invalid) {
    server.send(400, "application/json",
                "{\"error\":\"hardware_emergency_stop_active_high must be true/false or 1/0\"}");
    return;
  }
  if (hardStopResult == JsonFieldResult::Parsed && importedHardStopActiveHigh != EMERGENCY_STOP_ACTIVE_HIGH) {
    warning = "hardware_emergency_stop_active_high is compile-time only on this firmware";
  }

  if (restoredFields == 0) {
    server.send(400, "application/json",
                "{\"error\":\"No restorable config fields were provided\"}");
    return;
  }

  const bool hardwareChanged =
      newRelayActiveHigh != relayActiveHigh ||
      newLedActiveHigh != ledActiveHigh ||
      newFeedPresentWhenHigh != feedPresentWhenHigh;
  const bool stationWifiChanged =
      newStationWifiEnabled != stationWifiEnabled ||
      newStationWifiSsid != stationWifiSsid ||
      newStationWifiPassword != stationWifiPassword;
  const bool apAccessChanged = newApPasswordEnabled != apPasswordEnabled;

  feedBin1Name = newFeedBin1Name;
  feedBin2Name = newFeedBin2Name;
  feedLogicMode = newFeedLogicMode;
  feedLogicPreferredBin = newFeedLogicPreferredBin;
  feedLogicAlternateMs = newFeedLogicAlternateMs;
  feedLogicAutoSwitchMs = newFeedLogicAutoSwitchMs;
  feedLogicTopOffMs = newFeedLogicTopOffMs;
  plannerHouseName = newPlannerHouseName;
  plannerNotes = newPlannerNotes;
  plannerNodesTarget = newPlannerNodesTarget;
  plannerMeshEnabled = newPlannerMeshEnabled;
  plannerTrackBinLevel = newPlannerTrackBinLevel;
  plannerTrackBinClog = newPlannerTrackBinClog;
  plannerTrackVibrator = newPlannerTrackVibrator;
  plannerTrackHopperAuger = newPlannerTrackHopperAuger;
  plannerTrackLineAuger = newPlannerTrackLineAuger;
  plannerTrackMotorCurrent = newPlannerTrackMotorCurrent;
  noRunoutAlarmDelayMs = newNoRunoutAlarmDelayMs;
  emptyTooLongAlarmDelayMs = newEmptyTooLongAlarmDelayMs;
  manualOverrideTimeoutMs = newManualOverrideTimeoutMs;
  relayMaxRuntimeMs = newRelayMaxRuntimeMs;
  automationKeepaliveMs = newAutomationKeepaliveMs;
  apPasswordEnabled = newApPasswordEnabled;
  relayActiveHigh = newRelayActiveHigh;
  ledActiveHigh = newLedActiveHigh;
  feedPresentWhenHigh = newFeedPresentWhenHigh;
  stationWifiEnabled = newStationWifiEnabled;
  stationWifiSsid = newStationWifiSsid;
  stationWifiPassword = newStationWifiPassword;
  notificationEmailEnabled = newNotificationEmailEnabled;
  notificationEmailTo = newNotificationEmailTo;
  notificationHubUrl = newNotificationHubUrl;
  cluckMagicSelectedMac = newCluckMagicSelectedMac;
  configLoaded = true;

  const bool sanitized = sanitizePersistentConfig();

  stopFeedLogicCycle();
  forceAllRelaysOff("config restore");
  ledOn = false;
  applyOutputs();
  initializeFeedSensorState();
  updateEmergencyStopState();
  if (hardwareChanged) {
    feedLogicMode = FeedLogicMode::Manual;
    logEvent("Hardware profile restored; feeder logic forced to manual.");
  }
  if (stationWifiChanged) {
    if (stationWifiConfigured()) {
      beginStationWifi("config restore");
    } else {
      WiFi.disconnect(false, false);
      if (apRunning) {
        WiFi.mode(WIFI_AP);
      }
    }
  }
  updateAlarmStateAndLed();

  if (sanitized) {
    logEvent("Restored configuration sanitized to safe ranges.");
  }
  if (warning.length() > 0) {
    logEvent(String("Config restore warning: ") + warning);
  }

  markConfigDirty();
  const bool saveOk = savePersistentConfig();
  if (saveOk) {
    logEvent(String("Configuration restored from snapshot. Fields applied: ") + String(restoredFields));
    if (apAccessChanged) {
      requestControllerReboot("config restore AP access update");
    }
  } else {
    logEvent(String("Configuration restored from snapshot but persistence failed: ") + configSaveFaultReason);
  }

  String response = "{\"status\":\"";
  response += saveOk ? "ok" : "ok_pending_save";
  response += "\",\"fields_applied\":";
  response += String(restoredFields);
  response += ",\"hardware_changed\":";
  response += String(hardwareChanged ? "true" : "false");
  response += ",\"ap_access_changed\":";
  response += String(apAccessChanged ? "true" : "false");
  response += ",\"reboot_pending\":";
  response += String(rebootPending ? "true" : "false");
  response += ",\"config_saved\":";
  response += String(saveOk ? "true" : "false");
  response += ",\"config_save_fault\":";
  response += String(configSaveFault ? "true" : "false");
  response += ",\"config_save_fault_reason\":\"";
  response += jsonEscape(configSaveFaultReason);
  response += "\"";
  if (warning.length() > 0) {
    response += ",\"warning\":\"";
    response += jsonEscape(warning);
    response += "\"";
  }
  response += "}";
  server.send(saveOk ? 200 : 503, "application/json", response);
}

void setRelay(const uint8_t relay, const bool on) {
  if (!relayChannelIsValid(relay)) {
    logEvent(String("Ignored invalid relay command for channel ") + String(relay));
    return;
  }
  setRelayChannel(relay, on, RelayOwner::Manual, manualOverrideTimeoutMs, "manual");
}

void toggleRelay(const uint8_t relay) {
  if (relay == 1) {
    setRelayChannel(1, !relay1On, RelayOwner::Manual, manualOverrideTimeoutMs, "manual");
  } else if (relay == 2) {
    setRelayChannel(2, !relay2On, RelayOwner::Manual, manualOverrideTimeoutMs, "manual");
  } else {
    logEvent(String("Ignored invalid relay toggle for channel ") + String(relay));
  }
}

void engageEmergencyStop(const char *reason) {
  if (emergencyStopLatched) {
    forceAllRelaysOff(reason != nullptr ? reason : "emergency stop", false);
    return;
  }

  emergencyStopLatched = true;
  stopFeedLogicCycle();
  forceAllRelaysOff(reason != nullptr ? reason : "emergency stop", false);
  if (reason != nullptr && reason[0] != '\0') {
    logEvent(String("Emergency stop latched: ") + reason);
  } else {
    logEvent("Emergency stop latched.");
  }
}

bool resetEmergencyStop() {
  if (hardwareEmergencyStopInputActive()) {
    logEvent("Emergency stop reset rejected: hardware input active.");
    return false;
  }

  emergencyStopLatched = false;
  hardwareEmergencyStopActive = false;
  logEvent("Emergency stop cleared.");
  return true;
}

void handleRelayCommand(const uint8_t relay, const char *action) {
  if (!relayChannelIsValid(relay)) {
    server.send(400, "application/json", "{\"error\":\"Invalid relay channel\"}");
    return;
  }

  if (strcmp(action, "off") != 0 && guiFeedControlLocked()) {
    server.send(423, "application/json", "{\"error\":\"Emergency stop active\"}");
    return;
  }

  if (strcmp(action, "off") != 0 && !requireMaintenanceSession("feed bin control")) {
    return;
  }

  if (strcmp(action, "on") == 0) {
    setRelay(relay, true);
    sendStatusJson();
    return;
  }

  if (strcmp(action, "off") == 0) {
    setRelay(relay, false);
    sendStatusJson();
    return;
  }

  if (strcmp(action, "toggle") == 0) {
    toggleRelay(relay);
    sendStatusJson();
    return;
  }

  server.send(400, "application/json", "{\"error\":\"Invalid action\"}");
}

void registerRelayActionRoutes(const char *basePath, const uint8_t relay) {
  const char *const actions[] = {"on", "off", "toggle"};
  for (const char *action : actions) {
    String route = "/api/";
    route += basePath;
    route += "/";
    route += String(relay);
    route += "/";
    route += action;
    server.on(route.c_str(), HTTP_POST, [relay, action]() { handleRelayCommand(relay, action); });
  }
}

void registerRelayFamilyRoutes(const char *basePath) {
  const uint8_t relays[] = {1, 2};
  for (const uint8_t relay : relays) {
    registerRelayActionRoutes(basePath, relay);
  }
}

bool parseUnsignedValue(const String &value, unsigned long &outValue) {
  String trimmed = value;
  trimmed.trim();

  if (trimmed.length() == 0) {
    return false;
  }

  return parseUnsignedDigits(trimmed.c_str(), trimmed.length(), outValue);
}

bool parseUnsignedDigits(const char *text, const size_t length, unsigned long &outValue) {
  if (text == nullptr || length == 0) {
    return false;
  }

  const uint64_t limit = static_cast<uint64_t>(ULONG_MAX);
  uint64_t parsed = 0;

  for (size_t i = 0; i < length; ++i) {
    const unsigned char c = static_cast<unsigned char>(text[i]);
    if (c < '0' || c > '9') {
      return false;
    }

    parsed = parsed * 10ULL + static_cast<uint64_t>(c - '0');
    if (parsed > limit) {
      return false;
    }
  }

  outValue = static_cast<unsigned long>(parsed);
  return true;
}

void handleAlarmClear() {
  if (!requireMaintenanceSession("feed alarm clear")) {
    return;
  }

  clearFeedAlarm("operator clear");
  sendStatusJson();
}

void handleAlarmConfigUpdate() {
  if (!requireMaintenanceSession("alarm configuration update")) {
    return;
  }

  if (!server.hasArg("no_runout_min") || !server.hasArg("empty_too_long_min")) {
    server.send(400, "application/json",
                "{\"error\":\"Required args: no_runout_min, empty_too_long_min\"}");
    return;
  }

  unsigned long noRunoutMin = 0;
  unsigned long emptyTooLongMin = 0;
  if (!parseUnsignedValue(server.arg("no_runout_min"), noRunoutMin) ||
      !parseUnsignedValue(server.arg("empty_too_long_min"), emptyTooLongMin)) {
    server.send(400, "application/json", "{\"error\":\"Alarm values must be positive integers\"}");
    return;
  }

  noRunoutAlarmDelayMs = minutesToMsClamped(noRunoutMin);
  emptyTooLongAlarmDelayMs = minutesToMsClamped(emptyTooLongMin);
  updateAlarmStateAndLed();
  logEvent(String("Alarm timers updated: no_runout=") + String(noRunoutAlarmDelayMs / 60000UL) +
           "min empty=" + String(emptyTooLongAlarmDelayMs / 60000UL) + "min");
  markConfigDirty();
  if (!savePersistentConfig()) {
    sendConfigSaveFailureResponse("alarm configuration update");
    return;
  }
  sendStatusJson();
}

void handleFeedLogicConfigUpdate() {
  if (!requireMaintenanceSession("feed logic configuration update")) {
    return;
  }

  bool changed = false;

  if (server.hasArg("bin1_name")) {
    feedBin1Name = normalizedFeedBinName(server.arg("bin1_name"), "Feed Bin 1");
    changed = true;
  }
  if (server.hasArg("bin2_name")) {
    feedBin2Name = normalizedFeedBinName(server.arg("bin2_name"), "Feed Bin 2");
    changed = true;
  }

  if (server.hasArg("mode")) {
    FeedLogicMode parsedMode = feedLogicMode;
    if (!parseFeedLogicMode(server.arg("mode"), parsedMode)) {
      server.send(400, "application/json",
                  "{\"error\":\"Invalid mode. Use manual, sensor_demand, auto_switch, alternate_cycle, timed_alternate\"}");
      return;
    }
    feedLogicMode = parsedMode;
    stopFeedLogicCycle();
    forceAllRelaysOff("feed logic mode update");
    feedLogicLastAlternateMs = millis();
    logEvent(String("Feed logic mode -> ") + feedLogicModeName(feedLogicMode));
    changed = true;
  }

  if (server.hasArg("alternate_min")) {
    unsigned long alternateMin = 0;
    if (!parseUnsignedValue(server.arg("alternate_min"), alternateMin)) {
      server.send(400, "application/json", "{\"error\":\"alternate_min must be a positive integer\"}");
      return;
    }
    feedLogicAlternateMs =
        scaleToMsClamped(alternateMin, 60000ULL, MIN_LOGIC_ALTERNATE_MS, MAX_LOGIC_ALTERNATE_MS);
    changed = true;
  }

  if (server.hasArg("auto_switch_sec")) {
    unsigned long autoSwitchSec = 0;
    if (!parseUnsignedValue(server.arg("auto_switch_sec"), autoSwitchSec)) {
      server.send(400, "application/json", "{\"error\":\"auto_switch_sec must be a positive integer\"}");
      return;
    }
    feedLogicAutoSwitchMs =
        scaleToMsClamped(autoSwitchSec, 1000ULL, MIN_LOGIC_AUTO_SWITCH_MS, MAX_LOGIC_AUTO_SWITCH_MS);
    changed = true;
  }

  if (server.hasArg("top_off_sec")) {
    unsigned long topOffSec = 0;
    if (!parseUnsignedValue(server.arg("top_off_sec"), topOffSec)) {
      server.send(400, "application/json", "{\"error\":\"top_off_sec must be a non-negative integer\"}");
      return;
    }
    feedLogicTopOffMs =
        scaleToMsClamped(topOffSec, 1000ULL, MIN_LOGIC_TOP_OFF_MS, MAX_LOGIC_TOP_OFF_MS);
    changed = true;
  }

  if (server.hasArg("preferred_bin")) {
    unsigned long preferred = 0;
    if (!parseUnsignedValue(server.arg("preferred_bin"), preferred) || (preferred != 1 && preferred != 2)) {
      server.send(400, "application/json", "{\"error\":\"preferred_bin must be 1 or 2\"}");
      return;
    }
    feedLogicPreferredBin = static_cast<uint8_t>(preferred);
    changed = true;
  }

  if (!changed) {
    server.send(400, "application/json",
                "{\"error\":\"Provide one or more: bin1_name, bin2_name, mode, alternate_min, auto_switch_sec, top_off_sec, preferred_bin\"}");
    return;
  }

  markConfigDirty();
  if (!savePersistentConfig()) {
    sendConfigSaveFailureResponse("feed logic configuration update");
    return;
  }
  sendStatusJson();
}

void handleHousePlannerConfigUpdate() {
  if (!requireMaintenanceSession("house planner configuration update")) {
    return;
  }

  bool changed = false;

  if (server.hasArg("house_name")) {
    plannerHouseName = normalizedLimited(server.arg("house_name"), "House 1", 32);
    changed = true;
  }

  if (server.hasArg("notes")) {
    plannerNotes = normalizedLimited(server.arg("notes"), "", 240);
    changed = true;
  }

  if (server.hasArg("nodes_target")) {
    unsigned long nodes = 0;
    if (!parseUnsignedValue(server.arg("nodes_target"), nodes)) {
      server.send(400, "application/json", "{\"error\":\"nodes_target must be a positive integer\"}");
      return;
    }
    plannerNodesTarget =
        static_cast<uint16_t>(clampRange(nodes, MIN_HOUSE_PLANNER_NODES, MAX_HOUSE_PLANNER_NODES));
    changed = true;
  }

  auto updatePlannerFlag = [&](const char *key, bool &target) -> bool {
    if (!server.hasArg(key)) {
      return true;
    }
    bool parsed = false;
    if (!parseBoolLike(server.arg(key), parsed)) {
      String err = "{\"error\":\"Invalid boolean for ";
      err += key;
      err += "\"}";
      server.send(400, "application/json", err);
      return false;
    }
    target = parsed;
    changed = true;
    return true;
  };

  if (!updatePlannerFlag("mesh_enabled", plannerMeshEnabled)) return;
  if (!updatePlannerFlag("track_bin_level", plannerTrackBinLevel)) return;
  if (!updatePlannerFlag("track_bin_clog", plannerTrackBinClog)) return;
  if (!updatePlannerFlag("track_vibrator", plannerTrackVibrator)) return;
  if (!updatePlannerFlag("track_hopper_auger", plannerTrackHopperAuger)) return;
  if (!updatePlannerFlag("track_line_auger", plannerTrackLineAuger)) return;
  if (!updatePlannerFlag("track_motor_current", plannerTrackMotorCurrent)) return;

  if (!changed) {
    server.send(400, "application/json",
                "{\"error\":\"Provide one or more planner fields\"}");
    return;
  }

  logEvent("House planner configuration updated.");
  markConfigDirty();
  if (!savePersistentConfig()) {
    sendConfigSaveFailureResponse("house planner configuration update");
    return;
  }
  sendStatusJson();
}

void handleLeaseHeartbeat() {
  const unsigned long now = millis();
  for (uint8_t relay = 1; relay <= 2; ++relay) {
    const uint8_t idx = relay - 1;
    if (((idx == 0) ? relay1On : relay2On) &&
        static_cast<RelayOwner>(relayLeaseOwner[idx]) == RelayOwner::Manual) {
      relayLeaseUntilMs[idx] = now + manualOverrideTimeoutMs;
      manualControlOverrideUntilMs = now + manualOverrideTimeoutMs;
    }
  }
  sendStatusJson();
}

void handleFaultReset() {
  if (!requireMaintenanceSession("fault reset")) {
    return;
  }

  clearFault();
  sendStatusJson();
}

void handleReboot() {
  if (rebootPending) {
    sendStatusJson();
    return;
  }

  if (!requireMaintenanceSession("maintenance reboot")) {
    return;
  }

  requestControllerReboot("maintenance reboot");
  sendStatusJson();
}

void handleLogs() {
  size_t limit = 16;
  if (server.hasArg("limit")) {
    unsigned long value = 0;
    if (parseUnsignedValue(server.arg("limit"), value)) {
      limit = static_cast<size_t>(clampRange(value, 1UL, 32UL));
    }
  }
  sendNoStoreHeaders();
  String json = "{\"entries\":";
  json += buildLogJson(limit);
  json += "}";
  server.send(200, "application/json", json);
}

void handleHealth() {
  const unsigned long now = millis();
  const HealthSnapshot health = buildHealthSnapshot(now);
  sendNoStoreHeaders();
  server.send(health.ok ? 200 : 503, "application/json", buildHealthJson(health, now));
}

void handleSafetyConfigUpdate() {
  if (!requireMaintenanceSession("safety configuration update")) {
    return;
  }

  bool changed = false;

  if (server.hasArg("manual_timeout_sec")) {
    unsigned long value = 0;
    if (!parseUnsignedValue(server.arg("manual_timeout_sec"), value)) {
      server.send(400, "application/json", "{\"error\":\"manual_timeout_sec must be a positive integer\"}");
      return;
    }
    manualOverrideTimeoutMs =
        scaleToMsClamped(value, 1000ULL, 10UL * 1000UL, 30UL * 60UL * 1000UL);
    changed = true;
  }

  if (server.hasArg("relay_max_min")) {
    unsigned long value = 0;
    if (!parseUnsignedValue(server.arg("relay_max_min"), value)) {
      server.send(400, "application/json", "{\"error\":\"relay_max_min must be a positive integer\"}");
      return;
    }
    relayMaxRuntimeMs =
        scaleToMsClamped(value, 60000ULL, 1UL * 60UL * 1000UL, 60UL * 60UL * 1000UL);
    changed = true;
  }

  if (server.hasArg("automation_keepalive_sec")) {
    unsigned long value = 0;
    if (!parseUnsignedValue(server.arg("automation_keepalive_sec"), value)) {
      server.send(400, "application/json",
                  "{\"error\":\"automation_keepalive_sec must be a positive integer\"}");
      return;
    }
    automationKeepaliveMs =
        scaleToMsClamped(value, 1000ULL, 5UL * 1000UL, 5UL * 60UL * 1000UL);
    changed = true;
  }

  if (!changed) {
    server.send(400, "application/json",
                "{\"error\":\"Provide one or more: manual_timeout_sec, relay_max_min, automation_keepalive_sec\"}");
    return;
  }

  logEvent(String("Safety config updated: manual=") + String(manualOverrideTimeoutMs / 1000UL) +
           "s relay_max=" + String(relayMaxRuntimeMs / 60000UL) +
           "min auto_keep=" + String(automationKeepaliveMs / 1000UL) + "s");
  markConfigDirty();
  if (!savePersistentConfig()) {
    sendConfigSaveFailureResponse("safety configuration update");
    return;
  }
  sendStatusJson();
}

void handleHardwareConfigUpdate() {
  if (!requireMaintenanceSession("hardware configuration update")) {
    return;
  }

  bool changed = false;
  bool newRelayActiveHigh = relayActiveHigh;
  bool newLedActiveHigh = ledActiveHigh;
  bool newFeedPresentWhenHigh = feedPresentWhenHigh;

  if (server.hasArg("relay_active_high")) {
    if (!parseBoolLike(server.arg("relay_active_high"), newRelayActiveHigh)) {
      server.send(400, "application/json",
                  "{\"error\":\"relay_active_high must be true/false, on/off, yes/no, or 1/0\"}");
      return;
    }
    changed = true;
  }

  if (server.hasArg("led_active_high")) {
    if (!parseBoolLike(server.arg("led_active_high"), newLedActiveHigh)) {
      server.send(400, "application/json",
                  "{\"error\":\"led_active_high must be true/false, on/off, yes/no, or 1/0\"}");
      return;
    }
    changed = true;
  }

  if (server.hasArg("feed_sensor_active_high")) {
    if (!parseBoolLike(server.arg("feed_sensor_active_high"), newFeedPresentWhenHigh)) {
      server.send(400, "application/json",
                  "{\"error\":\"feed_sensor_active_high must be true/false, on/off, yes/no, or 1/0\"}");
      return;
    }
    changed = true;
  }

  if (!changed) {
    server.send(400, "application/json",
                "{\"error\":\"Provide one or more: relay_active_high, led_active_high, feed_sensor_active_high\"}");
    return;
  }

  relayActiveHigh = newRelayActiveHigh;
  ledActiveHigh = newLedActiveHigh;
  feedPresentWhenHigh = newFeedPresentWhenHigh;
  const bool feedLogicWasManual = feedLogicMode == FeedLogicMode::Manual;
  feedLogicMode = FeedLogicMode::Manual;
  stopFeedLogicCycle();
  forceAllRelaysOff("hardware config update");
  ledOn = false;
  applyOutputs();
  initializeFeedSensorState();
  updateEmergencyStopState();
  updateAlarmStateAndLed();
  if (!feedLogicWasManual) {
    logEvent("Feed logic forced to manual after hardware profile update.");
  }
  logEvent(String("Hardware polarity updated: relay=") + (relayActiveHigh ? "high" : "low") +
           " sensor=" + (feedPresentWhenHigh ? "high" : "low") +
           " led=" + (ledActiveHigh ? "high" : "low") +
           " logic=manual");
  markConfigDirty();
  if (!savePersistentConfig()) {
    sendConfigSaveFailureResponse("hardware configuration update");
    return;
  }
  sendStatusJson();
}

void handleWifiConfigUpdate() {
  if (!requireMaintenanceSession("network Wi-Fi configuration update")) {
    return;
  }

  bool changed = false;
  bool newEnabled = stationWifiEnabled;
  String newSsid = stationWifiSsid;
  String newPassword = stationWifiPassword;

  if (server.hasArg("station_enabled")) {
    if (!parseBoolLike(server.arg("station_enabled"), newEnabled)) {
      server.send(400, "application/json",
                  "{\"error\":\"station_enabled must be true/false, on/off, yes/no, or 1/0\"}");
      return;
    }
    changed = true;
  }

  if (server.hasArg("ssid")) {
    newSsid = normalizedOptionalLimited(server.arg("ssid"), MAX_WIFI_SSID_LENGTH);
    changed = true;
  }

  if (server.hasArg("password")) {
    newPassword = normalizedOptionalLimited(server.arg("password"), MAX_WIFI_PASSWORD_LENGTH);
    changed = true;
  }

  bool clearPassword = false;
  if (server.hasArg("clear_password")) {
    if (!parseBoolLike(server.arg("clear_password"), clearPassword)) {
      server.send(400, "application/json",
                  "{\"error\":\"clear_password must be true/false, on/off, yes/no, or 1/0\"}");
      return;
    }
    if (clearPassword) {
      newPassword = "";
      changed = true;
    }
  }

  if (!changed) {
    server.send(400, "application/json",
                "{\"error\":\"Provide one or more: station_enabled, ssid, password, clear_password\"}");
    return;
  }

  if (newEnabled && newSsid.length() == 0) {
    server.send(400, "application/json", "{\"error\":\"SSID is required when station Wi-Fi is enabled\"}");
    return;
  }

  stationWifiEnabled = newEnabled;
  stationWifiSsid = newSsid;
  stationWifiPassword = newPassword;
  stationWifiConnecting = false;
  stationWifiEverConnected = false;
  stationWifiConnectedAtMs = 0;
  stationWifiLastStatus = WiFi.status();

  logEvent(String("Station Wi-Fi settings updated: ") +
           (stationWifiEnabled ? stationWifiSsid : String("disabled")));
  markConfigDirty();
  if (!savePersistentConfig()) {
    sendConfigSaveFailureResponse("network Wi-Fi configuration update");
    return;
  }

  if (stationWifiConfigured()) {
    beginStationWifi("settings update");
  } else {
    WiFi.disconnect(false, false);
    if (apRunning) {
      WiFi.mode(WIFI_AP);
    }
  }

  sendStatusJson();
}

void handleCluckMagicConfigUpdate() {
  if (!requireMaintenanceSession("Cluck-o-Magic module selection")) {
    return;
  }

  if (!server.hasArg("selected_mac")) {
    server.send(400, "application/json", "{\"error\":\"selected_mac is required\"}");
    return;
  }

  String selected = server.arg("selected_mac");
  selected.trim();
  if (selected.length() > 0) {
    selected = normalizedMacString(selected);
    if (selected.length() == 0) {
      server.send(400, "application/json", "{\"error\":\"selected_mac must be a MAC address\"}");
      return;
    }
  }

  cluckMagicSelectedMac = selected;
  logEvent(cluckMagicSelectedMac.length() > 0
               ? String("Cluck-o-Magic selected: ") + cluckMagicSelectedMac
               : String("Cluck-o-Magic selection cleared."));
  markConfigDirty();
  if (!savePersistentConfig()) {
    sendConfigSaveFailureResponse("Cluck-o-Magic module selection");
    return;
  }
  sendStatusJson();
}

void handleCluckMagicCommand(const uint8_t relay, const char *action) {
  if (CLUCK_MAGIC_ROLE) {
    server.send(409, "application/json",
                "{\"error\":\"This firmware is running as Cluck-o-Magic; use Bin Commander to command it.\"}");
    return;
  }
  if (relay != ESPNOW_RELAY_1 && relay != ESPNOW_RELAY_2 && relay != ESPNOW_RELAY_BOTH) {
    server.send(400, "application/json", "{\"error\":\"Invalid Cluck-o-Magic relay\"}");
    return;
  }

  uint8_t espAction = ESPNOW_ACTION_OFF;
  if (strcmp(action, "on") == 0) {
    espAction = ESPNOW_ACTION_ON;
  } else if (strcmp(action, "off") == 0) {
    espAction = ESPNOW_ACTION_OFF;
  } else if (strcmp(action, "toggle") == 0) {
    espAction = ESPNOW_ACTION_TOGGLE;
  } else {
    server.send(400, "application/json", "{\"error\":\"Invalid Cluck-o-Magic action\"}");
    return;
  }

  if (espAction != ESPNOW_ACTION_OFF && !requireMaintenanceSession("Cluck-o-Magic vibrator control")) {
    return;
  }

  if (!sendCluckMagicCommand(relay, espAction)) {
    String response = "{\"error\":\"Cluck-o-Magic command failed\",\"status\":\"";
    response += jsonEscape(cluckMagicLastCommandStatus);
    response += "\"}";
    server.send(503, "application/json", response);
    return;
  }

  sendStatusJson();
}

void handleNotificationConfigUpdate() {
  if (!requireMaintenanceSession("notification configuration update")) {
    return;
  }

  bool changed = false;
  bool newEnabled = notificationEmailEnabled;
  String newEmailTo = notificationEmailTo;
  String newHubUrl = notificationHubUrl;

  if (server.hasArg("email_enabled")) {
    if (!parseBoolLike(server.arg("email_enabled"), newEnabled)) {
      server.send(400, "application/json",
                  "{\"error\":\"email_enabled must be true/false, on/off, yes/no, or 1/0\"}");
      return;
    }
    changed = true;
  }

  if (server.hasArg("email_to")) {
    newEmailTo = normalizedOptionalLimited(server.arg("email_to"), MAX_NOTIFICATION_EMAIL_LENGTH);
    changed = true;
  }

  if (server.hasArg("hub_url")) {
    newHubUrl = normalizedOptionalLimited(server.arg("hub_url"), MAX_NOTIFICATION_URL_LENGTH);
    changed = true;
  }

  if (!changed) {
    server.send(400, "application/json",
                "{\"error\":\"Provide one or more: email_enabled, email_to, hub_url\"}");
    return;
  }

  if (newEnabled && (newEmailTo.length() == 0 || newHubUrl.length() == 0)) {
    server.send(400, "application/json",
                "{\"error\":\"Email address and hub URL are required when notifications are enabled\"}");
    return;
  }

  notificationEmailEnabled = newEnabled;
  notificationEmailTo = newEmailTo;
  notificationHubUrl = newHubUrl;
  notificationLastStatus = notificationStatusDetail();

  logEvent(String("Notification settings updated: ") +
           (notificationEmailEnabled ? notificationEmailTo : String("disabled")));
  markConfigDirty();
  if (!savePersistentConfig()) {
    sendConfigSaveFailureResponse("notification configuration update");
    return;
  }
  sendStatusJson();
}

void handleNotificationTest() {
  if (!requireMaintenanceSession("notification test")) {
    return;
  }

  const bool sent = sendHubAlertNotification(
      "fbb-notification-test",
      "warning",
      "Bin Commander test alert",
      "The settings page requested a test notification.",
      "Test only",
      "Confirm the email reached the right operator.");

  sendNoStoreHeaders();
  String response = "{\"status\":\"";
  response += sent ? "sent" : "failed";
  response += "\",\"notification_status\":\"";
  response += jsonEscape(notificationLastStatus);
  response += "\",\"last_attempt_ms\":";
  response += String(notificationLastAttemptMs);
  response += ",\"last_success_ms\":";
  response += String(notificationLastSuccessMs);
  response += "}";
  server.send(sent ? 200 : 503, "application/json", response);
}

void handleAccessPasswordRotate() {
  if (rebootPending) {
    sendStatusJson();
    return;
  }

  if (!requireMaintenanceSession("AP access update")) {
    return;
  }

  bool newPasswordEnabled = server.hasArg("ap_password_enabled") || server.hasArg("enabled")
                                ? apPasswordEnabled
                                : true;
  if (server.hasArg("ap_password_enabled") &&
      !parseBoolLike(server.arg("ap_password_enabled"), newPasswordEnabled)) {
    server.send(400, "application/json",
                "{\"error\":\"ap_password_enabled must be true/false, on/off, yes/no, or 1/0\"}");
    return;
  }
  if (server.hasArg("enabled") && !parseBoolLike(server.arg("enabled"), newPasswordEnabled)) {
    server.send(400, "application/json",
                "{\"error\":\"enabled must be true/false, on/off, yes/no, or 1/0\"}");
    return;
  }

  const bool hadDirtyConfig = configDirty;
  const unsigned long previousDirtySince = configDirtySinceMs;
  const bool previousPasswordEnabled = apPasswordEnabled;
  const String previousPassword = deviceWifiPassword;
  String newPassword = deviceWifiPassword;
  bool generatedPassword = false;

  if (newPasswordEnabled) {
    if (server.hasArg("password")) {
      newPassword = normalizedOptionalLimited(server.arg("password"), MAX_ACCESS_PASSWORD_LENGTH);
      if (newPassword.length() < MIN_ACCESS_PASSWORD_LENGTH) {
        server.send(400, "application/json", "{\"error\":\"AP password must be 8 to 63 characters\"}");
        return;
      }
    } else {
      newPassword = generateAccessPassword();
      generatedPassword = true;
    }
  }

  apPasswordEnabled = newPasswordEnabled;
  deviceWifiPassword = newPassword;
  deviceAdminPassword = newPassword;
  markConfigDirty();

  if (!savePersistentConfig()) {
    apPasswordEnabled = previousPasswordEnabled;
    deviceWifiPassword = previousPassword;
    deviceAdminPassword = previousPassword;
    configDirty = hadDirtyConfig;
    configDirtySinceMs = previousDirtySince;
    sendConfigSaveFailureResponse("AP access update");
    return;
  }

  logEvent(apPasswordEnabled ? "AP password enabled; controller reboot pending." :
                               "AP opened; controller reboot pending.");
  requestControllerReboot("AP access update");

  sendNoStoreHeaders();
  String response = "{\"status\":\"ok\",";
  response += "\"message\":\"AP access updated. Reconnect after reboot if the AP security changed.\",";
  response += "\"ap_password_enabled\":";
  response += apPasswordEnabled ? "true" : "false";
  if (apPasswordEnabled) {
    response += ",\"new_password\":\"";
    response += jsonEscape(newPassword);
    response += "\",\"generated_password\":";
    response += generatedPassword ? "true" : "false";
  }
  response += ",\"reboot_pending\":true,\"reboot_reason\":\"";
  response += jsonEscape(rebootReason);
  response += "\"}";
  server.send(200, "application/json", response);
}

void handleMaintenanceUnlock() {
  if (!accessPasswordRequired()) {
    sendNoStoreHeaders();
    server.send(200, "application/json",
                "{\"status\":\"ok\",\"maintenance_unlocked\":true,\"open_access\":true,"
                "\"maintenance_token\":\"\",\"maintenance_session_remaining_ms\":0}");
    return;
  }

  if (!server.hasArg("password")) {
    sendNoStoreHeaders();
    server.send(400, "application/json", "{\"error\":\"Required arg: password\"}");
    return;
  }

  const String password = server.arg("password");
  if (password != deviceWifiPassword) {
    sendNoStoreHeaders();
    server.send(401, "application/json", "{\"error\":\"Invalid access password\"}");
    return;
  }

  maintenanceSessionToken = generateMaintenanceToken();
  touchMaintenanceSession();
  logEvent("Maintenance session unlocked.");

  sendNoStoreHeaders();
  String response = "{\"status\":\"ok\",";
  response += "\"maintenance_unlocked\":true,";
  response += "\"maintenance_token\":\"";
  response += jsonEscape(maintenanceSessionToken);
  response += "\",\"maintenance_session_remaining_ms\":";
  response += String(maintenanceSessionRemainingMs(millis()));
  response += "}";
  server.send(200, "application/json", response);
}

const char *manualHtml() {
  return R"HTML(
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bin Commander Manual</title>
  <style>
    body {
      margin: 0;
      font-family: "Segoe UI", Tahoma, sans-serif;
      background: #f2f6fb;
      color: #152235;
    }
    .wrap {
      max-width: 940px;
      margin: 0 auto;
      padding: 20px 16px 40px;
    }
    .card {
      background: #fff;
      border: 1px solid #d9e3f0;
      border-radius: 14px;
      padding: 16px;
      margin-bottom: 14px;
      box-shadow: 0 8px 22px rgba(8, 20, 40, 0.08);
    }
    h1 { margin: 0; font-size: 1.5rem; }
    h2 { margin: 0 0 10px; font-size: 1.08rem; }
    p, li { line-height: 1.45; }
    ul { margin: 8px 0 0 18px; }
    .muted { color: #5b6f86; }
    code {
      background: #eef4fb;
      border: 1px solid #d8e4f2;
      border-radius: 6px;
      padding: 1px 5px;
    }
    .back {
      display: inline-block;
      margin-top: 10px;
      text-decoration: none;
      background: #0b4f74;
      color: #fff;
      font-weight: 700;
      border-radius: 9px;
      padding: 8px 12px;
    }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>Bin Commander Manual</h1>
      <p class="muted">Network: Bin Commander | AP: BIN COMMANDER</p>
      <a class="back" href="/">Back to Controller</a>
    </div>

    <div class="card">
      <h2>Purpose</h2>
      <p>This controller manages two feed bins feeding one hopper. It watches the hopper sensor, runs alarms, automatic bin-selection logic, manual overrides with leases, and emergency controls.</p>
    </div>

    <div class="card">
      <h2>Feed State and Alarms</h2>
      <ul>
        <li><b>Feed Present</b>: hopper sensor sees feed at sensor level.</li>
        <li><b>Low Feed</b>: sensor is clear (hopper below sensor level).</li>
        <li><b>Alarm 1 - No Runout Too Long</b>: hopper stayed present too long. LED is solid red.</li>
        <li><b>Alarm 2 - Empty Too Long</b>: hopper stayed low too long. LED flashes red.</li>
        <li><b>Clear / Resume</b>: after checking the bin, auger, bridging, and sensor, clear the alarm to restart the sensor timer and let the selected feed mode resume.</li>
        <li>Alarm delays are configured in minutes in the Alarm Configuration card.</li>
        <li><b>Hopper Top-Off Time</b>: extra automatic auger runtime after the hopper sensor first sees feed, used to finish filling hoppers where the sensor is covered early.</li>
      </ul>
    </div>

    <div class="card">
      <h2>Feed Bin Controls</h2>
      <ul>
        <li><b>Toggle switch</b>: latches each feed bin ON/OFF.</li>
        <li><b>Momentary button</b>: runs a feed bin only while the web button is held.</li>
        <li><b>Emergency Stop</b>: latches both bins OFF and blocks start commands until reset.</li>
        <li><b>Hardware emergency stop</b>: an optional normally-closed loop on the PCB forces both bins OFF and latches the controller if the loop opens or the stop is pressed.</li>
        <li><b>Fault latch</b>: trips on runtime overruns and must be cleared explicitly.</li>
      </ul>
    </div>

    <div class="card">
      <h2>Feeder Logic Modes</h2>
      <ul>
        <li><code>manual</code>: direct control from switches. The hopper sensor only reports status and alarms.</li>
        <li><code>sensor_demand</code>: hopper sensor low starts the preferred bin; feed present starts hopper top-off, then stops both bins.</li>
        <li><code>auto_switch</code>: hopper sensor low starts the preferred bin; if no recovery after timeout, switch to the other bin once, then use hopper top-off after feed is present.</li>
        <li><code>alternate_cycle</code>: hopper sensor low starts the preferred bin; after hopper top-off completes, stop both bins and make the other bin preferred next time.</li>
        <li><code>timed_alternate</code>: hopper sensor low starts the preferred bin; feed present starts hopper top-off, and the preferred bin alternates by timer while idle.</li>
      </ul>
      <p>When a non-manual mode is active, direct feed-bin controls take a manual lease and automation yields until that lease expires. Any mode change still starts from a clean OFF state so the new logic owns the outputs explicitly.</p>
    </div>

    <div class="card">
      <h2>Bin Commander Integration</h2>
      <ul>
        <li>Planner metadata stays available for Chicken Chat integration.</li>
        <li>Feed-bin control stays focused on bins, alarms, and logic on this device.</li>
        <li>The shared data contract can still carry house rollout notes when Chicken Chat needs them.</li>
      </ul>
      <p>The feeder-bin dashboard does not surface the planner as a primary task area, but the compatibility fields remain in the snapshot.</p>
    </div>

    <div class="card">
      <h2>Remote Access</h2>
      <p>For remote access, use the built-in controller AP for direct service, optional station Wi-Fi for farm-network access, or a small always-on Linux gateway with Tailscale on the same site as the controller. Forward either the controller AP address or the station-network address to <code>127.0.0.1</code> on the gateway with a tiny local proxy such as <code>socat</code>, then publish it into the tailnet with <code>tailscale serve --bg --https=443 localhost:8080</code> or <code>tailscale serve --bg --http=80 localhost:8080</code>. The gateway services in <code>ops/tailscale/</code> show the same shape with <code>fbb-socat.service</code> and <code>fbb-tailscale-serve.service</code>; both can read <code>/etc/default/fbb</code> so the controller host, proxy port, and health URL are easy to override without editing the unit files. The controller AP is open by default. The dashboard can enable or change the AP / OTA password later, and optional station Wi-Fi keeps the AP available while joining a farm network.</p>
    </div>

    <div class="card">
      <h2>API Summary</h2>
      <ul>
        <li><code>GET /api/status</code> - full state snapshot, including <code>controller_state</code>, <code>controller_state_detail</code>, and the stable <code>controller_state_code</code>.</li>
        <li><code>GET /api/health</code> - readiness summary for gateway monitoring, with <code>ok</code>, <code>health_level</code>, <code>health_level_code</code>, <code>controller_state</code>, and <code>controller_state_code</code>.</li>
        <li><code>POST /api/security/unlock</code> - exchange the AP / OTA password for a short-lived maintenance token when AP password protection is enabled.</li>
        <li><code>POST /api/feedbin/1/on|off|toggle</code>, same for bin 2. <code>on</code> and <code>toggle</code> require the maintenance token; <code>off</code> remains available for safe shutoff.</li>
        <li><code>POST /api/feedlogic/config</code> - mode, nicknames, alternation/switch timers.</li>
        <li><code>POST /api/alarm/config</code> - alarm delays.</li>
        <li><code>POST /api/alarm/clear</code> - clear the active feed alarm, restart the sensor timer, and allow the selected feed mode to resume.</li>
        <li><code>POST /api/safety/config</code> - manual lease, automation keepalive, runtime limit.</li>
        <li><code>POST /api/hardware/config</code> - relay, LED, and feed sensor polarity.</li>
        <li><code>POST /api/wifi/config</code> - optional station Wi-Fi credentials for farm-network access and browser firmware uploads.</li>
        <li><code>POST /api/notifications/config</code> - local hub notification endpoint and operator email target.</li>
        <li><code>POST /api/notifications/test</code> - send a test alert to the configured Chicken Chat hub.</li>
        <li><code>POST /api/houseplanner/config</code> - compatibility planner fields/checklist.</li>
        <li><code>POST /api/lease/heartbeat</code> - renew the manual control lease while the UI is open; it does not extend maintenance access.</li>
        <li><code>POST /api/emergency/stop</code> and <code>/api/emergency/reset</code> - stop is immediate; reset requires the maintenance token.</li>
        <li><code>POST /api/fault/reset</code> - clear a fault latch after investigation.</li>
        <li><code>POST /api/reboot</code> - force outputs OFF and restart the controller safely.</li>
        <li><code>POST /api/security/ap/config</code> - enable, disable, or change AP / OTA password protection, save it to NVS, and reboot the controller.</li>
        <li><code>GET /api/config</code> - download a backup snapshot of persistent settings.</li>
        <li><code>POST /api/config</code> - restore a backup snapshot from exported JSON.</li>
        <li><code>GET /api/logs</code> - recent event log.</li>
        <li><code>POST /update</code> via <code>/update</code> - OTA firmware upload.</li>
        <li>Config-changing endpoints return HTTP 503 if NVS persistence fails, even when the live in-memory state has already updated.</li>
        <li>Protected config and reboot actions return HTTP 403 until the browser tab unlocks maintenance access.</li>
      </ul>
    </div>
  </div>
</body>
</html>
)HTML";
}

const char *indexHtml() {
  return R"HTML(
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bin Commander | Feed Bin Controller</title>
  <style>
    :root {
      --bg: #08111f;
      --bg-soft: #0d1a2f;
      --panel: rgba(11, 21, 38, 0.88);
      --panel-strong: rgba(18, 30, 50, 0.96);
      --ink: #eef4ff;
      --muted: #9bb0c9;
      --line: rgba(152, 178, 209, 0.18);
      --good: #3ebd7b;
      --warn: #f4b042;
      --bad: #ff6b5c;
      --off: #8a96ab;
      --accent: #62a6ff;
      --shadow: 0 24px 60px rgba(0, 0, 0, 0.28);
    }

    * {
      box-sizing: border-box;
    }

    html {
      color-scheme: dark;
    }

    body {
      margin: 0;
      min-height: 100vh;
      color: var(--ink);
      background:
        radial-gradient(circle at top left, rgba(98, 166, 255, 0.16), transparent 28%),
        radial-gradient(circle at top right, rgba(62, 189, 123, 0.12), transparent 26%),
        radial-gradient(circle at bottom left, rgba(244, 176, 66, 0.12), transparent 30%),
        linear-gradient(145deg, var(--bg), var(--bg-soft));
      font-family: "Avenir Next", "Trebuchet MS", "Gill Sans", "Noto Sans", sans-serif;
    }

    .wrap {
      width: min(1360px, calc(100% - 2rem));
      margin: 0 auto;
      padding: 22px 0 28px;
    }

    .hero,
    .card {
      background: var(--panel);
      border: 1px solid var(--line);
      box-shadow: var(--shadow);
      backdrop-filter: blur(18px);
    }

    .hero {
      border-radius: 24px;
      padding: 18px 22px;
      margin-bottom: 16px;
      display: grid;
      gap: 14px;
    }

    .hero-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 16px;
      flex-wrap: wrap;
    }

    .eyebrow {
      margin: 0;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: 0.14em;
      font-size: 0.75rem;
      font-weight: 800;
    }

    .hero-title {
      margin: 0;
      font-size: clamp(2rem, 3.5vw, 3.4rem);
      line-height: 0.96;
      letter-spacing: 0;
    }

    .hero-copy {
      margin: 0;
      max-width: 64ch;
      color: var(--muted);
      font-size: 1.01rem;
      line-height: 1.5;
    }

    .uptime-bar {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      width: fit-content;
      padding: 10px 14px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.04);
      border: 1px solid var(--line);
      color: var(--ink);
      font-size: 0.88rem;
      font-weight: 800;
      letter-spacing: 0.03em;
    }

    .help-link {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      padding: 10px 14px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.04);
      color: var(--ink);
      font-weight: 800;
      font-size: 0.88rem;
      letter-spacing: 0.03em;
      border: 1px solid var(--line);
    }

    .hero-controls {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }

    .hero-controls > button,
    .hero-controls > .help-link {
      flex: 1 1 150px;
    }

    .hero-controls > button.emergency {
      flex: 3 1 360px;
      width: auto;
      min-height: 50px;
      font-size: 1.08rem;
    }

    .card {
      border-radius: 22px;
      padding: 18px;
      margin-bottom: 16px;
    }

    .alarm-banner {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 12px;
      flex-wrap: wrap;
    }

    .alarm-actions {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 10px;
      flex-wrap: wrap;
    }

    .system-banner {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 12px;
      align-items: start;
      border-left: 6px solid var(--accent);
    }

    .system-banner.good {
      border-left-color: var(--good);
    }

    .system-banner.info {
      border-left-color: var(--accent);
    }

    .system-banner.warn {
      border-left-color: var(--warn);
    }

    .system-banner.alarm {
      border-left-color: var(--bad);
    }

    .system-banner.offline {
      border-left-color: var(--off);
    }

    .system-banner-title {
      margin: 6px 0 0;
      font-size: 1.35rem;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .system-banner-detail {
      margin: 6px 0 0;
      color: var(--muted);
      line-height: 1.5;
    }

    .system-banner-meta {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 8px;
    }

    .state-title {
      font-size: 0.76rem;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: var(--muted);
      font-weight: 800;
    }

    .state-value {
      margin-top: 6px;
      font-size: 1.4rem;
      font-weight: 800;
      letter-spacing: -0.02em;
    }

    .chip {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      border-radius: 999px;
      padding: 8px 14px;
      font-weight: 800;
      font-size: 0.86rem;
      letter-spacing: 0.03em;
      border: 1px solid var(--line);
      background: rgba(255, 255, 255, 0.04);
      color: var(--ink);
    }

    .chip.warn {
      color: var(--warn);
      border-color: rgba(244, 176, 66, 0.28);
      background: rgba(244, 176, 66, 0.08);
    }

    .chip.alarm {
      color: var(--bad);
      border-color: rgba(255, 107, 92, 0.28);
      background: rgba(255, 107, 92, 0.08);
    }

    .chip.normal {
      color: var(--good);
      border-color: rgba(62, 189, 123, 0.28);
      background: rgba(62, 189, 123, 0.08);
    }

    .mini-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 12px;
      margin-top: 14px;
    }

    .mini {
      background: var(--panel-strong);
      border: 1px solid var(--line);
      border-radius: 16px;
      padding: 12px;
    }

    .mini .k {
      color: var(--muted);
      font-size: 0.76rem;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      font-weight: 800;
    }

    .mini .v {
      margin-top: 6px;
      font-size: 1.04rem;
      font-weight: 800;
    }

    .silo-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 16px;
      margin-top: 12px;
    }

    .silo {
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid var(--line);
      border-radius: 20px;
      padding: 16px;
      border-left: 6px solid var(--accent);
    }

    .silo h3 {
      margin: 0;
      font-size: 1.15rem;
      letter-spacing: -0.02em;
    }

    .silo-status {
      margin: 8px 0 12px;
      color: var(--muted);
      font-weight: 700;
    }

    .toggle-line {
      display: flex;
      align-items: center;
      gap: 12px;
      margin: 6px 0 12px;
    }

    .switch {
      position: relative;
      display: inline-block;
      width: 64px;
      height: 34px;
    }

    .switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      inset: 0;
      background: #475569;
      transition: 0.2s;
      border-radius: 999px;
    }

    .slider::before {
      content: "";
      position: absolute;
      height: 26px;
      width: 26px;
      left: 4px;
      bottom: 4px;
      background: #fff;
      border-radius: 50%;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
      transition: 0.2s;
    }

    .switch input:checked + .slider {
      background: var(--good);
    }

    .switch input:checked + .slider::before {
      transform: translateX(30px);
    }

    .toggle-state {
      font-weight: 800;
      color: var(--good);
      letter-spacing: 0.04em;
    }

    .btn-row {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    button {
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 10px 13px;
      cursor: pointer;
      font-weight: 800;
      color: var(--ink);
      background: rgba(255, 255, 255, 0.04);
      transition: transform 120ms ease, filter 120ms ease, background 120ms ease, border-color 120ms ease;
    }

    button:hover {
      transform: translateY(-1px);
      background: rgba(255, 255, 255, 0.08);
      border-color: rgba(255, 255, 255, 0.24);
      filter: none;
    }

    button.stop {
      background: rgba(255, 107, 92, 0.16);
      color: var(--bad);
      border-color: rgba(255, 107, 92, 0.28);
    }

    button.alt {
      background: rgba(138, 150, 171, 0.14);
      color: var(--ink);
    }

    button.momentary {
      background: rgba(255, 107, 92, 0.16);
      color: var(--bad);
      width: 100%;
    }

    button.emergency {
      background: linear-gradient(180deg, rgba(255, 107, 92, 0.22), rgba(255, 107, 92, 0.12));
      color: #ffd1cc;
      width: 100%;
      font-size: 1rem;
      letter-spacing: 0.04em;
    }

    button.reset {
      background: rgba(138, 150, 171, 0.16);
      color: var(--ink);
      width: 100%;
    }

    button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      transform: none;
      filter: none;
    }

    .config-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 12px;
      align-items: end;
      margin-top: 8px;
    }

    label {
      display: block;
      font-size: 0.76rem;
      color: var(--muted);
      margin-bottom: 6px;
      text-transform: uppercase;
      letter-spacing: 0.11em;
      font-weight: 800;
    }

    label.with-info {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      position: relative;
      width: auto;
    }

    .info-bubble {
      position: relative;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      border: 1px solid rgba(143, 212, 255, 0.52);
      color: #8fd4ff;
      background: rgba(143, 212, 255, 0.12);
      font-size: 0.72rem;
      line-height: 1;
      text-transform: none;
      letter-spacing: 0;
      cursor: help;
      flex: 0 0 auto;
    }

    .info-bubble::after {
      content: attr(data-tip);
      position: absolute;
      z-index: 20;
      left: 0;
      bottom: calc(100% + 8px);
      width: 260px;
      max-width: min(260px, calc(100vw - 32px));
      padding: 9px 10px;
      border-radius: 10px;
      border: 1px solid rgba(143, 212, 255, 0.34);
      background: #0d1726;
      color: var(--ink);
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.34);
      font-size: 0.78rem;
      font-weight: 700;
      line-height: 1.35;
      text-transform: none;
      letter-spacing: 0;
      opacity: 0;
      pointer-events: none;
      transform: translateY(4px);
      transition: opacity 120ms ease, transform 120ms ease;
    }

    .info-bubble:hover::after,
    .info-bubble:focus::after {
      opacity: 1;
      transform: translateY(0);
    }

    .info-bubble:focus {
      outline: 2px solid rgba(143, 212, 255, 0.7);
      outline-offset: 2px;
    }

    input[type="number"],
    input[type="text"],
    select,
    textarea {
      width: 100%;
      padding: 10px 11px;
      border: 1px solid var(--line);
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.04);
      color: var(--ink);
      box-sizing: border-box;
      font-size: 0.96rem;
    }

    input[type="checkbox"] {
      width: 18px;
      height: 18px;
      accent-color: var(--accent);
      margin: 0;
      flex: 0 0 auto;
    }

    input::placeholder,
    textarea::placeholder {
      color: #7f93ae;
    }

    textarea {
      min-height: 92px;
      resize: vertical;
    }

    .check-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
      gap: 8px 12px;
      margin-top: 8px;
    }

    .check-item {
      display: flex;
      align-items: center;
      gap: 9px;
      font-size: 0.93rem;
      color: var(--ink);
    }

    .diag-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
      gap: 10px;
      margin-top: 10px;
    }

    .diag-panel > summary {
      list-style: none;
      cursor: pointer;
      user-select: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 10px 14px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.04);
      color: var(--ink);
      font-weight: 800;
      border: 1px solid var(--line);
    }

    .diag-panel > summary::-webkit-details-marker {
      display: none;
    }

    .diag-panel > summary::after {
      content: " ▼";
      font-size: 0.82rem;
    }

    .diag-panel[open] > summary::after {
      content: " ▲";
    }

    .diag {
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 8px 10px;
      font-size: 0.9rem;
    }

    .log-panel {
      margin: 12px 0 0;
      padding: 14px;
      border: 1px solid var(--line);
      border-radius: 16px;
      background: rgba(0, 0, 0, 0.18);
      color: var(--ink);
      font-size: 0.9rem;
      line-height: 1.45;
      max-height: 260px;
      overflow: auto;
      white-space: pre-wrap;
    }

    .inline-actions {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      align-items: center;
    }

    .diag span {
      display: block;
      color: var(--muted);
      font-size: 0.76rem;
      margin-bottom: 4px;
      text-transform: uppercase;
      letter-spacing: 0.11em;
      font-weight: 800;
    }

    .muted {
      color: var(--muted);
    }

    body:not(.diagnostics-page) .advanced-only {
      display: none;
    }

    h2 {
      margin: 0;
      font-size: 1.05rem;
    }

    @media (max-width: 720px) {
      .wrap {
        width: min(100% - 1rem, 1360px);
        padding-top: 10px;
      }

      .hero {
        padding: 16px;
        border-radius: 20px;
      }

      .card,
      .silo,
      .mini,
      .diag {
        border-radius: 18px;
      }

      .hero-controls {
        width: 100%;
      }

      button {
        flex: 1 1 auto;
      }

      .state-value {
        font-size: 1.15rem;
      }
    }

    @media (prefers-reduced-motion: reduce) {
      *,
      *::before,
      *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
      }
    }
  </style>
</head>
<body>
  <script>
    if (location.pathname === '/diagnostics') {
      document.body.classList.add('diagnostics-page');
    }
  </script>
  <div class="wrap">
    <div class="hero">
      <div class="hero-top">
        <div>
          <div class="hero-title">Bin Commander</div>
        </div>
      </div>
      <div class="uptime-bar">Controller Uptime: <span id="uptimeCounter">--:--:--</span></div>
      <div class="hero-controls">
        <button class="emergency" onclick="emergencyStop()">EMERGENCY STOP</button>
        <button class="reset" onclick="resetEmergencyStop()">Reset Emergency Stop</button>
        <a class="help-link" href="/manual" target="_blank" rel="noopener noreferrer">Help</a>
        <a class="help-link" href="/update" target="_blank" rel="noopener noreferrer">OTA Update</a>
        <a class="help-link" href="/diagnostics">Diagnostics</a>
        <button class="alt" id="rebootButton" onclick="rebootController()">Safe Reboot</button>
      </div>
      <div class="muted" id="emergencyState">Emergency Stop: loading...</div>
    </div>

    <div class="card system-banner info" id="systemBanner">
      <div>
        <div class="state-title">Controller State</div>
        <div class="system-banner-title" id="systemBannerTitle">Loading...</div>
        <div class="system-banner-detail" id="systemBannerDetail">Fetching controller status...</div>
      </div>
      <div class="system-banner-meta">
        <div class="chip normal" id="systemBannerBadge">LOADING</div>
      </div>
    </div>

    <div class="card">
      <div class="alarm-banner">
        <div>
          <div class="state-title">Feed State</div>
          <div class="state-value" id="feedState">...</div>
          <div class="muted" id="alarmHint">Loading alarm status...</div>
        </div>
        <div class="alarm-actions">
          <div class="chip normal" id="alarmChip">NORMAL</div>
          <button class="alt" id="alarmClearButton" onclick="clearFeedAlarm()" disabled>Clear / Resume</button>
        </div>
      </div>

      <div class="mini-grid">
        <div class="mini">
          <div class="k">Feed Present Time</div>
          <div class="v" id="feedPresentDur">-</div>
        </div>
        <div class="mini">
          <div class="k">Low Feed Time</div>
          <div class="v" id="lowFeedDur">-</div>
        </div>
        <div class="mini">
          <div class="k">Alarm LED</div>
          <div class="v" id="alarmLed">-</div>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>Feed Bin Controls</h2>
      <div class="silo-grid">
        <div class="silo">
          <h3 id="feedBin1Title">FEED BIN 1</h3>
          <div class="silo-status" id="feedBin1State">Status: ...</div>
          <div class="toggle-line">
            <label class="switch">
              <input id="feedBin1Toggle" type="checkbox" onchange="setFeedBinToggle(1, this.checked)">
              <span class="slider"></span>
            </label>
            <div class="toggle-state" id="feedBin1ToggleState">OFF</div>
          </div>
          <div class="btn-row">
            <button class="momentary"
                    id="feedBin1Momentary"
                    onmousedown="momentaryFeedBin(1, true)"
                    onmouseup="momentaryFeedBin(1, false)"
                    onmouseleave="momentaryFeedBin(1, false)"
                    ontouchstart="momentaryTouch(event, 1, true)"
                    ontouchend="momentaryTouch(event, 1, false)"
                    ontouchcancel="momentaryTouch(event, 1, false)">
              <span id="feedBin1MomentaryLabel">Momentary Feed Bin 1</span>
            </button>
          </div>
        </div>
        <div class="silo">
          <h3 id="feedBin2Title">FEED BIN 2</h3>
          <div class="silo-status" id="feedBin2State">Status: ...</div>
          <div class="toggle-line">
            <label class="switch">
              <input id="feedBin2Toggle" type="checkbox" onchange="setFeedBinToggle(2, this.checked)">
              <span class="slider"></span>
            </label>
            <div class="toggle-state" id="feedBin2ToggleState">OFF</div>
          </div>
          <div class="btn-row">
            <button class="momentary"
                    id="feedBin2Momentary"
                    onmousedown="momentaryFeedBin(2, true)"
                    onmouseup="momentaryFeedBin(2, false)"
                    onmouseleave="momentaryFeedBin(2, false)"
                    ontouchstart="momentaryTouch(event, 2, true)"
                    ontouchend="momentaryTouch(event, 2, false)"
                    ontouchcancel="momentaryTouch(event, 2, false)">
              <span id="feedBin2MomentaryLabel">Momentary Feed Bin 2</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>Cluck-o-Magic Bin Shaker</h2>
      <div class="muted" id="cluckMagicStatus">Scanning for shaker module...</div>
      <div class="silo-grid">
        <div class="silo">
          <h3>BIN 1 VIBRATOR</h3>
          <div class="silo-status" id="cluckMagicBin1State">Status: ...</div>
          <div class="btn-row">
            <button class="momentary"
                    id="cluckMagicBin1Momentary"
                    onmousedown="momentaryCluckMagic(1, true)"
                    onmouseup="momentaryCluckMagic(1, false)"
                    onmouseleave="momentaryCluckMagic(1, false)"
                    ontouchstart="cluckMagicTouch(event, 1, true)"
                    ontouchend="cluckMagicTouch(event, 1, false)"
                    ontouchcancel="cluckMagicTouch(event, 1, false)">
              Momentary Vibrator 1
            </button>
            <button class="alt" id="cluckMagicBin1Off" onclick="cluckMagic(1, 'off')">Stop Vibrator 1</button>
          </div>
        </div>
        <div class="silo">
          <h3>BIN 2 VIBRATOR</h3>
          <div class="silo-status" id="cluckMagicBin2State">Status: ...</div>
          <div class="btn-row">
            <button class="momentary"
                    id="cluckMagicBin2Momentary"
                    onmousedown="momentaryCluckMagic(2, true)"
                    onmouseup="momentaryCluckMagic(2, false)"
                    onmouseleave="momentaryCluckMagic(2, false)"
                    ontouchstart="cluckMagicTouch(event, 2, true)"
                    ontouchend="cluckMagicTouch(event, 2, false)"
                    ontouchcancel="cluckMagicTouch(event, 2, false)">
              Momentary Vibrator 2
            </button>
            <button class="alt" id="cluckMagicBin2Off" onclick="cluckMagic(2, 'off')">Stop Vibrator 2</button>
          </div>
        </div>
      </div>
      <div class="config-grid">
        <div>
          <label for="cluckMagicSelectedMac">Selected Cluck-o-Magic MAC</label>
          <input id="cluckMagicSelectedMac" type="text" maxlength="17" placeholder="AA:BB:CC:DD:EE:FF">
        </div>
        <div>
          <label for="cluckMagicDetectedSelect">Detected Modules</label>
          <select id="cluckMagicDetectedSelect"></select>
        </div>
        <div class="inline-actions">
          <button onclick="saveCluckMagicConfig()">Save Selected Module</button>
          <button class="alt" onclick="useDetectedCluckMagic()">Use Detected</button>
          <button class="alt" id="cluckMagicBothOff" onclick="cluckMagic('both', 'off')">Stop Both Vibrators</button>
        </div>
      </div>
      <div class="diag-grid">
        <div class="diag"><span>Selected Module</span><div id="cluckMagicSelected">-</div></div>
        <div class="diag"><span>Last Shaker Command</span><div id="cluckMagicLastCommand">-</div></div>
        <div class="diag"><span>Detected Shakers</span><div id="cluckMagicDetectedList">-</div></div>
      </div>
    </div>

    <div class="card">
      <h2>Feed Schedule &amp; Logic</h2>
      <div class="config-grid">
        <div>
          <label class="with-info" for="feedBin1NameInput">Feed Bin 1 Nickname <span class="info-bubble" tabindex="0" role="button" aria-label="Feed Bin 1 nickname info" data-tip="Display name only. It makes the buttons and status easier to read, but it does not change wiring or relay assignment.">?</span></label>
          <input id="feedBin1NameInput" type="text" maxlength="32" placeholder="Starter feed">
        </div>
        <div>
          <label class="with-info" for="feedBin2NameInput">Feed Bin 2 Nickname <span class="info-bubble" tabindex="0" role="button" aria-label="Feed Bin 2 nickname info" data-tip="Display name only. Use the feed type or bin number.">?</span></label>
          <input id="feedBin2NameInput" type="text" maxlength="32" placeholder="Grower feed">
        </div>
        <div>
          <label class="with-info" for="logicTopOffSec">Hopper Top-Off Time (sec) <span class="info-bubble" tabindex="0" role="button" aria-label="Hopper top-off time info" data-tip="After the hopper sensor first sees feed during an automatic fill, keep the active bin auger running this many extra seconds so the hopper can finish filling. Set 0 to stop as soon as the sensor is covered.">?</span></label>
          <input id="logicTopOffSec" type="number" min="0" step="1">
        </div>
        <div>
          <label class="with-info" for="logicModeSelect">Logic Mode <span class="info-bubble" tabindex="0" role="button" aria-label="Logic mode info" data-tip="Manual is direct buttons. Hopper Sensor runs the preferred bin when feed is low. Auto Switch tries the other bin if feed does not recover. Alternate modes rotate which bin starts.">?</span></label>
          <select id="logicModeSelect">
            <option value="manual">Manual - Direct Buttons</option>
            <option value="sensor_demand">Hopper Sensor - Preferred Bin</option>
            <option value="auto_switch">Auto Switch</option>
            <option value="alternate_cycle">Alternate Each Fill</option>
            <option value="timed_alternate">Timed Alternate</option>
          </select>
        </div>
        <div>
          <label class="with-info" for="logicAlternateMin">Time To Alternate (min) <span class="info-bubble" tabindex="0" role="button" aria-label="Time to alternate info" data-tip="Used by Timed Alternate. While the hopper is full and idle, this timer changes which bin will start next. It does not force a running auger to switch.">?</span></label>
          <input id="logicAlternateMin" type="number" min="1" step="1">
        </div>
        <div>
          <label class="with-info" for="logicAutoSwitchSec">Auto Switch Timeout (sec) <span class="info-bubble" tabindex="0" role="button" aria-label="Auto switch timeout info" data-tip="Used by Auto Switch. If the selected bin runs this long and the hopper sensor still does not see feed, the controller tries the other bin once.">?</span></label>
          <input id="logicAutoSwitchSec" type="number" min="10" step="1">
        </div>
        <div>
          <label class="with-info" for="logicPreferredBin">Preferred Start Bin <span class="info-bubble" tabindex="0" role="button" aria-label="Preferred start bin info" data-tip="The bin that starts first when the hopper calls for feed. Alternate modes may change this automatically after a fill or after the timer.">?</span></label>
          <select id="logicPreferredBin">
            <option value="1">Feed Bin 1</option>
            <option value="2">Feed Bin 2</option>
          </select>
        </div>
        <div>
          <button onclick="saveFeedLogicConfig()">Save Feeder Logic</button>
        </div>
      </div>
    </div>

    <div class="card advanced-only">
      <h2>Alarm Timers</h2>
      <div class="muted">Set how long the hopper sensor can stay covered or empty before the controller raises an alarm. Alarm 1 is solid red. Alarm 2 is flashing red.</div>
      <div class="config-grid">
        <div>
          <label class="with-info" for="noRunoutMin">No Runout Alarm Delay <span class="info-bubble" tabindex="0" role="button" aria-label="No runout alarm delay info" data-tip="Alarm 1. If feed stays present too long without dropping below the hopper sensor, the bin may not be feeding normally.">?</span></label>
          <input id="noRunoutMin" type="number" min="1" step="1">
        </div>
        <div>
          <label class="with-info" for="emptyTooLongMin">Empty Too Long Alarm Delay <span class="info-bubble" tabindex="0" role="button" aria-label="Empty too long alarm delay info" data-tip="Alarm 2. If the auger is trying to feed but the hopper sensor stays low this long, suspect empty bin, bridging, clog, or failed auger.">?</span></label>
          <input id="emptyTooLongMin" type="number" min="1" step="1">
        </div>
        <div>
          <button onclick="saveAlarmConfig()">Save Alarm Settings</button>
        </div>
      </div>
    </div>

    <div class="card advanced-only">
      <h2>Safety Limits</h2>
      <div class="muted">These limits stop augers when a browser, network link, or automatic cycle stops checking in. Safe reboot also turns both augers OFF before restart.</div>
      <div class="config-grid">
        <div>
          <label class="with-info" for="manualLeaseSec">Manual Run Timeout (sec) <span class="info-bubble" tabindex="0" role="button" aria-label="Manual run timeout info" data-tip="How long a manual ON command may keep running without a fresh browser heartbeat. If the phone or laptop disappears, the output returns OFF.">?</span></label>
          <input id="manualLeaseSec" type="number" min="10" step="1">
        </div>
        <div>
          <label class="with-info" for="relayMaxMin">Max Auger Runtime (min) <span class="info-bubble" tabindex="0" role="button" aria-label="Max auger runtime info" data-tip="Absolute maximum runtime for a relay. If an auger exceeds this, the controller trips a fault and forces outputs OFF.">?</span></label>
          <input id="relayMaxMin" type="number" min="1" step="1">
        </div>
        <div>
          <label class="with-info" for="automationKeepaliveSec">Auto Mode Check-In (sec) <span class="info-bubble" tabindex="0" role="button" aria-label="Auto mode check-in info" data-tip="How often automation must renew ownership while it is running an output. Missed keepalive means the controller drops the relay OFF.">?</span></label>
          <input id="automationKeepaliveSec" type="number" min="5" step="1">
        </div>
        <div class="inline-actions">
          <button onclick="saveSafetyConfig()">Save Safety Settings</button>
          <button class="alt" onclick="resetFault()">Reset Fault</button>
        </div>
      </div>
    </div>

    <div class="card advanced-only">
      <h2>AP Access</h2>
      <div class="muted">The controller AP is open unless password protection is turned on here. With password protection on, enter the AP / OTA password once to unlock changes in this browser tab.</div>
      <div class="inline-actions">
        <input id="maintenancePassword" type="password" autocomplete="current-password" placeholder="AP / OTA password">
        <button id="maintenanceUnlockButton" onclick="unlockMaintenance()">Unlock</button>
        <button class="alt" onclick="lockMaintenance()">Lock</button>
      </div>
      <div class="diag-grid">
        <div class="diag"><span>Change Access</span><div id="maintenanceStatus">LOCKED</div></div>
        <div class="diag"><span>Unlock Time Left</span><div id="maintenanceLease">NONE</div></div>
      </div>
      <div class="config-grid" style="margin-top: 12px;">
        <label class="check-item"><input id="apPasswordEnabled" type="checkbox"> Require AP / OTA password</label>
        <div>
          <label for="apPasswordNew">New AP Password</label>
          <input id="apPasswordNew" type="password" minlength="8" maxlength="63" autocomplete="new-password" placeholder="Blank generates one">
        </div>
        <div class="inline-actions">
          <button onclick="saveApAccess(false)">Save AP Access</button>
          <button class="alt" onclick="saveApAccess(true)">Generate AP Password</button>
        </div>
      </div>
    </div>

    <div class="card advanced-only">
      <h2>Network Manager</h2>
      <div class="muted">Join farm Wi-Fi while keeping the controller AP available. ESP-NOW stays on the local service channel for nearby modules such as Cluck-o-Magic.</div>
      <div class="config-grid">
        <label class="check-item"><input id="stationWifiEnabled" type="checkbox"> Connect to farm Wi-Fi</label>
        <div>
          <label for="stationWifiSsid">Wi-Fi Name</label>
          <input id="stationWifiSsid" type="text" maxlength="32" autocomplete="off" placeholder="Farm Wi-Fi">
        </div>
        <div>
          <label for="stationWifiPassword">Wi-Fi Password</label>
          <input id="stationWifiPassword" type="password" maxlength="63" autocomplete="new-password" placeholder="Leave blank to keep saved password">
        </div>
        <label class="check-item"><input id="stationWifiClearPassword" type="checkbox"> Clear saved Wi-Fi password</label>
        <div class="inline-actions">
          <button onclick="saveWifiConfig()">Save Wi-Fi</button>
          <a class="help-link" id="networkUpdateLink" href="/update" target="_blank" rel="noopener noreferrer">OTA Update</a>
        </div>
      </div>
      <div class="diag-grid">
        <div class="diag"><span>Farm Wi-Fi Status</span><div id="stationWifiStatus">-</div></div>
        <div class="diag"><span>Farm Network IP</span><div id="stationWifiIp">-</div></div>
        <div class="diag"><span>Farm Wi-Fi Signal</span><div id="stationWifiRssi">-</div></div>
      </div>
    </div>

    <div class="card advanced-only">
      <h2>Alert Emails</h2>
      <div class="muted">Bin Commander posts feed alerts to the Chicken Chat hub; the hub sends the email.</div>
      <div class="config-grid">
        <label class="check-item"><input id="notificationEmailEnabled" type="checkbox"> Email feed alerts</label>
        <div>
          <label for="notificationEmailTo">Email To</label>
          <input id="notificationEmailTo" type="email" maxlength="96" placeholder="operator@example.com">
        </div>
        <div>
          <label for="notificationHubUrl">Hub Notify URL</label>
          <input id="notificationHubUrl" type="url" maxlength="160" placeholder="http://192.168.1.10:8787/api/alerts/notify">
        </div>
        <div class="inline-actions">
          <button onclick="saveNotificationConfig()">Save Notifications</button>
          <button class="alt" onclick="sendNotificationTest()">Send Test</button>
        </div>
      </div>
      <div class="diag-grid">
        <div class="diag"><span>Email Status</span><div id="notificationStatus">-</div></div>
        <div class="diag"><span>Last Result</span><div id="notificationLastStatus">-</div></div>
        <div class="diag"><span>Last Attempt</span><div id="notificationLastAttempt">-</div></div>
        <div class="diag"><span>Last Success</span><div id="notificationLastSuccess">-</div></div>
      </div>
    </div>

    <div class="card advanced-only">
      <h2>Wiring Settings</h2>
      <div class="muted">Match these settings to the installed board and field wiring. Saving them turns both augers OFF, re-reads the hopper sensor, and leaves feeder logic in Manual.</div>
      <div class="check-grid">
        <label class="check-item"><input id="relayActiveHigh" type="checkbox"> Relay outputs are active-high</label>
        <label class="check-item"><input id="feedSensorActiveHigh" type="checkbox"> Feed sensor is active-high</label>
        <label class="check-item"><input id="ledActiveHigh" type="checkbox"> Status LED is active-high</label>
      </div>
      <div class="inline-actions">
        <button onclick="saveHardwareConfig()">Save Hardware Settings</button>
      </div>
    </div>

    <div class="card advanced-only">
      <h2>House Planner</h2>
      <div class="muted">Basic house and rollout notes for higher-level dashboards. These fields do not change auger wiring or safety behavior.</div>
      <div class="config-grid">
        <div>
          <label for="plannerHouseName">House Name</label>
          <input id="plannerHouseName" type="text" maxlength="32" placeholder="House 1">
        </div>
        <div>
          <label for="plannerNodesTarget">Target Nodes</label>
          <input id="plannerNodesTarget" type="number" min="1" max="100" step="1">
        </div>
      </div>
      <label for="plannerNotes">Planner Notes</label>
      <textarea id="plannerNotes" placeholder="Notes for Bin Commander rollout, sensor placement, or auger layout."></textarea>
      <div class="check-grid">
        <label class="check-item"><input id="plannerMeshEnabled" type="checkbox"> Mesh enabled</label>
        <label class="check-item"><input id="plannerTrackBinLevel" type="checkbox"> Track bin level</label>
        <label class="check-item"><input id="plannerTrackBinClog" type="checkbox"> Track bin clog</label>
        <label class="check-item"><input id="plannerTrackVibrator" type="checkbox"> Track vibrator</label>
        <label class="check-item"><input id="plannerTrackHopperAuger" type="checkbox"> Track hopper auger</label>
        <label class="check-item"><input id="plannerTrackLineAuger" type="checkbox"> Track line auger</label>
        <label class="check-item"><input id="plannerTrackMotorCurrent" type="checkbox"> Track motor current</label>
      </div>
      <div class="inline-actions">
        <button onclick="saveHousePlannerConfig()">Save Compatibility Settings</button>
      </div>
    </div>

    <div class="card advanced-only">
      <h2>Backup &amp; Restore</h2>
      <div class="muted">Download a configuration snapshot or paste one back in. Restore stops both augers, writes the settings to NVS, and re-reads the feed sensor state before returning to normal operation.</div>
      <div class="inline-actions">
        <a class="help-link" href="/api/config" download="fbb-config.json" rel="noopener noreferrer">Download Backup</a>
        <button class="alt" onclick="document.getElementById('configRestoreFile').click()">Load JSON File</button>
        <button onclick="restoreConfig()">Restore Snapshot</button>
      </div>
      <input id="configRestoreFile" type="file" accept="application/json,.json" style="display:none" onchange="loadConfigFile(this)">
      <label for="configRestoreText">Restore JSON</label>
      <textarea id="configRestoreText" placeholder="Paste an exported fbb-config.json snapshot here"></textarea>
    </div>

    <div class="card advanced-only">
      <h2>Remote Access</h2>
      <div class="muted">Use the controller AP for direct local service, station Wi-Fi for farm-network access, or a companion Tailscale gateway when remote access is needed. The gateway units can read <code>/etc/default/fbb</code> so you can override the controller host, proxy port, or health URL without editing the shipped service files.</div>
      <div class="inline-actions" style="margin-top: 12px;">
        <button class="alt" onclick="saveApAccess(true)">Generate AP Password</button>
        <a class="help-link" href="/manual" target="_blank" rel="noopener noreferrer">Access Notes</a>
      </div>
      <div class="diag-grid">
        <div class="diag"><span>Controller AP</span><div>BIN COMMANDER</div></div>
        <div class="diag"><span>Controller IP</span><div>192.168.4.1</div></div>
        <div class="diag"><span>Network IP</span><div id="remoteStationIp">-</div></div>
        <div class="diag"><span>Gateway Tag</span><div>tag:fbb-gateway</div></div>
      </div>
    </div>

    <div class="card advanced-only">
      <details class="diag-panel">
        <summary>Diagnostics</summary>
        <div class="diag-grid">
          <div class="diag"><span>Firmware Version</span><div id="firmwareVersion">-</div></div>
          <div class="diag"><span>Board Profile</span><div id="buildProfile">-</div></div>
          <div class="diag"><span>Last Restart</span><div id="bootReason">-</div></div>
          <div class="diag"><span>Current Status</span><div id="controllerState">-</div></div>
          <div class="diag"><span>Status Details</span><div id="controllerStateDetail">-</div></div>
          <div class="diag"><span>Health Summary</span><div id="healthLevel">-</div></div>
          <div class="diag"><span>Health Code</span><div id="healthLevelCode">-</div></div>
          <div class="diag"><span>Status Code</span><div id="controllerStateCode">-</div></div>
          <div class="diag"><span>Settings Version</span><div id="configVersion">-</div></div>
          <div class="diag"><span>Settings Loaded</span><div id="configLoaded">-</div></div>
          <div class="diag"><span>Unsaved Settings</span><div id="configDirty">-</div></div>
          <div class="diag"><span>Unsaved For</span><div id="configDirtyAge">-</div></div>
          <div class="diag"><span>Settings Save Error</span><div id="configSaveFault">-</div></div>
          <div class="diag"><span>Save Error Detail</span><div id="configSaveFaultReason">-</div></div>
          <div class="diag"><span>Last Settings Save</span><div id="configSaved">-</div></div>
          <div class="diag"><span>Time Since Save</span><div id="configSavedAge">-</div></div>
          <div class="diag"><span>Last Save Try</span><div id="configSaveAttemptAge">-</div></div>
          <div class="diag"><span>Reboot Queued</span><div id="rebootPending">-</div></div>
          <div class="diag"><span>Reboot Reason</span><div id="rebootReason">-</div></div>
          <div class="diag"><span>Reboot In</span><div id="rebootEta">-</div></div>
          <div class="diag"><span>Relay Wiring</span><div id="relayPolarity">-</div></div>
          <div class="diag"><span>Hopper Sensor Wiring</span><div id="sensorPolarity">-</div></div>
          <div class="diag"><span>Status LED Wiring</span><div id="ledPolarity">-</div></div>
          <div class="diag"><span>Controller Name</span><div id="networkName">-</div></div>
          <div class="diag"><span>Device Role</span><div id="deviceRole">-</div></div>
          <div class="diag"><span>Controller AP</span><div id="apRunning">-</div></div>
          <div class="diag"><span>AP Password</span><div id="apSecurity">-</div></div>
          <div class="diag"><span>AP Wi-Fi Channel</span><div id="apChannel">-</div></div>
          <div class="diag"><span>Client Drop Guard</span><div id="apDisconnectGuard">-</div></div>
          <div class="diag"><span>Controller AP Address</span><div id="apIp">-</div></div>
          <div class="diag"><span>Connected Devices</span><div id="stations">-</div></div>
          <div class="diag"><span>Last Client Change</span><div id="apStationChange">-</div></div>
          <div class="diag"><span>ESP-NOW Link</span><div id="espNowReady">-</div></div>
          <div class="diag"><span>ESP-NOW Messages</span><div id="espNowPackets">-</div></div>
          <div class="diag"><span>ESP-NOW Sent</span><div id="espNowSent">-</div></div>
          <div class="diag"><span>Last ESP-NOW Sender</span><div id="espNowSender">-</div></div>
          <div class="diag"><span>Last ESP-NOW Message</span><div id="espNowAge">-</div></div>
          <div class="diag"><span>Bin 1 Controlled By</span><div id="relay1Owner">-</div></div>
          <div class="diag"><span>Bin 1 Time Left</span><div id="relay1Lease">-</div></div>
          <div class="diag"><span>Bin 1 Run Time</span><div id="relay1Runtime">-</div></div>
          <div class="diag"><span>Bin 2 Controlled By</span><div id="relay2Owner">-</div></div>
          <div class="diag"><span>Bin 2 Time Left</span><div id="relay2Lease">-</div></div>
          <div class="diag"><span>Bin 2 Run Time</span><div id="relay2Runtime">-</div></div>
          <div class="diag"><span>Physical Button</span><div id="btnState">-</div></div>
          <div class="diag"><span>Last Button Action</span><div id="btnAction">-</div></div>
          <div class="diag"><span>Bin 1 Relay Pin</span><div id="relay1Gpio">-</div></div>
          <div class="diag"><span>Bin 2 Relay Pin</span><div id="relay2Gpio">-</div></div>
          <div class="diag"><span>Hopper Sensor Pin</span><div id="feedGpio">-</div></div>
          <div class="diag"><span>Status LED Pin</span><div id="statusLedGpio">-</div></div>
          <div class="diag"><span>E-Stop Pin</span><div id="hardEstopGpio">-</div></div>
          <div class="diag"><span>E-Stop Input</span><div id="hardEstopState">-</div></div>
          <div class="diag"><span>Time Since Restart</span><div id="uptime">-</div></div>
          <div class="diag"><span>Free Memory</span><div id="heap">-</div></div>
          <div class="diag"><span>Lowest Free Memory</span><div id="minHeap">-</div></div>
          <div class="diag"><span>ESP32 Chip</span><div id="chip">-</div></div>
          <div class="diag"><span>CPU Speed</span><div id="cpu">-</div></div>
          <div class="diag"><span>Flash Size</span><div id="flash">-</div></div>
        </div>
      </details>
    </div>

    <div class="card">
      <h2>Recent Events</h2>
      <div class="muted">Latest controller log entries, including safety interlocks, runtime cutoffs, and reconnects.</div>
      <div id="logPanel" class="log-panel">Loading logs...</div>
    </div>
  </div>

    <script>
    function setText(id, value) {
      const el = document.getElementById(id);
      if (el) {
        el.textContent = value;
      }
    }

    function formatDuration(ms) {
      const sec = Math.floor(ms / 1000);
      const d = Math.floor(sec / 86400);
      const h = Math.floor((sec % 86400) / 3600);
      const m = Math.floor((sec % 3600) / 60);
      const s = sec % 60;
      if (d > 0) return `${d}d ${h}h ${m}m`;
      if (h > 0) return `${h}h ${m}m ${s}s`;
      if (m > 0) return `${m}m ${s}s`;
      return `${s}s`;
    }

    function formatClock(ms) {
      const total = Math.floor(ms / 1000);
      const d = Math.floor(total / 86400);
      const h = Math.floor((total % 86400) / 3600);
      const m = Math.floor((total % 3600) / 60);
      const s = total % 60;
      const hh = String(h).padStart(2, '0');
      const mm = String(m).padStart(2, '0');
      const ss = String(s).padStart(2, '0');
      return d > 0 ? `${d}d ${hh}:${mm}:${ss}` : `${hh}:${mm}:${ss}`;
    }

    function words(value) {
      const text = String(value || '').replace(/_/g, ' ').trim();
      return text
        ? text.replace(/\b\w/g, ch => ch.toUpperCase())
        : '-';
    }

    function gpioLabel(value) {
      const pin = Number(value);
      return pin === 255 ? 'Disabled' : `GPIO ${pin}`;
    }

    const MAINTENANCE_TOKEN_KEY = 'fbbMaintenanceToken';
    const MAINTENANCE_HEADER = 'X-FBB-Maintenance-Token';

    document.addEventListener('click', (event) => {
      const bubble = event.target.closest ? event.target.closest('.info-bubble') : null;
      if (!bubble) return;
      event.preventDefault();
      event.stopPropagation();
      bubble.focus();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && document.activeElement && document.activeElement.classList.contains('info-bubble')) {
        document.activeElement.blur();
      }
    });

    function getMaintenanceToken() {
      try {
        return sessionStorage.getItem(MAINTENANCE_TOKEN_KEY) || '';
      } catch (e) {
        console.warn('maintenance token read failed', e);
        return '';
      }
    }

    function setMaintenanceToken(token) {
      try {
        if (token) {
          sessionStorage.setItem(MAINTENANCE_TOKEN_KEY, token);
        } else {
          sessionStorage.removeItem(MAINTENANCE_TOKEN_KEY);
        }
      } catch (e) {
        console.warn('maintenance token write failed', e);
      }
    }

    function maintenanceHeaders(extraHeaders = {}) {
      const headers = { ...extraHeaders };
      const token = getMaintenanceToken();
      if (token) {
        headers[MAINTENANCE_HEADER] = token;
      }
      return headers;
    }

    function updateMaintenanceUi(unlocked, remainingMs, openAccess = false) {
      const statusEl = document.getElementById('maintenanceStatus');
      const leaseEl = document.getElementById('maintenanceLease');
      const button = document.getElementById('maintenanceUnlockButton');
      const passwordInput = document.getElementById('maintenancePassword');
      const tokenPresent = !!getMaintenanceToken();
      const active = !!openAccess || (!!unlocked && tokenPresent);

      if (statusEl) {
        statusEl.textContent = openAccess ? 'Open AP' : (active ? 'Unlocked' : 'Locked');
      }
      if (leaseEl) {
        leaseEl.textContent = openAccess ? 'No password needed' : (active ? formatDuration(Math.max(0, Number(remainingMs) || 0)) : 'None');
      }
      if (button) {
        button.textContent = openAccess ? 'Open Access' : (active ? 'Refresh Unlock' : 'Unlock');
        button.disabled = !!openAccess;
      }
      if (passwordInput) {
        passwordInput.disabled = !!openAccess;
        passwordInput.placeholder = openAccess ? 'AP open access active' : 'AP / OTA password';
      }
      if ((!active || openAccess) && tokenPresent) {
        setMaintenanceToken('');
      }
    }

    function lockMaintenance() {
      setMaintenanceToken('');
      const passwordInput = document.getElementById('maintenancePassword');
      if (passwordInput) {
        passwordInput.value = '';
      }
      updateMaintenanceUi(false, 0);
      setSystemBanner('info', 'Maintenance locked', 'This browser tab no longer sends the temporary maintenance token.');
    }

    async function unlockMaintenance(promptIfBlank = true) {
      if (window.fbbOpenTestAccess) {
        updateMaintenanceUi(true, 0, true);
        return true;
      }

      const passwordInput = document.getElementById('maintenancePassword');
      let password = passwordInput ? String(passwordInput.value || '').trim() : '';
      const hadToken = !!getMaintenanceToken();
      if (!password && promptIfBlank) {
        password = window.prompt('Enter the current AP / OTA password to unlock maintenance actions:', '') || '';
      }
      if (!password) {
        return false;
      }

      try {
        const params = new URLSearchParams();
        params.set('password', password);
        const res = await fetch('/api/security/unlock', {
          method: 'POST',
          body: params,
        });
        const text = await res.text();
        let data = {};
        try {
          data = text ? JSON.parse(text) : {};
        } catch (e) {
          console.warn('maintenance unlock response was not JSON', e, text);
        }

        if (!res.ok) {
          if (!hadToken) {
            lockMaintenance();
          }
          alert('Maintenance unlock failed: ' + (data.error || text || `HTTP ${res.status}`));
          return false;
        }

        const token = String(data.maintenance_token || '').trim();
        if (!token) {
          if (!hadToken) {
            lockMaintenance();
          }
          alert('Maintenance unlock failed: missing session token.');
          return false;
        }

        setMaintenanceToken(token);
        if (passwordInput) {
          passwordInput.value = '';
        }
        updateMaintenanceUi(true, Number(data.maintenance_session_remaining_ms || 0));
        setSystemBanner(
          'info',
          'Maintenance unlocked',
          'This browser tab can now change protected settings until the temporary session expires.'
        );
        return true;
      } catch (e) {
        console.warn('maintenance unlock failed', e);
        alert('Maintenance unlock failed: ' + e);
        return false;
      }
    }

    async function maintenanceRequest(url, options = {}, promptOnLock = false) {
      const requestOptions = {
        ...options,
        headers: maintenanceHeaders(options.headers || {}),
      };
      let res = await fetch(url, requestOptions);
      if (res.status === 403 && promptOnLock) {
        const unlocked = await unlockMaintenance(true);
        if (!unlocked) {
          return null;
        }
        requestOptions.headers = maintenanceHeaders(options.headers || {});
        res = await fetch(url, requestOptions);
      }
      return res;
    }

    async function fetchJsonWithMaintenance(url, options = {}, promptOnLock = false) {
      const res = await maintenanceRequest(url, options, promptOnLock);
      if (!res) {
        return null;
      }
      return res;
    }

    async function fetchStatus() {
      const res = await maintenanceRequest('/api/status', {}, false);
      if (!res.ok) throw new Error('status fetch failed');
      return res.json();
    }

    async function feedBin(channel, action) {
      const requiresUnlock = action !== 'off';
      const res = await maintenanceRequest(`/api/feedbin/${channel}/${action}`, { method: 'POST' }, requiresUnlock);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Feed Bin command failed: ' + txt);
      }
      await refresh();
    }

    async function setFeedBinToggle(channel, checked) {
      await feedBin(channel, checked ? 'on' : 'off');
    }

    const momentaryLatch = { 1: false, 2: false };
    let emergencyLatched = false;
    let faultLatched = false;
    let statusPollFailures = 0;
    let rebootNoticeActive = false;
    let manualOutputsActive = false;

    async function momentaryFeedBin(channel, pressed) {
      if (emergencyLatched) return;
      if (momentaryLatch[channel] === pressed) return;
      momentaryLatch[channel] = pressed;
      await feedBin(channel, pressed ? 'on' : 'off');
    }

    function momentaryTouch(event, channel, pressed) {
      event.preventDefault();
      momentaryFeedBin(channel, pressed);
    }

    async function cluckMagic(channel, action) {
      const requiresUnlock = action !== 'off';
      const res = await maintenanceRequest(`/api/cluck/${channel}/${action}`, { method: 'POST' }, requiresUnlock);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Cluck-o-Magic command failed: ' + txt);
      }
      await refresh();
    }

    const cluckMagicMomentaryLatch = { 1: false, 2: false };

    async function momentaryCluckMagic(channel, pressed) {
      if (emergencyLatched) return;
      if (cluckMagicMomentaryLatch[channel] === pressed) return;
      cluckMagicMomentaryLatch[channel] = pressed;
      await cluckMagic(channel, pressed ? 'on' : 'off');
    }

    function cluckMagicTouch(event, channel, pressed) {
      event.preventDefault();
      momentaryCluckMagic(channel, pressed);
    }

    async function saveCluckMagicConfig() {
      const params = new URLSearchParams();
      params.set('selected_mac', document.getElementById('cluckMagicSelectedMac').value);
      const res = await maintenanceRequest(`/api/cluck/config?${params.toString()}`, { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Failed to save Cluck-o-Magic module: ' + txt);
        return;
      }
      setSystemBanner('info', 'Cluck-o-Magic saved', 'The selected shaker module was saved.');
      await refresh();
    }

    async function useDetectedCluckMagic() {
      const select = document.getElementById('cluckMagicDetectedSelect');
      if (!select || !select.value) {
        alert('No Cluck-o-Magic module is detected yet.');
        return;
      }
      document.getElementById('cluckMagicSelectedMac').value = select.value;
      await saveCluckMagicConfig();
    }

    async function emergencyStop() {
      const res = await fetch('/api/emergency/stop', { method: 'POST' });
      if (!res.ok) {
        const txt = await res.text();
        alert('Emergency stop failed: ' + txt);
      }
      await refresh();
    }

    async function resetEmergencyStop() {
      const res = await maintenanceRequest('/api/emergency/reset', { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Emergency reset failed: ' + txt);
      }
      await refresh();
    }

    async function resetFault() {
      const res = await maintenanceRequest('/api/fault/reset', { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Fault reset failed: ' + txt);
      }
      await refresh();
    }

    async function clearFeedAlarm() {
      const res = await maintenanceRequest('/api/alarm/clear', { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Feed alarm clear failed: ' + txt);
        return;
      }
      setSystemBanner('info', 'Feed alarm cleared', 'The alarm timer was restarted from the current hopper sensor state.');
      await refresh();
    }

    async function rebootController() {
      if (!confirm('Reboot the controller now? The auger outputs will be forced OFF first.')) {
        return;
      }
      const res = await maintenanceRequest('/api/reboot', { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Reboot request failed: ' + txt);
        return;
      }
      lockMaintenance();
      rebootNoticeActive = true;
      setSystemBanner('info', 'Reboot pending', 'Outputs were forced OFF and the controller will restart shortly.');
      await refresh();
    }

    async function saveApAccess(generatePassword) {
      const enabledInput = document.getElementById('apPasswordEnabled');
      const passwordInput = document.getElementById('apPasswordNew');
      const enabled = generatePassword ? true : !!(enabledInput && enabledInput.checked);
      const password = passwordInput ? String(passwordInput.value || '').trim() : '';

      if (enabled && !generatePassword && password.length > 0 && password.length < 8) {
        alert('AP password must be at least 8 characters.');
        return;
      }

      const confirmText = enabled
        ? 'Apply AP password protection now? The controller will reboot and you may need to reconnect with the new password.'
        : 'Make the controller AP open now? The controller will reboot and the AP will not require a Wi-Fi password.';
      if (!confirm(confirmText)) {
        return;
      }

      try {
        const params = new URLSearchParams();
        params.set('ap_password_enabled', enabled ? '1' : '0');
        if (enabled && !generatePassword && password.length > 0) {
          params.set('password', password);
        }
        const res = await maintenanceRequest(`/api/security/ap/config?${params.toString()}`, { method: 'POST' }, true);
        if (!res) {
          return;
        }
        const text = await res.text();
        let data = {};
        try {
          data = text ? JSON.parse(text) : {};
        } catch (e) {
          console.warn('Password rotation response was not JSON', e, text);
        }

        if (!res.ok) {
          alert('Password rotation failed: ' + text);
          await refresh();
          return;
        }

        lockMaintenance();
        rebootNoticeActive = true;
        const newPassword = String(data.new_password || '').trim();
        if (passwordInput) {
          passwordInput.value = '';
        }
        if (enabledInput) {
          enabledInput.checked = !!data.ap_password_enabled;
        }
        const message = enabled
          ? [
              'AP / OTA password enabled.',
              newPassword ? `Password: ${newPassword}` : 'Using the password you entered.',
              'The controller is rebooting now.'
            ].join('\n')
          : 'Controller AP set to open access. The controller is rebooting now.';
        alert(message);
        setSystemBanner('info', 'AP access update pending', 'Outputs were forced OFF and the controller will restart with the new AP access setting.');
        await refresh();
      } catch (e) {
        rebootNoticeActive = true;
        console.warn('AP access request interrupted', e);
        alert('AP access request was interrupted. The controller may already be rebooting with the new setting.');
        setSystemBanner('info', 'AP access update pending', 'The controller may already be rebooting with the new AP access setting.');
        await refresh().catch(() => {});
      }
    }

    async function rotateAccessPassword() {
      return saveApAccess(true);
    }

    async function saveAlarmConfig() {
      const noRunoutMin = document.getElementById('noRunoutMin').value;
      const emptyTooLongMin = document.getElementById('emptyTooLongMin').value;
      const res = await maintenanceRequest(`/api/alarm/config?no_runout_min=${encodeURIComponent(noRunoutMin)}&empty_too_long_min=${encodeURIComponent(emptyTooLongMin)}`, { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Failed to save alarm config: ' + txt);
      }
      await refresh();
    }

    async function saveSafetyConfig() {
      const params = new URLSearchParams();
      params.set('manual_timeout_sec', document.getElementById('manualLeaseSec').value);
      params.set('relay_max_min', document.getElementById('relayMaxMin').value);
      params.set('automation_keepalive_sec', document.getElementById('automationKeepaliveSec').value);
      const res = await maintenanceRequest(`/api/safety/config?${params.toString()}`, { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Failed to save safety config: ' + txt);
      }
      await refresh();
    }

    async function saveHardwareConfig() {
      const params = new URLSearchParams();
      params.set('relay_active_high', document.getElementById('relayActiveHigh').checked ? '1' : '0');
      params.set('feed_sensor_active_high', document.getElementById('feedSensorActiveHigh').checked ? '1' : '0');
      params.set('led_active_high', document.getElementById('ledActiveHigh').checked ? '1' : '0');
      const res = await maintenanceRequest(`/api/hardware/config?${params.toString()}`, { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Failed to save hardware settings: ' + txt);
      }
      await refresh();
    }

    async function saveWifiConfig() {
      const params = new URLSearchParams();
      const password = document.getElementById('stationWifiPassword').value;
      params.set('station_enabled', document.getElementById('stationWifiEnabled').checked ? '1' : '0');
      params.set('ssid', document.getElementById('stationWifiSsid').value);
      if (password.length > 0) {
        params.set('password', password);
      }
      params.set('clear_password', document.getElementById('stationWifiClearPassword').checked ? '1' : '0');

      const res = await maintenanceRequest(`/api/wifi/config?${params.toString()}`, { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Failed to save Wi-Fi settings: ' + txt);
        return;
      }
      document.getElementById('stationWifiPassword').value = '';
      document.getElementById('stationWifiClearPassword').checked = false;
      setSystemBanner('info', 'Wi-Fi saved', 'The controller is applying the farm-network Wi-Fi settings.');
      await refresh();
    }

    async function saveNotificationConfig() {
      const params = new URLSearchParams();
      params.set('email_enabled', document.getElementById('notificationEmailEnabled').checked ? '1' : '0');
      params.set('email_to', document.getElementById('notificationEmailTo').value);
      params.set('hub_url', document.getElementById('notificationHubUrl').value);

      const res = await maintenanceRequest(`/api/notifications/config?${params.toString()}`, { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Failed to save notification settings: ' + txt);
        return;
      }
      setSystemBanner('info', 'Notifications saved', 'The controller will send feed alerts to the configured hub when station Wi-Fi is connected.');
      await refresh();
    }

    async function sendNotificationTest() {
      const res = await maintenanceRequest('/api/notifications/test', { method: 'POST' }, true);
      if (!res) {
        return;
      }
      const text = await res.text();
      let data = {};
      try {
        data = text ? JSON.parse(text) : {};
      } catch (e) {
        console.warn('Notification test response was not JSON', e, text);
      }

      if (!res.ok) {
        alert(`Notification test failed: ${data.notification_status || text || res.status}`);
        await refresh();
        return;
      }

      alert(`Notification test sent: ${data.notification_status || 'sent'}`);
      await refresh();
    }

    async function loadConfigFile(input) {
      const file = input.files && input.files[0];
      if (!file) {
        return;
      }
      try {
        const text = await file.text();
        document.getElementById('configRestoreText').value = text;
      } catch (e) {
        alert('Failed to read config file: ' + e);
      } finally {
        input.value = '';
      }
    }

    async function restoreConfig() {
      const textArea = document.getElementById('configRestoreText');
      const payload = textArea.value.trim();
      if (!payload) {
        alert('Paste or load a config snapshot first.');
        return;
      }
      if (!confirm('Restore this snapshot? Both augers will be forced OFF before the settings are saved.')) {
        return;
      }

      try {
        const res = await maintenanceRequest('/api/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: payload,
        }, true);
        if (!res) {
          return;
        }
        const text = await res.text();
        if (!res.ok) {
          alert('Failed to restore config: ' + text);
          return;
        }

        let data = {};
        try {
          data = text ? JSON.parse(text) : {};
        } catch (e) {
          console.warn('Config restore response was not JSON', e, text);
        }

        await refresh();
        const notes = [];
        notes.push(data.hardware_changed
          ? 'Hardware profile changed.'
          : 'Configuration restored.');
        notes.push('Outputs were forced OFF during the restore.');
        if (data.config_saved === false) {
          notes.push(`Persistent save failed: ${data.config_save_fault_reason || 'unknown save fault'}.`);
        }
        if (data.warning) {
          notes.push(String(data.warning));
        }
        alert(notes.join('\n'));
      } catch (e) {
        alert('Config restore failed: ' + e);
      }
    }

    async function heartbeatLease() {
      try {
        if (!manualOutputsActive) {
          return;
        }
        const res = await fetch('/api/lease/heartbeat', { method: 'POST' });
        if (!res.ok && res.status !== 403) {
          console.warn('heartbeat failed', await res.text());
        }
      } catch (e) {
        console.warn('heartbeat failed', e);
      }
    }

    async function refreshLogs() {
      try {
        const res = await fetch('/api/logs?limit=12');
        if (!res.ok) throw new Error('logs fetch failed');
        const data = await res.json();
        const entries = Array.isArray(data.entries) ? data.entries : [];
        const panel = document.getElementById('logPanel');
        if (panel) {
          panel.textContent = entries.map((entry) => {
            const seconds = Math.floor((entry.ms || 0) / 1000);
            const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
            const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
            const s = String(seconds % 60).padStart(2, '0');
            return `[${h}:${m}:${s}] ${entry.message || ''}`;
          }).join('\n') || 'No events yet.';
        }
      } catch (e) {
        console.error(e);
      }
    }

    function modePretty(mode) {
      if (mode === 'sensor_demand') return 'Hopper Sensor';
      if (mode === 'auto_switch') return 'Auto Switch';
      if (mode === 'alternate_cycle') return 'Alternate Each Fill';
      if (mode === 'timed_alternate') return 'Timed Alternate';
      return 'Manual';
    }

    function modeRule(mode) {
      if (mode === 'sensor_demand') {
        return 'Sensor low starts the preferred bin; feed present starts the hopper top-off timer, then stops both bins.';
      }
      if (mode === 'auto_switch') {
        return 'Sensor low starts the preferred bin; if feed does not recover before timeout, switch once, then use hopper top-off after feed is present.';
      }
      if (mode === 'alternate_cycle') {
        return 'Sensor low starts the preferred bin; after hopper top-off completes, stop both bins and make the other bin preferred next time.';
      }
      if (mode === 'timed_alternate') {
        return 'Sensor low starts the preferred bin; feed present starts hopper top-off, and the preferred bin alternates by timer while idle.';
      }
      return 'Manual switches and buttons control the bins; the hopper sensor only reports status and alarms.';
    }

    async function saveFeedLogicConfig() {
      const params = new URLSearchParams();
      params.set('bin1_name', document.getElementById('feedBin1NameInput').value);
      params.set('bin2_name', document.getElementById('feedBin2NameInput').value);
      params.set('mode', document.getElementById('logicModeSelect').value);
      const alternateMin = document.getElementById('logicAlternateMin').value.trim();
      const autoSwitchSec = document.getElementById('logicAutoSwitchSec').value.trim();
      const topOffSec = document.getElementById('logicTopOffSec').value.trim();
      if (alternateMin.length > 0) params.set('alternate_min', alternateMin);
      if (autoSwitchSec.length > 0) params.set('auto_switch_sec', autoSwitchSec);
      if (topOffSec.length > 0) params.set('top_off_sec', topOffSec);
      params.set('preferred_bin', document.getElementById('logicPreferredBin').value);

      const res = await maintenanceRequest(`/api/feedlogic/config?${params.toString()}`, { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        let msg = txt;
        try {
          const data = txt ? JSON.parse(txt) : {};
          msg = data.error || data.config_save_fault_reason || txt;
        } catch (e) {}
        alert('Failed to save feeder logic: ' + (msg || `HTTP ${res.status}`));
        return;
      }
      setSystemBanner('info', 'Feeder logic saved', 'The feeder logic settings were saved to the controller.');
      await refresh();
    }

    async function saveHousePlannerConfig() {
      const params = new URLSearchParams();
      params.set('house_name', document.getElementById('plannerHouseName').value);
      params.set('notes', document.getElementById('plannerNotes').value);
      params.set('nodes_target', document.getElementById('plannerNodesTarget').value);
      params.set('mesh_enabled', document.getElementById('plannerMeshEnabled').checked ? '1' : '0');
      params.set('track_bin_level', document.getElementById('plannerTrackBinLevel').checked ? '1' : '0');
      params.set('track_bin_clog', document.getElementById('plannerTrackBinClog').checked ? '1' : '0');
      params.set('track_vibrator', document.getElementById('plannerTrackVibrator').checked ? '1' : '0');
      params.set('track_hopper_auger', document.getElementById('plannerTrackHopperAuger').checked ? '1' : '0');
      params.set('track_line_auger', document.getElementById('plannerTrackLineAuger').checked ? '1' : '0');
      params.set('track_motor_current', document.getElementById('plannerTrackMotorCurrent').checked ? '1' : '0');

      const res = await maintenanceRequest(`/api/houseplanner/config?${params.toString()}`, { method: 'POST' }, true);
      if (!res) {
        return;
      }
      if (!res.ok) {
        const txt = await res.text();
        alert('Failed to save house planner: ' + txt);
      }
      await refresh();
    }

    function setAlarmVisual(state) {
      const chip = document.getElementById('alarmChip');
      chip.className = 'chip';
      if (state === 'no_runout_too_long') {
        chip.classList.add('warn');
        chip.textContent = 'ALARM 1: NO RUNOUT TOO LONG';
      } else if (state === 'empty_too_long') {
        chip.classList.add('alarm');
        chip.textContent = 'ALARM 2: BIN EMPTY TOO LONG';
      } else {
        chip.classList.add('normal');
        chip.textContent = 'NORMAL';
      }
    }

    function setSystemBanner(level, title, detail) {
      const banner = document.getElementById('systemBanner');
      const badge = document.getElementById('systemBannerBadge');
      if (!banner || !badge) {
        return;
      }

      const safeLevel = ['good', 'info', 'warn', 'alarm', 'offline'].includes(level) ? level : 'info';
      banner.className = `card system-banner ${safeLevel}`;

      badge.className = 'chip';
      if (safeLevel === 'good') {
        badge.classList.add('normal');
        badge.textContent = 'READY';
      } else if (safeLevel === 'warn') {
        badge.classList.add('warn');
        badge.textContent = 'WARN';
      } else if (safeLevel === 'alarm') {
        badge.classList.add('alarm');
        badge.textContent = 'ALARM';
      } else if (safeLevel === 'offline') {
        badge.classList.add('warn');
        badge.textContent = 'OFFLINE';
      } else {
        badge.classList.add('normal');
        badge.textContent = 'INFO';
      }

      setText('systemBannerTitle', title || 'Controller State');
      setText('systemBannerDetail', detail || '');
    }

    function buildSystemBanner(s) {
      const healthTitle = String(s.health_title || '');
      const healthDetail = String(s.health_detail || '');
      if (healthTitle.length > 0 || healthDetail.length > 0) {
        return {
          level: String(s.health_level || 'info'),
          title: healthTitle || 'Controller State',
          detail: healthDetail || 'Controller status unavailable.',
        };
      }

      const rebootPending = !!s.reboot_pending;
      const faultLatched = !!s.fault_latched;
      const emergencyLatched = !!s.emergency_stop_latched;
      const hardEmergencyStopEnabled = !!s.hardware_emergency_stop_enabled;
      const hardEmergencyStopActive = !!s.hardware_emergency_stop_active;
      const apDisconnectGuardArmed = !!s.ap_disconnect_guard_armed;
      const apDisconnectGraceRemaining = Number(s.ap_disconnect_grace_remaining_ms || 0);
      const apRunning = !!s.ap_running;
      const logicMode = String(s.feed_logic_mode || 'manual');
      const bin1On = !!(s.feed_bin1_on ?? s.silo1_on);
      const bin2On = !!(s.feed_bin2_on ?? s.silo2_on);
      const bin1Name = String(s.feed_bin1_name || 'Feed Bin 1');
      const bin2Name = String(s.feed_bin2_name || 'Feed Bin 2');
      const bin1Owner = String(s.feed_bin1_owner || 'none').toUpperCase();
      const bin2Owner = String(s.feed_bin2_owner || 'none').toUpperCase();
      const bin1Lease = Number(s.feed_bin1_lease_remaining_ms || 0);
      const bin2Lease = Number(s.feed_bin2_lease_remaining_ms || 0);
      const uptime = Number(s.uptime_ms || 0);
      const configDirty = !!s.config_dirty;
      const configSaveFault = !!s.config_save_fault;
      const configSaveFaultReason = String(s.config_save_fault_reason || '');
      const configDirtySinceMs = Number(s.config_dirty_since_ms || 0);
      const configLastSaveAttemptMs = Number(s.config_last_save_attempt_ms || 0);
      const configLastSavedMs = Number(s.config_last_saved_ms || 0);
      const configDirtyAge = configDirtySinceMs > 0 ? formatDuration(Math.max(0, uptime - configDirtySinceMs)) : '';
      const configSaveAttemptAge =
        configLastSaveAttemptMs > 0 ? formatDuration(Math.max(0, uptime - configLastSaveAttemptMs)) : '';
      const configLastSavedAge =
        configLastSavedMs > 0 ? formatDuration(Math.max(0, uptime - configLastSavedMs)) : '';

      if (rebootPending) {
        const rebootEta = Number(s.reboot_remaining_ms || 0);
        return {
          level: 'info',
          title: 'Reboot pending',
          detail: `Outputs were forced OFF and the controller will restart in ${rebootEta > 0 ? formatDuration(rebootEta) : 'a moment'}.`,
        };
      }

      if (faultLatched) {
        return {
          level: 'alarm',
          title: 'Fault latched',
          detail: `Controller outputs are OFF until the fault is cleared: ${s.fault_reason || 'unknown fault'}.`,
        };
      }

      if (emergencyLatched) {
        return {
          level: 'alarm',
          title: 'Emergency stop latched',
          detail: hardEmergencyStopActive
            ? 'The hard stop input is active, so the controller is refusing to energize either auger.'
            : 'Outputs are forced OFF until the emergency stop is reset.',
        };
      }

      if (hardEmergencyStopEnabled && hardEmergencyStopActive) {
        return {
          level: 'warn',
          title: 'Hardware stop active',
          detail: 'The normally-closed stop loop is open. Restore the loop before attempting a reset.',
        };
      }

      if (!apRunning) {
        return {
          level: 'warn',
          title: 'Access point restarting',
          detail: 'The controller AP is not advertising yet. Wait for Wi-Fi recovery or check the access-point service.',
        };
      }

      if (apDisconnectGuardArmed && apDisconnectGraceRemaining > 0) {
        return {
          level: 'warn',
          title: 'Disconnect guard armed',
          detail: `A client was present and then disconnected. Reconnect before the AP grace timer expires in ${formatDuration(apDisconnectGraceRemaining)}.`,
        };
      }

      if (bin1On || bin2On) {
        const details = [];
        if (bin1On) {
          details.push(`${bin1Name}: ${bin1Owner}${bin1Lease > 0 ? `, lease ${formatDuration(bin1Lease)} left` : ''}`);
        }
        if (bin2On) {
          details.push(`${bin2Name}: ${bin2Owner}${bin2Lease > 0 ? `, lease ${formatDuration(bin2Lease)} left` : ''}`);
        }
        if (configSaveFault) {
          details.push(configSaveFaultReason
            ? `storage fault: ${configSaveFaultReason}`
            : 'storage fault');
        }
        return {
          level: 'info',
          title: bin1On && bin2On ? 'Both augers running' : `${bin1On ? bin1Name : bin2Name} running`,
          detail: details.join(' | '),
        };
      }

      if (configSaveFault) {
        return {
          level: 'warn',
          title: 'Persistent storage fault',
          detail: `${configSaveFaultReason ? `NVS save failed (${configSaveFaultReason})` : 'NVS save failed'}${
            configSaveAttemptAge ? ` ${configSaveAttemptAge} ago` : ''
          }. Settings remain dirty until storage recovers.${
            configLastSavedAge ? ` Last successful save was ${configLastSavedAge} ago.` : ''
          }`,
        };
      }

      if (logicMode !== 'manual') {
        const logicRule = String(s.feed_logic_run_rule || modeRule(logicMode));
        return {
          level: 'info',
          title: 'Feed logic armed',
          detail: `${modePretty(logicMode)}: ${logicRule} Manual GUI controls override automation for the manual lease.`,
        };
      }

      if (configDirty) {
        return {
          level: 'info',
          title: 'Configuration pending save',
          detail: configDirtyAge
            ? `Settings changed ${configDirtyAge} ago and will be written to NVS shortly.`
            : 'Settings changed and will be written to NVS shortly.',
        };
      }

      return {
        level: 'good',
        title: 'Ready',
        detail: 'All outputs are OFF and the controller is waiting for work.',
      };
    }

    async function refresh() {
      try {
        const s = await fetchStatus();
        const bin1On = !!(s.feed_bin1_on ?? s.silo1_on);
        const bin2On = !!(s.feed_bin2_on ?? s.silo2_on);
        manualOutputsActive = bin1On || bin2On;
        const logicMode = s.feed_logic_mode || 'manual';
        const logicLabel = String(s.feed_logic_mode_label || modePretty(logicMode));
        const logicRunRule = String(s.feed_logic_run_rule || modeRule(logicMode));
        const logicManual = logicMode === 'manual';
        const alarmState = String(s.alarm_state || 'normal');
        const feedAlarmActive = alarmState === 'empty_too_long';
        const manualOverrideRemaining = Number(s.manual_control_override_remaining_ms || 0);
        const bin1Name = s.feed_bin1_name || 'Feed Bin 1';
        const bin2Name = s.feed_bin2_name || 'Feed Bin 2';
        const relay1Owner = words(s.feed_bin1_owner || 'none');
        const relay2Owner = words(s.feed_bin2_owner || 'none');
        const relay1Lease = s.feed_bin1_lease_remaining_ms
          ? `${formatDuration(s.feed_bin1_lease_remaining_ms)} left`
          : 'None';
        const relay2Lease = s.feed_bin2_lease_remaining_ms
          ? `${formatDuration(s.feed_bin2_lease_remaining_ms)} left`
          : 'None';
        emergencyLatched = !!s.emergency_stop_latched;
        faultLatched = !!s.fault_latched;
        const rebootPending = !!s.reboot_pending;
        const rebootReason = String(s.reboot_reason || '');
        const rebootReasonLabel = rebootPending ? words(rebootReason || 'maintenance reboot') : 'None';
        const rebootEta = s.reboot_remaining_ms
          ? `${formatDuration(s.reboot_remaining_ms)} left`
          : 'Ready';
        const hardEmergencyStopEnabled = !!s.hardware_emergency_stop_enabled;
        const hardEmergencyStopActive = !!s.hardware_emergency_stop_active;
        statusPollFailures = 0;
        rebootNoticeActive = rebootPending;
        window.fbbOpenTestAccess = !!s.open_access;
        updateMaintenanceUi(
          !!s.maintenance_unlocked,
          Number(s.maintenance_session_remaining_ms || 0),
          window.fbbOpenTestAccess
        );
        const banner = buildSystemBanner(s);

        setText('feedBin1Title', bin1Name.toUpperCase());
        setText('feedBin2Title', bin2Name.toUpperCase());
        setText('feedBin1MomentaryLabel', `Momentary ${bin1Name}`);
        setText('feedBin2MomentaryLabel', `Momentary ${bin2Name}`);
        setText('feedBin1State', `${bin1Name} Status: ${bin1On ? 'RUNNING' : 'STOPPED'} | Owner: ${relay1Owner} | Lease: ${relay1Lease}`);
        setText('feedBin2State', `${bin2Name} Status: ${bin2On ? 'RUNNING' : 'STOPPED'} | Owner: ${relay2Owner} | Lease: ${relay2Lease}`);
        document.getElementById('feedBin1Toggle').checked = bin1On;
        document.getElementById('feedBin2Toggle').checked = bin2On;
        setText('feedBin1ToggleState', bin1On ? 'ON' : 'OFF');
        setText('feedBin2ToggleState', bin2On ? 'ON' : 'OFF');
        let controlState = faultLatched
          ? `Fault: ${s.fault_reason || 'unknown'}`
          : (emergencyLatched
            ? (hardEmergencyStopActive
              ? 'Emergency stop: latched, hardware input active'
              : 'Emergency stop: latched, outputs forced OFF')
            : 'Emergency stop: clear');
        if (rebootPending) {
          controlState = `Reboot pending: ${rebootReasonLabel} | ETA: ${rebootEta}`;
        }
        controlState += hardEmergencyStopEnabled
          ? (hardEmergencyStopActive ? ' | Hard stop input active' : ' | Hard stop input clear')
          : ' | Hard stop input disabled';
        if (!logicManual && !emergencyLatched && !faultLatched) {
          controlState += manualOverrideRemaining > 0
            ? ` | Manual override active: ${formatDuration(manualOverrideRemaining)} left`
            : ' | Manual controls override automation';
        }
        if (feedAlarmActive && !emergencyLatched && !faultLatched) {
          controlState += ' | Feed alarm active; manual controls available';
        }
        setText('emergencyState', controlState);
        setSystemBanner(banner.level, banner.title, banner.detail);
        const topOffStatus = s.feed_logic_top_off_active
          ? ` | Top-Off: ${formatDuration(s.feed_logic_top_off_remaining_ms || 0)} left`
          : ` | Top-Off Set: ${formatDuration(s.feed_logic_top_off_ms || 0)}`;
        setText('feedLogicStatus',
          `Mode: ${logicLabel} | Preferred Bin: ${s.feed_logic_preferred_bin || 1} | Active Bin: ${s.feed_logic_active_bin || 0}${topOffStatus}`);
        setText('feedLogicRule', `Run Rule: ${logicRunRule}`);

        const feedControlsLocked = emergencyLatched || hardEmergencyStopActive;
        document.getElementById('feedBin1Toggle').disabled = feedControlsLocked;
        document.getElementById('feedBin2Toggle').disabled = feedControlsLocked;
        const feedBin1MomentaryButton = document.getElementById('feedBin1Momentary');
        const feedBin2MomentaryButton = document.getElementById('feedBin2Momentary');
        if (feedBin1MomentaryButton) {
          feedBin1MomentaryButton.disabled = feedControlsLocked;
        }
        if (feedBin2MomentaryButton) {
          feedBin2MomentaryButton.disabled = feedControlsLocked;
        }
        if (feedControlsLocked) {
          momentaryLatch[1] = false;
          momentaryLatch[2] = false;
        }

        const cluckMagicRole = !!s.cluck_magic_role;
        const cluckModules = Array.isArray(s.cluck_magic_modules) ? s.cluck_magic_modules : [];
        const cluckOnline = !!s.cluck_magic_selected_online;
        const cluckEffectiveMac = String(s.cluck_magic_effective_mac || '');
        const cluckSelectedMac = String(s.cluck_magic_selected_mac || cluckEffectiveMac || '');
        const cluckSelectedName = String(s.cluck_magic_selected_name || 'Cluck-o-Magic');
        const cluckControlsLocked =
          cluckMagicRole || emergencyLatched || hardEmergencyStopActive || !s.espnow_ready || !cluckOnline;
        const cluckMacInput = document.getElementById('cluckMagicSelectedMac');
        if (cluckMacInput && document.activeElement !== cluckMacInput) {
          cluckMacInput.value = cluckSelectedMac;
        }
        const cluckSelect = document.getElementById('cluckMagicDetectedSelect');
        if (cluckSelect && document.activeElement !== cluckSelect) {
          cluckSelect.textContent = '';
          const placeholder = document.createElement('option');
          placeholder.value = '';
          placeholder.textContent = cluckModules.length > 0 ? 'Choose detected module' : 'No modules detected';
          cluckSelect.appendChild(placeholder);
          cluckModules.forEach((module) => {
            const option = document.createElement('option');
            option.value = module.mac || '';
            option.textContent = `${module.name || 'Cluck-o-Magic'} ${module.mac || ''}${module.online ? '' : ' (offline)'}`;
            if (option.value && option.value === cluckEffectiveMac) {
              option.selected = true;
            }
            cluckSelect.appendChild(option);
          });
        }
        const cluckStatus = cluckMagicRole
          ? 'This board is running as Cluck-o-Magic. Use Bin Commander to command it.'
          : (cluckOnline
            ? `${cluckSelectedName} online at ${cluckEffectiveMac || cluckSelectedMac}`
            : (cluckSelectedMac
              ? `Selected Cluck-o-Magic ${cluckSelectedMac} not detected`
              : 'No Cluck-o-Magic selected. Save a detected module to enable vibrator controls.'));
        setText('cluckMagicStatus', cluckStatus);
        setText('cluckMagicSelected', cluckEffectiveMac || cluckSelectedMac || 'None');
        setText('cluckMagicBin1State', `Vibrator 1: ${s.cluck_magic_bin1_on ? 'RUNNING' : 'STOPPED'}`);
        setText('cluckMagicBin2State', `Vibrator 2: ${s.cluck_magic_bin2_on ? 'RUNNING' : 'STOPPED'}`);
        setText('cluckMagicLastCommand',
          `${words(s.cluck_magic_last_command_status || 'none')}${
            s.cluck_magic_last_command_age_ms ? ` (${formatDuration(s.cluck_magic_last_command_age_ms)} ago)` : ''
          }`);
        setText('cluckMagicDetectedList', cluckModules.length
          ? cluckModules.map((module) =>
              `${module.name || 'Cluck-o-Magic'} ${module.mac || ''} ${module.online ? 'ONLINE' : 'OFFLINE'}`
            ).join(' | ')
          : 'None');
        ['cluckMagicBin1Momentary', 'cluckMagicBin2Momentary', 'cluckMagicBin1Off', 'cluckMagicBin2Off', 'cluckMagicBothOff'].forEach((id) => {
          const button = document.getElementById(id);
          if (button) {
            button.disabled = cluckControlsLocked;
          }
        });
        if (cluckControlsLocked) {
          cluckMagicMomentaryLatch[1] = false;
          cluckMagicMomentaryLatch[2] = false;
        }

        setText('feedState', s.feed_present ? 'Feed Present At Sensor Level' : 'Feed Low / Sensor Clear');
        setAlarmVisual(alarmState);
        const alarmClearButton = document.getElementById('alarmClearButton');
        if (alarmClearButton) {
          alarmClearButton.disabled = !s.alarm_clear_available || rebootPending;
        }
        if (alarmState === 'no_runout_too_long') {
          setText('alarmHint', 'Alarm 1 active: review feed flow and sensor placement, then clear the alarm to restart the timer.');
        } else if (alarmState === 'empty_too_long') {
          setText('alarmHint', 'Alarm 2 active: check feed, bridging, auger, and sensor. Manual GUI controls remain available unless emergency stop is active.');
        } else {
          setText('alarmHint', 'No active alarms.');
        }

        setText('feedPresentDur', formatDuration(s.feed_present_ms));
        setText('lowFeedDur', formatDuration(s.low_feed_ms));
        setText('alarmLed', s.alarm_led_on ? 'On' : 'Off');
        setText('feedGpio', gpioLabel(s.feed_sensor_gpio));
        setText('relay1Gpio', gpioLabel(s.relay_1_gpio));
        setText('relay2Gpio', gpioLabel(s.relay_2_gpio));
        setText('statusLedGpio', gpioLabel(s.status_led_gpio));
        setText('hardEstopGpio', s.hardware_emergency_stop_enabled ? gpioLabel(s.hardware_emergency_stop_gpio) : 'Disabled');
        setText('hardEstopState', s.hardware_emergency_stop_enabled
          ? (s.hardware_emergency_stop_active ? 'Stop input active' : 'Clear')
          : 'Disabled');

        const relayActiveHighInput = document.getElementById('relayActiveHigh');
        const feedSensorActiveHighInput = document.getElementById('feedSensorActiveHigh');
        const ledActiveHighInput = document.getElementById('ledActiveHigh');
        if (document.activeElement !== relayActiveHighInput) {
          relayActiveHighInput.checked = !!s.relay_active_high;
        }
        if (document.activeElement !== feedSensorActiveHighInput) {
          feedSensorActiveHighInput.checked = !!s.feed_sensor_active_high;
        }
        if (document.activeElement !== ledActiveHighInput) {
          ledActiveHighInput.checked = !!s.led_active_high;
        }

        const stationWifiEnabledInput = document.getElementById('stationWifiEnabled');
        const stationWifiSsidInput = document.getElementById('stationWifiSsid');
        const apPasswordEnabledInput = document.getElementById('apPasswordEnabled');
        if (document.activeElement !== apPasswordEnabledInput) {
          apPasswordEnabledInput.checked = !!s.ap_password_enabled;
        }
        if (document.activeElement !== stationWifiEnabledInput) {
          stationWifiEnabledInput.checked = !!s.station_wifi_enabled;
        }
        if (document.activeElement !== stationWifiSsidInput) {
          stationWifiSsidInput.value = s.station_wifi_ssid || '';
        }
        const stationStatus = s.station_wifi_connected
          ? 'Connected'
          : (s.station_wifi_connecting ? 'Connecting' : words(s.station_wifi_status || 'disabled'));
        setText('stationWifiStatus', stationStatus);
        setText('stationWifiIp', s.station_wifi_connected ? s.station_wifi_ip : 'Not connected');
        setText('remoteStationIp', s.station_wifi_connected ? s.station_wifi_ip : 'Not connected');
        setText('stationWifiRssi', s.station_wifi_connected ? `${s.station_wifi_rssi} dBm` : '-');
        const networkUpdateLink = document.getElementById('networkUpdateLink');
        if (networkUpdateLink) {
          networkUpdateLink.href = s.network_update_url || '/update';
          networkUpdateLink.textContent = s.station_wifi_connected ? 'OTA Update On Network' : 'OTA Update On AP';
        }

        const notificationEmailEnabledInput = document.getElementById('notificationEmailEnabled');
        const notificationEmailToInput = document.getElementById('notificationEmailTo');
        const notificationHubUrlInput = document.getElementById('notificationHubUrl');
        if (document.activeElement !== notificationEmailEnabledInput) {
          notificationEmailEnabledInput.checked = !!s.notification_email_enabled;
        }
        if (document.activeElement !== notificationEmailToInput) {
          notificationEmailToInput.value = s.notification_email_to || '';
        }
        if (document.activeElement !== notificationHubUrlInput) {
          notificationHubUrlInput.value = s.notification_hub_url || '';
        }
        setText('notificationStatus', String(s.notification_status || 'disabled').toUpperCase());
        setText('notificationLastStatus', String(s.notification_last_status || 'none').toUpperCase());
        setText('notificationLastAttempt', s.notification_last_attempt_ms
          ? `${formatDuration(Math.max(0, (s.uptime_ms || 0) - s.notification_last_attempt_ms))} AGO`
          : 'NEVER');
        setText('notificationLastSuccess', s.notification_last_success_ms
          ? `${formatDuration(Math.max(0, (s.uptime_ms || 0) - s.notification_last_success_ms))} AGO`
          : 'NEVER');

        const plannerHouseNameInput = document.getElementById('plannerHouseName');
        const plannerNotesInput = document.getElementById('plannerNotes');
        const plannerNodesTargetInput = document.getElementById('plannerNodesTarget');
        const plannerMeshEnabledInput = document.getElementById('plannerMeshEnabled');
        const plannerTrackBinLevelInput = document.getElementById('plannerTrackBinLevel');
        const plannerTrackBinClogInput = document.getElementById('plannerTrackBinClog');
        const plannerTrackVibratorInput = document.getElementById('plannerTrackVibrator');
        const plannerTrackHopperAugerInput = document.getElementById('plannerTrackHopperAuger');
        const plannerTrackLineAugerInput = document.getElementById('plannerTrackLineAuger');
        const plannerTrackMotorCurrentInput = document.getElementById('plannerTrackMotorCurrent');

        if (document.activeElement !== plannerHouseNameInput) {
          plannerHouseNameInput.value = s.house_planner_name || 'House 1';
        }
        if (document.activeElement !== plannerNotesInput) {
          plannerNotesInput.value = s.house_planner_notes || '';
        }
        if (document.activeElement !== plannerNodesTargetInput) {
          plannerNodesTargetInput.value = Math.max(1, Math.round(s.house_planner_nodes_target || 1));
        }
        if (document.activeElement !== plannerMeshEnabledInput) {
          plannerMeshEnabledInput.checked = !!s.house_planner_mesh_enabled;
        }
        if (document.activeElement !== plannerTrackBinLevelInput) {
          plannerTrackBinLevelInput.checked = !!s.house_planner_track_bin_level;
        }
        if (document.activeElement !== plannerTrackBinClogInput) {
          plannerTrackBinClogInput.checked = !!s.house_planner_track_bin_clog;
        }
        if (document.activeElement !== plannerTrackVibratorInput) {
          plannerTrackVibratorInput.checked = !!s.house_planner_track_vibrator;
        }
        if (document.activeElement !== plannerTrackHopperAugerInput) {
          plannerTrackHopperAugerInput.checked = !!s.house_planner_track_hopper_auger;
        }
        if (document.activeElement !== plannerTrackLineAugerInput) {
          plannerTrackLineAugerInput.checked = !!s.house_planner_track_line_auger;
        }
        if (document.activeElement !== plannerTrackMotorCurrentInput) {
          plannerTrackMotorCurrentInput.checked = !!s.house_planner_track_motor_current;
        }

        const manualLeaseInput = document.getElementById('manualLeaseSec');
        const relayMaxInput = document.getElementById('relayMaxMin');
        const autoKeepInput = document.getElementById('automationKeepaliveSec');
        if (document.activeElement !== manualLeaseInput) {
          manualLeaseInput.value = Math.max(10, Math.round((s.manual_override_timeout_ms || 0) / 1000));
        }
        if (document.activeElement !== relayMaxInput) {
          relayMaxInput.value = Math.max(1, Math.round((s.relay_max_runtime_ms || 0) / 60000));
        }
        if (document.activeElement !== autoKeepInput) {
          autoKeepInput.value = Math.max(5, Math.round((s.automation_keepalive_ms || 0) / 1000));
        }

        const noRunoutInput = document.getElementById('noRunoutMin');
        const emptyTooLongInput = document.getElementById('emptyTooLongMin');
        if (document.activeElement !== noRunoutInput) {
          noRunoutInput.value = Math.max(1, Math.round(s.no_runout_alarm_after_ms / 60000));
        }
        if (document.activeElement !== emptyTooLongInput) {
          emptyTooLongInput.value = Math.max(1, Math.round(s.empty_too_long_alarm_after_ms / 60000));
        }

        const bin1NameInput = document.getElementById('feedBin1NameInput');
        const bin2NameInput = document.getElementById('feedBin2NameInput');
        const modeSelect = document.getElementById('logicModeSelect');
        const alternateInput = document.getElementById('logicAlternateMin');
        const autoSwitchInput = document.getElementById('logicAutoSwitchSec');
        const topOffInput = document.getElementById('logicTopOffSec');
        const preferredSelect = document.getElementById('logicPreferredBin');

        if (document.activeElement !== bin1NameInput) {
          bin1NameInput.value = bin1Name;
        }
        if (document.activeElement !== bin2NameInput) {
          bin2NameInput.value = bin2Name;
        }
        if (document.activeElement !== modeSelect) {
          modeSelect.value = logicMode;
        }
        if (document.activeElement !== alternateInput) {
          alternateInput.value = Math.max(1, Math.round((s.feed_logic_alternate_ms || 0) / 60000));
        }
        if (document.activeElement !== autoSwitchInput) {
          autoSwitchInput.value = Math.max(10, Math.round((s.feed_logic_auto_switch_ms || 0) / 1000));
        }
        if (document.activeElement !== topOffInput) {
          topOffInput.value = Math.max(0, Math.round((s.feed_logic_top_off_ms || 0) / 1000));
        }
        if (document.activeElement !== preferredSelect) {
          preferredSelect.value = String(s.feed_logic_preferred_bin || 1);
        }

        setText('networkName', s.network_name || 'Bin Commander');
        setText('deviceRole', words(s.device_role || 'bin_commander'));
        setText('apRunning', s.ap_running ? 'Broadcasting' : 'Off');
        setText('apSecurity', s.ap_secure ? 'Password required' : 'Open');
        setText('apChannel', s.ap_channel);
        if (s.ap_disconnect_grace_remaining_ms > 0) {
          setText('apDisconnectGuard', `Watching - fault in ${formatDuration(s.ap_disconnect_grace_remaining_ms)}`);
        } else {
          setText('apDisconnectGuard', s.ap_disconnect_guard_armed ? 'Watching clients' : 'Waiting for first client');
        }
        setText('firmwareVersion', s.firmware_version || 'unknown');
        setText('buildProfile', s.build_profile || 'esp32dev');
        setText('bootReason', words(s.boot_reason || 'unknown'));
        setText('controllerState', words(s.controller_state || 'ready'));
        setText('controllerStateDetail', s.controller_state_detail || 'controller ready');
        setText(
          'healthLevel',
          `${words(s.health_level || 'info')} (${Number.isFinite(Number(s.health_level_code)) ? Number(s.health_level_code) : 1})`
        );
        setText(
          'healthLevelCode',
          Number.isFinite(Number(s.health_level_code)) ? String(Number(s.health_level_code)) : '-'
        );
        setText(
          'controllerStateCode',
          Number.isFinite(Number(s.controller_state_code)) ? String(Number(s.controller_state_code)) : '-'
        );
        setText('configVersion', s.config_version ?? '-');
        setText('configLoaded', s.config_loaded ? 'Loaded' : 'Not loaded');
        setText('configDirty', s.config_dirty ? 'Unsaved changes' : 'Saved');
        setText('configDirtyAge', s.config_dirty_since_ms
          ? `${formatDuration(Math.max(0, (s.uptime_ms || 0) - s.config_dirty_since_ms))} ago`
          : (s.config_dirty ? 'Pending' : 'Clean'));
        setText('configSaveFault', s.config_save_fault ? 'Save error' : 'OK');
        setText('configSaveFaultReason', s.config_save_fault_reason || 'None');
        setText('configSaved', s.config_last_saved_ms ? formatClock(s.config_last_saved_ms) : 'Never');
        setText('configSavedAge', s.config_last_saved_ms
          ? `${formatDuration(Math.max(0, (s.uptime_ms || 0) - s.config_last_saved_ms))} ago`
          : 'Never');
        setText('configSaveAttemptAge', s.config_last_save_attempt_ms
          ? `${formatDuration(Math.max(0, (s.uptime_ms || 0) - s.config_last_save_attempt_ms))} ago`
          : 'Never');
        setText('rebootPending', rebootPending ? 'Queued' : 'No');
        setText('rebootReason', rebootReasonLabel);
        setText('rebootEta', rebootPending ? rebootEta : 'Ready');
        setText('relayPolarity', s.relay_active_high ? 'Active-high' : 'Active-low');
        setText('sensorPolarity', s.feed_sensor_active_high ? 'Active-high' : 'Active-low');
        setText('ledPolarity', s.led_active_high ? 'Active-high' : 'Active-low');
        setText('espNowReady', s.espnow_ready ? 'Ready' : 'Off');
        setText('espNowPackets', `${Number(s.espnow_packets_rx || 0)} received`);
        setText('espNowSent', `${Number(s.espnow_packets_tx || 0)} sent`);
        setText('espNowSender', s.espnow_last_sender || 'None');
        setText('apIp', s.ap_ip);
        setText('stations', `${Number(s.stations || 0)} connected`);
        setText('relay1Owner', relay1Owner);
        setText('relay2Owner', relay2Owner);
        setText('relay1Lease', relay1Lease);
        setText('relay2Lease', relay2Lease);
        setText('relay1Runtime', formatDuration(s.feed_bin1_runtime_ms || 0));
        setText('relay2Runtime', formatDuration(s.feed_bin2_runtime_ms || 0));
        const buttonLastAction = String(s.button_last_action || 'none');
        const buttonLastActionAgeMs = Number(s.button_last_action_age_ms || 0);
        const localButtonEnabled = Number(s.button_gpio) !== 255;
        setText('btnAction',
          localButtonEnabled
            ? (buttonLastActionAgeMs > 0
              ? `${words(buttonLastAction)} (${formatDuration(buttonLastActionAgeMs)} ago)`
              : words(buttonLastAction))
            : 'Disabled');
        setText('apStationChange', s.ap_station_last_change_ms
          ? `${formatDuration(Math.max(0, (s.uptime_ms || 0) - s.ap_station_last_change_ms))} ago`
          : 'Never');
        setText('espNowAge', s.espnow_last_rx_ms
          ? `${formatDuration(Math.max(0, (s.uptime_ms || 0) - s.espnow_last_rx_ms))} ago`
          : 'Never');
        setText('btnState', localButtonEnabled ? (s.button_pressed ? 'Pressed' : 'Released') : 'Disabled');
        setText('uptimeCounter', formatClock(s.uptime_ms));
        setText('uptime', formatDuration(s.uptime_ms));
        setText('heap', `${Number(s.free_heap || 0)} bytes`);
        setText('minHeap', `${Number(s.min_free_heap || 0)} bytes`);
        setText('chip', `${s.chip_model} rev ${s.chip_revision}`);
        setText('cpu', `${Number(s.cpu_mhz || 0)} MHz`);
        setText('flash', `${Number(s.flash_mb || 0)} MB`);

        const rebootButton = document.getElementById('rebootButton');
        if (rebootButton) {
          rebootButton.disabled = rebootPending;
          rebootButton.textContent = rebootPending ? 'Rebooting...' : 'Safe Reboot';
        }

        await refreshLogs();
      } catch (e) {
        console.error(e);
        statusPollFailures += 1;
        if (rebootNoticeActive) {
          setSystemBanner('info', 'Reboot pending', 'Outputs were forced OFF and the controller is restarting.');
        } else {
          setSystemBanner(
            'offline',
            'Controller unreachable',
            statusPollFailures > 1
              ? `Status polling failed ${statusPollFailures} times in a row. Check the AP, gateway, or controller power.`
              : 'Unable to reach /api/status. Check the controller AP or gateway path.'
          );
        }
      }
    }

    refresh();
    setInterval(refresh, 1000);
    setInterval(heartbeatLease, 8000);
  </script>
</body>
</html>
)HTML";
}

void registerRoutes() {
  server.on("/", HTTP_GET, []() {
    sendHtmlPage(indexHtml());
  });
  server.on("/diagnostics", HTTP_GET, []() {
    sendHtmlPage(indexHtml());
  });
  server.on("/manual", HTTP_GET, []() {
    sendHtmlPage(manualHtml());
  });
  server.on("/readme", HTTP_GET, []() {
    sendHtmlPage(manualHtml());
  });
  server.on("/api/status", HTTP_GET, []() { sendStatusJson(); });
  server.on("/api/health", HTTP_GET, []() { handleHealth(); });
  server.on("/api/config", HTTP_GET, []() { handleConfigExport(); });
  server.on("/api/config", HTTP_POST, []() { handleConfigImport(); });
  server.on("/api/logs", HTTP_GET, []() { handleLogs(); });

  registerRelayFamilyRoutes("silo");
  registerRelayFamilyRoutes("feedbin");
  registerRelayFamilyRoutes("relay");
  server.on("/api/cluck/config", HTTP_POST, []() { handleCluckMagicConfigUpdate(); });
  server.on("/api/cluck/1/on", HTTP_POST, []() { handleCluckMagicCommand(ESPNOW_RELAY_1, "on"); });
  server.on("/api/cluck/1/off", HTTP_POST, []() { handleCluckMagicCommand(ESPNOW_RELAY_1, "off"); });
  server.on("/api/cluck/1/toggle", HTTP_POST, []() { handleCluckMagicCommand(ESPNOW_RELAY_1, "toggle"); });
  server.on("/api/cluck/2/on", HTTP_POST, []() { handleCluckMagicCommand(ESPNOW_RELAY_2, "on"); });
  server.on("/api/cluck/2/off", HTTP_POST, []() { handleCluckMagicCommand(ESPNOW_RELAY_2, "off"); });
  server.on("/api/cluck/2/toggle", HTTP_POST, []() { handleCluckMagicCommand(ESPNOW_RELAY_2, "toggle"); });
  server.on("/api/cluck/both/off", HTTP_POST, []() { handleCluckMagicCommand(ESPNOW_RELAY_BOTH, "off"); });

  server.on("/api/alarm/config", HTTP_POST, []() { handleAlarmConfigUpdate(); });
  server.on("/api/alarm/clear", HTTP_POST, []() { handleAlarmClear(); });
  server.on("/api/feedlogic/config", HTTP_POST, []() { handleFeedLogicConfigUpdate(); });
  server.on("/api/houseplanner/config", HTTP_POST, []() { handleHousePlannerConfigUpdate(); });
  server.on("/api/safety/config", HTTP_POST, []() { handleSafetyConfigUpdate(); });
  server.on("/api/hardware/config", HTTP_POST, []() { handleHardwareConfigUpdate(); });
  server.on("/api/wifi/config", HTTP_POST, []() { handleWifiConfigUpdate(); });
  server.on("/api/notifications/config", HTTP_POST, []() { handleNotificationConfigUpdate(); });
  server.on("/api/notifications/test", HTTP_POST, []() { handleNotificationTest(); });
  server.on("/api/security/unlock", HTTP_POST, []() { handleMaintenanceUnlock(); });
  server.on("/api/security/ap/config", HTTP_POST, []() { handleAccessPasswordRotate(); });
  server.on("/api/security/password/rotate", HTTP_POST, []() { handleAccessPasswordRotate(); });
  server.on("/api/lease/heartbeat", HTTP_POST, []() { handleLeaseHeartbeat(); });
  server.on("/api/fault/reset", HTTP_POST, []() { handleFaultReset(); });
  server.on("/api/reboot", HTTP_POST, []() { handleReboot(); });
  server.on("/api/emergency/stop", HTTP_POST, []() {
    engageEmergencyStop("manual emergency stop");
    sendStatusJson();
  });
  server.on("/api/emergency/reset", HTTP_POST, []() {
    if (hardwareEmergencyStopInputActive()) {
      server.send(409, "application/json",
                  "{\"error\":\"Hardware emergency stop input is still active\"}");
      return;
    }
    if (!requireMaintenanceSession("emergency stop reset")) {
      return;
    }
    if (resetEmergencyStop()) {
      sendStatusJson();
    } else {
      server.send(409, "application/json", "{\"error\":\"Emergency stop reset failed\"}");
    }
  });

  server.onNotFound([]() {
    const String uri = server.uri();
    if (server.method() == HTTP_GET && !uri.startsWith("/api/") && uri != "/update") {
      sendHtmlPage(indexHtml());
      return;
    }
    server.send(404, "application/json", "{\"error\":\"Not found\"}");
  });
}
}  // namespace

void setup() {
#ifdef FBB_CHICKEN_MESH
  chickenMesh.load();
  // Existing feeder networking remains authoritative. Provisioning validates channel 6.
  if (chickenMesh.configured && chickenMesh.config.channel != AP_CHANNEL) chickenMesh.configured = false;
#endif
  Serial.begin(115200);
  delay(150);

  deviceWifiPassword = generateAccessPassword();
  deviceAdminPassword = deviceWifiPassword;
  bootReasonLabel = bootReasonName(esp_reset_reason());
  loadPersistentConfig();

  if (esp_task_wdt_init(WDT_TIMEOUT_S, true) == ESP_OK && esp_task_wdt_add(NULL) == ESP_OK) {
    watchdogActive = true;
  }

  if (pinIsConfigured(PIN_BUTTON)) {
    pinMode(PIN_BUTTON, INPUT);
    buttonRawPressed = buttonPressed();
    buttonStablePressed = buttonRawPressed;
    buttonLastTransitionMs = millis();
    buttonPressStartedMs = buttonStablePressed ? millis() : 0;
    buttonLongPressHandled = buttonStablePressed;
  }
  if (pinIsConfigured(PIN_RELAY_1)) {
    initializeOutputPinInactive(PIN_RELAY_1, relayActiveHigh);
  }
  if (pinIsConfigured(PIN_RELAY_2)) {
    initializeOutputPinInactive(PIN_RELAY_2, relayActiveHigh);
  }
  if (pinIsConfigured(PIN_LED)) {
    initializeOutputPinInactive(PIN_LED, ledActiveHigh);
  }
  if (pinIsConfigured(PIN_FEED_SENSOR)) {
    pinMode(PIN_FEED_SENSOR, INPUT);
  }
  initializeEmergencyStopInput();

  relay1On = false;
  relay2On = false;
  ledOn = false;
  alarmBlinkOn = false;
  forceAllRelaysOff("boot");
  initializeFeedSensorState();
  initializeEmergencyStopState();
  feedLogicLastAlternateMs = millis();
  lastAlarmBlinkMs = millis();
  updateAlarmStateAndLed();
  if (configDirty) {
    savePersistentConfig();
  }

  const bool apStarted = startAccessPoint();
  const bool espNowStarted = initEspNow();

  registerRoutes();
  const char *collectedHeaders[] = {MAINTENANCE_TOKEN_HEADER};
  server.collectHeaders(collectedHeaders, 1);
  if (!accessPasswordRequired()) {
    httpUpdater.setup(&server, "/update");
  } else {
    httpUpdater.setup(&server, "/update", "fbb", deviceAdminPassword.c_str());
  }
  server.begin();

  Serial.println();
  if (apStarted) {
    Serial.print("AP started. Connect to SSID: ");
    Serial.println(AP_SSID);
    if (!accessPasswordRequired()) {
      Serial.println("AP / OTA password: none (open access)");
      Serial.println("Security: OPEN");
    } else {
      Serial.print("AP / OTA password: ");
      Serial.println(deviceWifiPassword);
      Serial.println("Security: WPA2 / WPA2-PSK");
    }
    Serial.print("Channel: ");
    Serial.println(AP_CHANNEL);
    Serial.print("AP MAC: ");
    Serial.println(WiFi.softAPmacAddress());
    Serial.print("Open: http://");
    Serial.println(WiFi.softAPIP());
    if (stationWifiConfigured()) {
      Serial.print("Station Wi-Fi target: ");
      Serial.println(stationWifiSsid);
      Serial.print("Station hostname: ");
      Serial.println(stationWifiHostname());
    }
  } else {
    Serial.println("ERROR: AP failed to start. Will retry in loop.");
  }

  Serial.print("ESP-NOW: ");
  Serial.println(espNowStarted ? "READY" : "FAILED");
  if (!accessPasswordRequired()) {
    Serial.println("OTA /update auth: disabled for open access");
  } else {
    Serial.print("OTA /update auth user=fbb password=");
    Serial.println(deviceAdminPassword);
  }
  Serial.print("Boot reason: ");
  Serial.println(bootReasonLabel);
  Serial.print("Build profile: ");
  Serial.println(BUILD_PROFILE);
  Serial.print("Relay pins: H1 GPIO");
  Serial.print(PIN_RELAY_1);
  Serial.print(", H2 GPIO");
  Serial.println(PIN_RELAY_2);
  Serial.print("Feed sensor (GPIO");
  Serial.print(PIN_FEED_SENSOR);
  Serial.print("): ");
  Serial.println(feedPresent ? "PRESENT" : "LOW");
  Serial.print("Feed sensor polarity: ");
  Serial.println(feedPresentWhenHigh ? "ACTIVE HIGH" : "ACTIVE LOW");
  Serial.print("Alarm 1 delay (no runout): ");
  Serial.print(noRunoutAlarmDelayMs / 60000);
  Serial.println(" min");
  Serial.print("Alarm 2 delay (empty too long): ");
  Serial.print(emptyTooLongAlarmDelayMs / 60000);
  Serial.println(" min");
  Serial.print("Feed logic mode: ");
  Serial.println(feedLogicModeName(feedLogicMode));
  Serial.print("Hopper top-off time: ");
  Serial.print(feedLogicTopOffMs / 1000UL);
  Serial.println(" sec");

  lastStatusLogMs = millis();
  lastApRetryMs = millis();
  lastEspNowRetryMs = millis();
  logEvent("Controller booted.");
}

void loop() {
  updateFeedSensorState();
  updateEmergencyStopState();
  updateLocalButtonState();
  updateFeedLogic();
  updateAlarmStateAndLed();
  monitorRelaySafety();
  server.handleClient();
  updateStationWifi();
  enforceDisconnectFailSafe();
  processEspNowCommands();
#ifdef FBB_CHICKEN_MESH
  chickenMesh.console([](const chickenmesh::Config &c) {
    return c.channel == AP_CHANNEL && c.gateway != chickenMesh.id &&
      !c.ssid[0] && !c.password[0] && !c.token[0] && c.analogPin == -1 && c.contactPin == -1;
  });
  chickenMesh.tick();
  if (chickenMesh.core && espNowReady) {
    static uint32_t lastMeshReading = 0;
    static uint8_t previousFlags = 255;
    uint8_t flags = (relay1On ? 1 : 0) | (relay2On ? 2 : 0) |
      ((emergencyStopLatched || hardwareEmergencyStopActive) ? 4 : 0) |
      (faultLatched ? 8 : 0) | (feedPresent ? 16 : 0);
    if (millis() - lastMeshReading >= chickenMesh.config.intervalMs ||
        (flags != previousFlags && millis() - lastMeshReading >= 1000)) {
      chickenmesh::Reading reading;
      reading.role = CLUCK_MAGIC_ROLE ? 2 : 1;
      reading.uptime = millis(); reading.feederFlags = flags;
      strcpy(reading.name, chickenMesh.config.name);
      strcpy(reading.house, chickenMesh.config.house);
      strcpy(reading.zone, chickenMesh.config.zone);
      uint8_t payload[chickenmesh::TelemetrySize];
      if (chickenmesh::encodeReading(reading, payload) &&
          chickenMesh.core->publish(chickenMesh.config.gateway, payload, sizeof(payload), millis(),
            (flags & 12) ? chickenmesh::Alarm : chickenmesh::Telemetry)) {
        previousFlags = flags; lastMeshReading = millis();
      }
    }
  }
#endif
  updateCluckMagicAnnounce();
  maybeSavePersistentConfig();
  if (rebootPending) {
    processPendingReboot();
  }

  if (watchdogActive && esp_task_wdt_reset() != ESP_OK) {
    Serial.println("WARN: task WDT reset failed.");
  }

  const unsigned long now = millis();
  if (!apRunning && (now - lastApRetryMs >= AP_RETRY_INTERVAL_MS)) {
    lastApRetryMs = now;
    const bool restarted = startAccessPoint();
    if (restarted) {
      Serial.print("AP restart succeeded. IP: ");
      Serial.println(WiFi.softAPIP());
    } else {
      Serial.println("AP restart attempt failed.");
    }
  }

  if (!espNowReady && (now - lastEspNowRetryMs >= ESPNOW_RETRY_INTERVAL_MS)) {
    lastEspNowRetryMs = now;
    if (initEspNow()) {
      logEvent("ESP-NOW reinitialized.");
    } else {
      Serial.println("ESP-NOW retry attempt failed.");
    }
  }

  if (now - lastStatusLogMs >= STATUS_LOG_INTERVAL_MS) {
    lastStatusLogMs = now;
    Serial.print("AP=");
    Serial.print(apRunning ? "ON" : "OFF");
    Serial.print(" secure=");
    Serial.print(apSecure ? "yes" : "no");
    Serial.print(" ip=");
    Serial.print(WiFi.softAPIP());
    Serial.print(" stations=");
    Serial.print(WiFi.softAPgetStationNum());
    Serial.print(" sta=");
    Serial.print(stationWifiStatusName(WiFi.status()));
    if (stationWifiConnected()) {
      Serial.print(" sta_ip=");
      Serial.print(WiFi.localIP());
    }
    Serial.print(" espnow=");
    Serial.print(espNowReady ? "ON" : "OFF");
    Serial.print(" rx=");
    Serial.print(espNowPacketsRx);
    Serial.print(" tx=");
    Serial.print(espNowPacketsTx);
    Serial.print(" role=");
    Serial.print(DEVICE_ROLE_NAME);
    Serial.print(" feed=");
    Serial.print(feedPresent ? "PRESENT" : "LOW");
    Serial.print(" alarm=");
    Serial.print(alarmStateName(alarmState));
    Serial.print(" logic=");
    Serial.print(feedLogicModeName(feedLogicMode));
    Serial.print(" preferred=");
    Serial.print(feedLogicPreferredBin);
    Serial.print(" topoff=");
    Serial.print(feedLogicTopOffActive ? "ON" : "OFF");
    Serial.print(" feedbin1=");
    Serial.print(relay1On ? "ON" : "OFF");
    Serial.print(" feedbin2=");
    Serial.print(relay2On ? "ON" : "OFF");
    Serial.print(" estop=");
    Serial.print(emergencyStopLatched ? "ON" : "OFF");
    Serial.print(" hw_estop=");
    Serial.print(pinIsConfigured(PIN_EMERGENCY_STOP)
                     ? (hardwareEmergencyStopActive ? "ON" : "OFF")
                     : "DISABLED");
    Serial.print(" fault=");
    Serial.print(faultLatched ? "ON" : "OFF");
    Serial.print(" fault_reason=");
    Serial.println(faultReason);
  }
}
